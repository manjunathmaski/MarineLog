﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.SqlServerCe.Client;
using Shell.MLBCaptureVesselData;
using System.Globalization;
using System.Windows.Forms;

namespace MLBCaptureVesselData
{
    public class HomeDataAccess
    {
        #region Global Variables
        SqlCeConnection con = new SqlCeConnection();
        #endregion

        public HomeDataAccess()
        {
            GetConnectionString();
        }

        #region GetVesselData
        /// <summary>
        /// This method gets the data of all projects/vessel Ids present 
        /// </summary>
        /// <returns>List of Vessel data</returns>
        public List<VesselInfoDataEntity> GetVesselData()
        {
            DataTable dtVesselData = new DataTable();
            DataSet dsVesselData = new DataSet();
            List<VesselInfoDataEntity> lstVesselData = new List<VesselInfoDataEntity>();
            VesselInfoDataEntity vdeVesselInfo = new VesselInfoDataEntity();

            try
            {
                //
                SqlCeDataAdapter sdaVesselData = new SqlCeDataAdapter("select * from Vessel_Information", con);
                sdaVesselData.Fill(dsVesselData);

                if (dsVesselData.Tables.Count > 0)
                {
                    dtVesselData = dsVesselData.Tables[0].Copy();
                }

                if (dtVesselData != null && dtVesselData.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtVesselData.Rows)
                    {
                        vdeVesselInfo = new VesselInfoDataEntity();
                        vdeVesselInfo.VesselNo = Convert.ToInt32(dr[Constants.VESSEL_NO.ToString()].ToString());
                        vdeVesselInfo.CompanyName = dr[Constants.COMPANY_NAME.ToString()].ToString();
                        vdeVesselInfo.NoOfVessels = dr[Constants.NO_OF_VESSELS.ToString()].ToString();
                        vdeVesselInfo.CustomerContact = dr[Constants.CUSTOMER_CONTACT.ToString()].ToString();
                        vdeVesselInfo.Address = dr[Constants.ADDRESS.ToString()].ToString();
                        vdeVesselInfo.Email = dr[Constants.EMAIL.ToString()].ToString();
                        vdeVesselInfo.Telephone = dr[Constants.TELEPHONE.ToString()].ToString();
                        vdeVesselInfo.SMPContactName = dr[Constants.SMP_CONTACT.ToString()].ToString();
                        vdeVesselInfo.SMPAddress = dr[Constants.SMP_ADDRESS].ToString();
                        vdeVesselInfo.SMPEmail = dr[Constants.SMP_EMAIL].ToString();
                        vdeVesselInfo.SMPTelephone = dr[Constants.SMP_TELEPHONE].ToString();
                        vdeVesselInfo.StartDateOfProj = dr[Constants.START_DATE_OF_PROJECT.ToString()].ToString();
                        vdeVesselInfo.TargetCompletionDate = dr[Constants.TGT_COMPLETION_DATE.ToString()].ToString();
                        vdeVesselInfo.VesselName = dr[Constants.VESSEL_NAME.ToString()].ToString();
                        vdeVesselInfo.IMONo = dr[Constants.IMO_NO.ToString()].ToString();
                        vdeVesselInfo.VesselID = dr[Constants.VESSEL_ID.ToString()].ToString();
                        vdeVesselInfo.DateDelivered = dr[Constants.DATE_DELIVERED.ToString()].ToString();
                        vdeVesselInfo.MainEngManuf = dr[Constants.MAIN_ENG_MANUFACTURER.ToString()].ToString();
                        vdeVesselInfo.MainEngType = dr[Constants.MAIN_ENGINE_TYPE.ToString()].ToString();
                        vdeVesselInfo.MainEngSerialNo = dr[Constants.MAIN_ENGINE_SERIAL_NO.ToString()].ToString();
                        vdeVesselInfo.MainEngLoc = dr[Constants.MAIN_ENGINE_LOCATION.ToString()].ToString();
                        vdeVesselInfo.MainEngNo = dr[Constants.MAIN_ENGINE_NO.ToString()].ToString();
                        vdeVesselInfo.MCR = dr[Constants.MCR.ToString()].ToString();
                        vdeVesselInfo.RPM = dr[Constants.RPM.ToString()].ToString();
                        vdeVesselInfo.LubricatorType = dr[Constants.LUBRICATOR_TYPE.ToString()].ToString();
                        vdeVesselInfo.MinFeedRate = dr[Constants.MIN_FEED_RATE.ToString()].ToString();
                        vdeVesselInfo.CurrentFeedRate = dr[Constants.CURRENT_FEED_RATE.ToString()].ToString();
                        vdeVesselInfo.TargetFeedRate = dr[Constants.TARGET_FEED_RATE.ToString()].ToString();
                        #region Change to include Oil Grade and Density at sample date level
                        vdeVesselInfo.OilGrade = dr[Constants.OIL_GRADE.ToString()].ToString();
                        vdeVesselInfo.Density = dr[Constants.DENSITY.ToString()].ToString();
                        #endregion
                        vdeVesselInfo.NoOfTurbos = dr[Constants.NO_OF_TURBOS.ToString()].ToString();
                        vdeVesselInfo.TurboCutOutAvailable = dr[Constants.TURBO_CUTOUT_AVAILABLE.ToString()].ToString();
                        vdeVesselInfo.PistonCleaningRing = dr[Constants.PISTON_CLEANING_RING.ToString()].ToString();
                        vdeVesselInfo.ProjectID = dr[Constants.VESSEL_ID.ToString()].ToString() + "-" + dr[Constants.VESSEL_NO.ToString()].ToString();
                        vdeVesselInfo.NoOfEngines = Convert.ToInt32(dr[Constants.NO_OF_ENGINES].ToString());
                        vdeVesselInfo.EngineNo = Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        vdeVesselInfo.NoOfCylinders = Convert.ToInt32(dr[Constants.NO_OF_CYLINDERS].ToString());
                        vdeVesselInfo.ProjectStatus = dr[Constants.PROJECT_STATUS].ToString();

                        lstVesselData.Add(vdeVesselInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return lstVesselData;
        }

        private void GetConnectionString()
        {
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userFilePath = Path.Combine(localAppData, "SHELL");

            string destFilePath = Path.Combine(userFilePath, "MLBDataCapture.sdf");
            con.ConnectionString = string.Format("Data Source={0};", destFilePath); 
        }
        #endregion

        #region UpdateVesselData
        /// <summary>
        /// This method updates the vessel data
        /// </summary>
        /// <param name="vdeVesselInfo">The vessel data that needs to be updated</param>
        /// <returns>bool indicating whether the operation was successful or not</returns>
        public bool UpdateVesselData(VesselInfoDataEntity vdeVesselInfo)
        {
            bool isSuccess = true;

            try
            {
                
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Vessel_Information SET " + Constants.COMPANY_NAME + "='" +
                    vdeVesselInfo.CompanyName + "', " + Constants.NO_OF_VESSELS + "='" +
                    vdeVesselInfo.NoOfVessels + "', " + Constants.CUSTOMER_CONTACT + "='" +
                    vdeVesselInfo.CustomerContact + "', " + Constants.ADDRESS + "='" +
                    vdeVesselInfo.Address + "', " + Constants.EMAIL + "='" +
                    vdeVesselInfo.Email + "', " + Constants.TELEPHONE + "='" +
                    vdeVesselInfo.Telephone + "', " + Constants.SMP_CONTACT + "='" +
                    vdeVesselInfo.SMPContactName + "', " + Constants.SMP_ADDRESS + "='" +
                    vdeVesselInfo.SMPAddress + "', " + Constants.SMP_EMAIL + "='" +
                    vdeVesselInfo.SMPEmail + "', " + Constants.SMP_TELEPHONE + "='" +
                    vdeVesselInfo.SMPTelephone + "', " + Constants.START_DATE_OF_PROJECT + "= @StartDate, " + Constants.TGT_COMPLETION_DATE + "= @EndDate, " 
                    + Constants.VESSEL_NAME + "='" +
                    vdeVesselInfo.VesselName + "', " + Constants.IMO_NO + "='" +
                    vdeVesselInfo.IMONo + "', " + Constants.VESSEL_ID + "='" +
                    vdeVesselInfo.VesselID + "', " + Constants.DATE_DELIVERED + "= @DateDelivered, " + Constants.MAIN_ENG_MANUFACTURER + "='" +
                    vdeVesselInfo.MainEngManuf + "', " + Constants.MAIN_ENGINE_TYPE + "='" +
                    vdeVesselInfo.MainEngType + "', " + Constants.MAIN_ENGINE_SERIAL_NO + "='" +
                    vdeVesselInfo.MainEngSerialNo + "', " + Constants.MAIN_ENGINE_LOCATION + "='" +
                    vdeVesselInfo.MainEngLoc + "', " + Constants.MAIN_ENGINE_NO + "='" +
                    vdeVesselInfo.MainEngNo + "', " + Constants.MCR + "='" +
                    vdeVesselInfo.MCR + "', " + Constants.RPM + "='" +
                    vdeVesselInfo.RPM + "', " + Constants.LUBRICATOR_TYPE + "='" +
                    vdeVesselInfo.LubricatorType + "', " + Constants.MIN_FEED_RATE + "='" +
                    vdeVesselInfo.MinFeedRate + "', " + Constants.CURRENT_FEED_RATE + "='" +
                    vdeVesselInfo.CurrentFeedRate + "', " + Constants.TARGET_FEED_RATE + "='" +
                    vdeVesselInfo.TargetFeedRate + "', " + Constants.OIL_GRADE + "='" +
                    vdeVesselInfo.OilGrade + "', " + Constants.DENSITY + "='" +
                    vdeVesselInfo.Density + "', " + Constants.NO_OF_TURBOS + "='" +
                    vdeVesselInfo.NoOfTurbos + "', " + Constants.TURBO_CUTOUT_AVAILABLE + "='" +
                    vdeVesselInfo.TurboCutOutAvailable + "', " + Constants.PISTON_CLEANING_RING + "='" +
                    vdeVesselInfo.PistonCleaningRing + "', " + Constants.NO_OF_ENGINES + "=" +
                    vdeVesselInfo.NoOfEngines + ", " + Constants.NO_OF_CYLINDERS + "=" +
                    vdeVesselInfo.NoOfCylinders + ", " + Constants.ENGINE_NO + "=" +
                    vdeVesselInfo.EngineNo + ", " + Constants.PROJECT_STATUS + "='" +
                    vdeVesselInfo.ProjectStatus +
                    "' where Vessel_No=" + vdeVesselInfo.VesselNo + " AND Engine_No=" + vdeVesselInfo.EngineNo;
                cmd.Parameters.Add("@StartDate", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.StartDateOfProj, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.TargetCompletionDate, CultureInfo.CurrentCulture);
                if (vdeVesselInfo.DateDelivered == string.Empty)
                {
                    cmd.Parameters.Add("@DateDelivered", SqlDbType.DateTime).Value = DateTime.Now;
                }
                else
                {
                    cmd.Parameters.Add("@DateDelivered", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.DateDelivered, CultureInfo.CurrentCulture);
                }
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                isSuccess = false;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return isSuccess;
        }
        #endregion

        #region InsertVesselData
        /// <summary>
        /// This method inserts new vessel data
        /// </summary>
        /// <param name="vdeVesselInfo">the vessel data to be inserted</param>
        /// <returns>bool indicating whether the operation was successful or not</returns>
        public bool InsertVesselData(VesselInfoDataEntity vdeVesselInfo)
        {
            bool isSuccess = true;
            
            try
            {
                
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Vessel_Information (" + Constants.VESSEL_NO + ", " + Constants.COMPANY_NAME + ", " + Constants.NO_OF_VESSELS + ", " + Constants.CUSTOMER_CONTACT +
                     ", " + Constants.ADDRESS + ", " + Constants.EMAIL + ", " + Constants.TELEPHONE + ", " + Constants.SMP_CONTACT +
                     ", " + Constants.SMP_ADDRESS + ", " + Constants.SMP_EMAIL + ", " + Constants.SMP_TELEPHONE + ", " + Constants.START_DATE_OF_PROJECT +
                     ", " + Constants.TGT_COMPLETION_DATE + ", " + Constants.VESSEL_NAME + ", " + Constants.IMO_NO + ", " + Constants.VESSEL_ID +
                     ", " + Constants.DATE_DELIVERED + ", " + Constants.MAIN_ENG_MANUFACTURER + ", " + Constants.MAIN_ENGINE_TYPE +
                     ", " + Constants.MAIN_ENGINE_SERIAL_NO + ", " + Constants.MAIN_ENGINE_LOCATION + ", " + Constants.MAIN_ENGINE_NO +
                     ", " + Constants.MCR + ", " + Constants.RPM + ", " + Constants.LUBRICATOR_TYPE + ", " + Constants.MIN_FEED_RATE +
                    ", " + Constants.CURRENT_FEED_RATE + ", " + Constants.TARGET_FEED_RATE + ", " + Constants.OIL_GRADE +
                     ", " + Constants.DENSITY + ", " + Constants.NO_OF_TURBOS + ", " + Constants.TURBO_CUTOUT_AVAILABLE +
                    ", " + Constants.PISTON_CLEANING_RING + ", " + Constants.NO_OF_ENGINES + ", " + Constants.ENGINE_NO + ", " + Constants.NO_OF_CYLINDERS +
                     ", " + Constants.PROJECT_STATUS + ") VALUES ('" +
                        vdeVesselInfo.VesselNo + "','" + vdeVesselInfo.CompanyName + "','" + vdeVesselInfo.NoOfVessels + "','" + vdeVesselInfo.CustomerContact
                        + "','" + vdeVesselInfo.Address + "','" + vdeVesselInfo.Email + "','" + vdeVesselInfo.Telephone + "','" + vdeVesselInfo.SMPContactName
                        + "','" + vdeVesselInfo.SMPAddress + "','" + vdeVesselInfo.SMPEmail + "','" + vdeVesselInfo.SMPTelephone + "',@StartDate, @EndDate,'" + vdeVesselInfo.VesselName + "','" + vdeVesselInfo.IMONo + "','" + vdeVesselInfo.VesselID
                        + "',@DateDelivered,'" + vdeVesselInfo.MainEngManuf + "','" + vdeVesselInfo.MainEngType
                        + "','" + vdeVesselInfo.MainEngSerialNo + "','" + vdeVesselInfo.MainEngLoc + "','" + vdeVesselInfo.MainEngNo
                        + "','" + vdeVesselInfo.MCR + "','" + vdeVesselInfo.RPM + "','" + vdeVesselInfo.LubricatorType + "','" + vdeVesselInfo.MinFeedRate
                        + "','" + vdeVesselInfo.CurrentFeedRate + "','" + vdeVesselInfo.TargetFeedRate + "','" + vdeVesselInfo.OilGrade
                        + "','" + vdeVesselInfo.Density + "','" + vdeVesselInfo.NoOfTurbos + "','" + vdeVesselInfo.TurboCutOutAvailable
                        + "','" + vdeVesselInfo.PistonCleaningRing + "'," + vdeVesselInfo.NoOfEngines + "," + vdeVesselInfo.EngineNo + "," + vdeVesselInfo.NoOfCylinders +
                        ",'" + vdeVesselInfo.ProjectStatus + "')";
                cmd.Parameters.Add("@StartDate", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.StartDateOfProj, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.TargetCompletionDate, CultureInfo.CurrentCulture);
                if (vdeVesselInfo.DateDelivered == string.Empty)
                {
                    cmd.Parameters.Add("@DateDelivered", SqlDbType.DateTime).Value = DateTime.Now;
                }
                else
                {
                    cmd.Parameters.Add("@DateDelivered", SqlDbType.DateTime).Value = Convert.ToDateTime(vdeVesselInfo.DateDelivered, CultureInfo.CurrentCulture);
                }
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                isSuccess = false;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return isSuccess;
        }
        #endregion

        #region GetRunningData
        /// <summary>
        /// This method Gets the running data for the given vessel no. and engine no.
        /// </summary>
        /// <param name="strVesselNo">The vessel no. for which running data needs to be fetched</param>
        /// <param name="engNo">The engine no. for which running data needs to be fetched</param>
        /// <returns>The list of running data for the given parameters</returns>
        public List<RunningData> GetRunningData(int strVesselNo, int engNo)
        {
            RunningData rngData = new RunningData();
            List<RunningData> lstRunningData = new List<RunningData>();
            DataSet dsRunningData = new DataSet();

            try
            {
                
                SqlCeDataAdapter sdaRunningData = new SqlCeDataAdapter("select * from Running_Data where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'"
                    + " ORDER BY DATE_OF_READING", con);
                sdaRunningData.Fill(dsRunningData);

                if (dsRunningData.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsRunningData.Tables[0].Rows)
                    {
                        rngData = new RunningData();
                        rngData.UniqueId = dr[Constants.UNIQUE_ID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.UNIQUE_ID.ToString()].ToString());
                        rngData.DateOfReading = dr[Constants.DATE_OF_READING].ToString();
                        rngData.PortSea = dr[Constants.PORTSEA].ToString();
                        rngData.NoOfCylinders = dr[Constants.NO_OF_CYLINDERS].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.NO_OF_CYLINDERS].ToString());
                        rngData.TotEngineHours = dr[Constants.TOT_ENGINE_HOURS].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.TOT_ENGINE_HOURS].ToString());
                        rngData.CylinderRPM = dr[Constants.CYLINDER_RPM].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CYLINDER_RPM].ToString());
                        rngData.Power = dr[Constants.POWER].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.POWER].ToString());
                        rngData.PercentMCR = dr[Constants.PERCENT_MCR].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.PERCENT_MCR].ToString());
                        rngData.PercentS = dr[Constants.PERCENT_S].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.PERCENT_S].ToString());
                        rngData.Catfines = dr[Constants.CATFINES].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CATFINES].ToString());
                        rngData.Vanadium = dr[Constants.VANADIUM].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.VANADIUM].ToString());
                        rngData.Consumption = dr[Constants.CONSUMPTION].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CONSUMPTION].ToString());
                        rngData.RelativeHumidity = dr[Constants.REL_HUMIDITY].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.REL_HUMIDITY].ToString());
                        rngData.AmbTemp = dr[Constants.AMB_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.AMB_TEMP].ToString());
                        rngData.ScavAirTemp = dr[Constants.SCAV_AIR_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.SCAV_AIR_TEMP].ToString());
                        rngData.EngRoomTemp = dr[Constants.ENG_ROOM_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.ENG_ROOM_TEMP].ToString());
                        rngData.CylinderOilConsump = dr[Constants.TOT_ENGINE_HOURS].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CYLINDER_OIL_CONSUMP].ToString());
                        rngData.Federate = dr[Constants.FEDERATE].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.FEDERATE].ToString());
                        rngData.SampleSentRCC = dr[Constants.SAMPLE_SENT_RCC].ToString();
                        rngData.NoOfTCInUse = dr[Constants.NO_OF_TC_IN_USE].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.NO_OF_TC_IN_USE].ToString());
                        #region Change to include Oil Grade and Density at sample date level
                        rngData.OilGrade = dr[Constants.OIL_GRADE].ToString();
                        rngData.Density = dr[Constants.DENSITY].ToString();
                        #endregion
                        rngData.Comments = dr[Constants.COMMENTS].ToString();
                        rngData.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        rngData.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        rngData.IsDataSubmitted = dr["Is_Data_Submitted"].ToString() == string.Empty ? 0 : Convert.ToInt32(dr["Is_Data_Submitted"].ToString());

                        lstRunningData.Add(rngData);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }


            return lstRunningData;
        }
        #endregion

        #region GetCylinderData
        /// <summary>
        /// This method Gets the cylinder data for the given vessel no. and engine no.
        /// </summary>
        /// <param name="strVesselNo">The vessel no. for which cylinder data needs to be fetched</param>
        /// <param name="engNo">The engine no. for which cylinder data needs to be fetched</param>
        /// <returns>The list of cylinder data for the given parameters</returns>
        public List<CylinderData> GetCylinderData(int strVesselNo, int engNo)
        {
            List<CylinderData> lstCylinderData = new List<CylinderData>();
            CylinderData cylData = new CylinderData();
            DataSet dsCylinderData = new DataSet();
            try
            {
                
                SqlCeDataAdapter sdaCylinderData = new SqlCeDataAdapter("select * from Cylinder_Data where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'", con);
                sdaCylinderData.Fill(dsCylinderData);

                if (dsCylinderData.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsCylinderData.Tables[0].Rows)
                    {
                        cylData = new CylinderData();
                        cylData.UniqueID = dr[Constants.CYLINDER_UNIQUE_ID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_UNIQUE_ID].ToString());
                        cylData.CylinderNumber = dr[Constants.CYLINDER_NUMBER].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NUMBER].ToString());
                        cylData.AAReading = dr[Constants.AA_READING].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.AA_READING].ToString());
                        cylData.PMax = dr[Constants.PMAX].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.PMAX].ToString());
                        cylData.FuelIndex = dr[Constants.FUEL_INDEX].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.FUEL_INDEX].ToString());
                        cylData.CoolingWaterTemp = dr[Constants.COOLING_WATER_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.COOLING_WATER_TEMP].ToString());
                        cylData.LinearWallTempMin = dr[Constants.LINEAR_WALL_TEMP_MIN].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.LINEAR_WALL_TEMP_MIN].ToString());
                        cylData.LinearWallTempMax = dr[Constants.LINEAR_WALL_TEMP_MAX].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.LINEAR_WALL_TEMP_MAX].ToString());
                        cylData.FederateSetPoint = dr[Constants.FEDERATE_SETPOINT].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.FEDERATE_SETPOINT].ToString());
                        cylData.BNMeasuredOnboard = dr[Constants.BN_MEASURED_ONBOARD].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.BN_MEASURED_ONBOARD].ToString());
                        cylData.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        cylData.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        cylData.MagneticIron = dr[Constants.MAGNETIC_IRON].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.MAGNETIC_IRON].ToString());
                        cylData.CorrosiveIron = dr[Constants.CORROSIVE_IRON].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CORROSIVE_IRON].ToString());

                        lstCylinderData.Add(cylData);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return lstCylinderData;
        }
        #endregion

        #region GetRunningDataPerDate
        /// <summary>
        /// This method Gets the running data for the given vessel no. and engine no. and date
        /// </summary>
        /// <param name="strVesselNo">The vessel no. for which running data needs to be fetched</param>
        /// <param name="engNo">The engine no. for which running data needs to be fetched</param>
        /// <param name="strDateOfReading">The date for which running data needs to be fetched</param>
        /// <returns>The list of running data for the given parameters</returns>
        public List<RunningData> GetRunningDataPerDate(string strDateOfReading, int engineNo, int vesselNo)
        {
            RunningData rngData = new RunningData();
            List<RunningData> lstRunningData = new List<RunningData>();
            DataSet dsRunningData = new DataSet();
            try
            {
                
                 if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "select * from Running_Data where Date_Of_Reading = @DOR AND Vessel_No = @VesselNo AND Engine_No = @EngNo";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(strDateOfReading, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = vesselNo;
                cmd.Parameters.Add("@EngNo", SqlDbType.Int).Value = engineNo;
                cmd.CommandType = CommandType.Text;
                SqlCeDataAdapter sdaRunningData = new SqlCeDataAdapter(cmd);
                    //new SqlCeDataAdapter("select * from Running_Data where Date_Of_Reading,110= @DOR AND Vessel_No = @VesselNo AND Engine_No = @EngNo", con);
                sdaRunningData.Fill(dsRunningData);

                if (dsRunningData.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsRunningData.Tables[0].Rows)
                    {
                        rngData.UniqueId = dr[Constants.UNIQUE_ID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.UNIQUE_ID.ToString()].ToString());
                        rngData.DateOfReading = dr[Constants.DATE_OF_READING].ToString();
                        rngData.PortSea = dr[Constants.PORTSEA].ToString();
                        rngData.NoOfCylinders = dr[Constants.NO_OF_CYLINDERS].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.NO_OF_CYLINDERS].ToString());
                        rngData.TotEngineHours = dr[Constants.TOT_ENGINE_HOURS].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.TOT_ENGINE_HOURS].ToString());
                        rngData.CylinderRPM = dr[Constants.CYLINDER_RPM].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CYLINDER_RPM].ToString());
                        rngData.Power = dr[Constants.POWER].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.POWER].ToString());
                        rngData.PercentMCR = dr[Constants.PERCENT_MCR].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.PERCENT_MCR].ToString());
                        rngData.PercentS = dr[Constants.PERCENT_S].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.PERCENT_S].ToString());
                        rngData.Catfines = dr[Constants.CATFINES].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CATFINES].ToString());
                        rngData.Vanadium = dr[Constants.VANADIUM].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.VANADIUM].ToString());
                        rngData.Consumption = dr[Constants.CONSUMPTION].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CONSUMPTION].ToString());
                        rngData.RelativeHumidity = dr[Constants.REL_HUMIDITY].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.REL_HUMIDITY].ToString());
                        rngData.AmbTemp = dr[Constants.AMB_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.AMB_TEMP].ToString());
                        rngData.ScavAirTemp = dr[Constants.SCAV_AIR_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.SCAV_AIR_TEMP].ToString());
                        rngData.EngRoomTemp = dr[Constants.ENG_ROOM_TEMP].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.ENG_ROOM_TEMP].ToString());
                        rngData.CylinderOilConsump = dr[Constants.TOT_ENGINE_HOURS].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.CYLINDER_OIL_CONSUMP].ToString());
                        rngData.Federate = dr[Constants.FEDERATE].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.FEDERATE].ToString());
                        rngData.SampleSentRCC = dr[Constants.SAMPLE_SENT_RCC].ToString();
                        rngData.NoOfTCInUse = dr[Constants.NO_OF_TC_IN_USE].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.NO_OF_TC_IN_USE].ToString());
                        rngData.Comments = dr[Constants.COMMENTS].ToString();
                        rngData.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        rngData.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());

                        lstRunningData.Add(rngData);
                    }
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }


            return lstRunningData;
        }
        #endregion

        #region InsertRunningData
        /// <summary>
        /// This method inserts the running data
        /// </summary>
        /// <param name="rngRunningData">the running data to be inserted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertRunningData(RunningData rngRunningData)
        {
            int inUniqueId = 0;
            List<RunningData> rngRngData = new List<RunningData>();

            try
            {
                
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Running_Data (" + Constants.DATE_OF_READING + "," +
                    Constants.PORTSEA + "," + Constants.NO_OF_CYLINDERS + "," + Constants.TOT_ENGINE_HOURS + "," +
                    Constants.CYLINDER_RPM + "," + Constants.POWER + "," + Constants.PERCENT_MCR + "," +
                    Constants.PERCENT_S + "," + Constants.CATFINES + "," + Constants.VANADIUM + "," +
                    Constants.CONSUMPTION + "," + Constants.REL_HUMIDITY + "," + Constants.AMB_TEMP + "," +
                    Constants.SCAV_AIR_TEMP + "," + Constants.ENG_ROOM_TEMP + "," + Constants.CYLINDER_OIL_CONSUMP + "," +
                    Constants.FEDERATE + "," + Constants.SAMPLE_SENT_RCC + "," + Constants.NO_OF_TC_IN_USE + "," + Constants.OIL_GRADE + "," + Constants.DENSITY + "," +
                    Constants.COMMENTS + "," + Constants.VESSEL_NO + "," + Constants.ENGINE_NO + ",Is_Data_Submitted) VALUES (@DOR,'" + rngRunningData.PortSea + "', @NoOfCylinders," +
                    "@TotEngHours, @CylinderRPM, @Power,@percentMCR, @percentS, @Catfines, @vanadium, @Consumption, @RelativeHumidity , " +
                    "@AmbTemp, @ScavAirTemp, @EngRoomTemp,@CylinderOilConsump, @Feedrate,'" + rngRunningData.SampleSentRCC + "',@NoOfTCInUse,@OilGrade,@Density,'" + rngRunningData.Comments + 
                    "',@VesselNo,@EngineNo,@IsDataSubmitted)";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(rngRunningData.DateOfReading, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@percentMCR", SqlDbType.Decimal).Value = rngRunningData.PercentMCR;
                cmd.Parameters.Add("@Feedrate", SqlDbType.Decimal).Value = rngRunningData.Federate;
                cmd.Parameters.Add("@NoOfCylinders", SqlDbType.Int).Value = rngRunningData.NoOfCylinders;
                cmd.Parameters.Add("@TotEngHours", SqlDbType.Decimal).Value = rngRunningData.TotEngineHours;
                cmd.Parameters.Add("@CylinderRPM", SqlDbType.Decimal).Value = rngRunningData.CylinderRPM;
                cmd.Parameters.Add("@Power", SqlDbType.Decimal).Value = rngRunningData.Power;
                cmd.Parameters.Add("@percentS", SqlDbType.Decimal).Value = rngRunningData.PercentS;
                cmd.Parameters.Add("@Catfines", SqlDbType.Decimal).Value = rngRunningData.Catfines;
                cmd.Parameters.Add("@vanadium", SqlDbType.Decimal).Value = rngRunningData.Vanadium;
                cmd.Parameters.Add("@Consumption", SqlDbType.Decimal).Value = rngRunningData.Consumption;
                cmd.Parameters.Add("@RelativeHumidity", SqlDbType.Decimal).Value = rngRunningData.RelativeHumidity;
                cmd.Parameters.Add("@AmbTemp", SqlDbType.Decimal).Value = rngRunningData.AmbTemp;
                cmd.Parameters.Add("@ScavAirTemp", SqlDbType.Decimal).Value = rngRunningData.ScavAirTemp;
                cmd.Parameters.Add("@EngRoomTemp", SqlDbType.Decimal).Value = rngRunningData.EngRoomTemp;
                cmd.Parameters.Add("@CylinderOilConsump", SqlDbType.Decimal).Value = rngRunningData.CylinderOilConsump;
                cmd.Parameters.Add("@NoOfTCInUse", SqlDbType.Int).Value = rngRunningData.NoOfTCInUse;
                #region Change to include Oil Grade and Density at sample date level
                cmd.Parameters.Add("@OilGrade", SqlDbType.NVarChar).Value = rngRunningData.OilGrade;
                cmd.Parameters.Add("@Density", SqlDbType.NVarChar).Value = rngRunningData.Density;
                #endregion
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = rngRunningData.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = rngRunningData.EngineNo;
                cmd.Parameters.Add("@IsDataSubmitted", SqlDbType.Int).Value = rngRunningData.IsDataSubmitted;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();

                rngRngData = GetRunningDataPerDate(rngRunningData.DateOfReading, rngRunningData.EngineNo, rngRunningData.VesselNo);
                if (rngRngData.Count() > 0)
                {
                    inUniqueId = rngRngData[0].UniqueId;
                }
            }
            catch (Exception ex)
            {
                inUniqueId = 0;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }
            return inUniqueId;
        }
        #endregion

        #region UpdateRunningData
        /// <summary>
        /// THis method updates the running data
        /// </summary>
        /// <param name="rngRunningData">the running data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateRunningData(RunningData rngRunningData)
        {
            int inUniqueId = 0;
            List<RunningData> rngRngData = new List<RunningData>();

            try
            {
                
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Running_Data SET " + 
                    //Constants.DATE_OF_READING + "='" +
                    //   rngRunningData.DateOfReading + "', " + 
                       Constants.PORTSEA + "='" +
                       rngRunningData.PortSea + "', " + Constants.NO_OF_CYLINDERS + "=@NoOfCylinders, " + Constants.TOT_ENGINE_HOURS + "=@TotEngHours, "
                       + Constants.CYLINDER_RPM + "=@CylinderRPM, " + Constants.POWER + "=@Power, " + Constants.PERCENT_MCR + "=@percentMCR, "
                       + Constants.PERCENT_S + "=@percentS, " + Constants.CATFINES + "=@Catfines, " + Constants.VANADIUM + "=@vanadium, "
                       + Constants.CONSUMPTION + "=@Consumption, " + Constants.REL_HUMIDITY + "=@RelativeHumidity, " + Constants.AMB_TEMP
                       + "=@AmbTemp, " + Constants.SCAV_AIR_TEMP + "=@ScavAirTemp, " + Constants.ENG_ROOM_TEMP + "=@EngRoomTemp, " +
                       Constants.CYLINDER_OIL_CONSUMP + "=@CylinderOilConsump, " + Constants.FEDERATE + "=@Feedrate, " + Constants.SAMPLE_SENT_RCC + "='" +
                       rngRunningData.SampleSentRCC + "', " + Constants.NO_OF_TC_IN_USE + "=@NoOfTCInUse, " + Constants.OIL_GRADE + "=@OilGrade, "
                       + Constants.DENSITY + "=@Density, " + Constants.COMMENTS + "='" +
                       rngRunningData.Comments +
                       "',Is_Data_Submitted= @IsDataSubmitted where Date_Of_Reading= @DOR AND Vessel_No = @VesselNo AND Engine_No = @EngNo";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(rngRunningData.DateOfReading, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = rngRunningData.VesselNo;
                cmd.Parameters.Add("@EngNo", SqlDbType.Int).Value = rngRunningData.EngineNo;
                cmd.Parameters.Add("@percentMCR", SqlDbType.Decimal).Value = rngRunningData.PercentMCR;
                cmd.Parameters.Add("@Feedrate", SqlDbType.Decimal).Value = rngRunningData.Federate;
                cmd.Parameters.Add("@NoOfCylinders", SqlDbType.Int).Value = rngRunningData.NoOfCylinders;
                cmd.Parameters.Add("@TotEngHours", SqlDbType.Decimal).Value = rngRunningData.TotEngineHours;
                cmd.Parameters.Add("@CylinderRPM", SqlDbType.Decimal).Value = rngRunningData.CylinderRPM;
                cmd.Parameters.Add("@Power", SqlDbType.Decimal).Value = rngRunningData.Power;
                cmd.Parameters.Add("@percentS", SqlDbType.Decimal).Value = rngRunningData.PercentS;
                cmd.Parameters.Add("@Catfines", SqlDbType.Decimal).Value = rngRunningData.Catfines;
                cmd.Parameters.Add("@vanadium", SqlDbType.Decimal).Value = rngRunningData.Vanadium;
                cmd.Parameters.Add("@Consumption", SqlDbType.Decimal).Value = rngRunningData.Consumption;
                cmd.Parameters.Add("@RelativeHumidity", SqlDbType.Decimal).Value = rngRunningData.RelativeHumidity;
                cmd.Parameters.Add("@AmbTemp", SqlDbType.Decimal).Value = rngRunningData.AmbTemp;
                cmd.Parameters.Add("@ScavAirTemp", SqlDbType.Decimal).Value = rngRunningData.ScavAirTemp;
                cmd.Parameters.Add("@EngRoomTemp", SqlDbType.Decimal).Value = rngRunningData.EngRoomTemp;
                cmd.Parameters.Add("@CylinderOilConsump", SqlDbType.Decimal).Value = rngRunningData.CylinderOilConsump;
                cmd.Parameters.Add("@NoOfTCInUse", SqlDbType.Int).Value = rngRunningData.NoOfTCInUse;
                cmd.Parameters.Add("@OilGrade", SqlDbType.NVarChar).Value = rngRunningData.OilGrade;
                cmd.Parameters.Add("@Density", SqlDbType.NVarChar).Value = rngRunningData.Density;
                cmd.Parameters.Add("@IsDataSubmitted", SqlDbType.Int).Value = rngRunningData.IsDataSubmitted;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();

                rngRngData = GetRunningDataPerDate(rngRunningData.DateOfReading, rngRunningData.EngineNo, rngRunningData.VesselNo);
                if (rngRngData.Count() > 0)
                {
                    inUniqueId = rngRngData[0].UniqueId;
                }
            }
            catch (Exception ex)
            {
                inUniqueId = 0;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return inUniqueId;
        }
        #endregion

        public int UpdateRunningDataForSubmission(int vesselNo, int EngineNo, string strDateFrom, string strDateTo)
        {
            int isSuccess = 0;

            try
            {

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Running_Data SET Is_Data_Submitted= 1 where Date_Of_Reading >= @startDate AND  Date_Of_Reading <= @endDate" + 
                " AND Vessel_No = @VesselNo AND Engine_No = @EngNo";
                cmd.Parameters.Add("@startDate", SqlDbType.DateTime).Value = Convert.ToDateTime(strDateFrom, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@endDate", SqlDbType.DateTime).Value = Convert.ToDateTime(strDateTo, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = vesselNo;
                cmd.Parameters.Add("@EngNo", SqlDbType.Int).Value = EngineNo;
                
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();

                isSuccess = 1;
            }
            catch (Exception ex)
            {
                isSuccess = 0;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return isSuccess;
        }

        #region SaveRunningData
        /// <summary>
        /// This method saves the running data either in insert mode or update mode
        /// </summary>
        /// <param name="rngRunningData">the running data to be saved</param>
        /// <returns>int with the updated/newly inserted unique id</returns>
        public int SaveRunningData(RunningData rngRunningData)
        {
            int inUniqueId = 0;

            try
            {
                
                List<RunningData> rngRngData = new List<RunningData>();
                rngRngData = GetRunningDataPerDate(rngRunningData.DateOfReading, rngRunningData.EngineNo, rngRunningData.VesselNo);
                if (rngRngData.Count() > 0)
                {
                    //update
                    //con.Open();
                    SqlCeCommand cmd = con.CreateCommand();
                    cmd.CommandText = "UPDATE Running_Data SET " + Constants.DATE_OF_READING + "='" +
                        rngRunningData.DateOfReading + "', " + Constants.PORTSEA + "='" +
                        rngRunningData.PortSea + "', " + Constants.NO_OF_CYLINDERS + "='" +
                        rngRunningData.NoOfCylinders + "', " + Constants.TOT_ENGINE_HOURS + "='" +
                        rngRunningData.TotEngineHours + "', " + Constants.CYLINDER_RPM + "='" +
                        rngRunningData.CylinderRPM + "', " + Constants.POWER + "='" +
                        rngRunningData.Power + "', " + Constants.PERCENT_MCR + "='" +
                        rngRunningData.PercentMCR + "', " + Constants.PERCENT_S + "='" +
                        rngRunningData.PercentS + "', " + Constants.CATFINES + "='" +
                        rngRunningData.Catfines + "', " + Constants.VANADIUM + "='" +
                        rngRunningData.Vanadium + "', " + Constants.CONSUMPTION + "='" +
                        rngRunningData.Consumption + "', " + Constants.REL_HUMIDITY + "='" +
                        rngRunningData.RelativeHumidity + "', " + Constants.AMB_TEMP + "='" +
                        rngRunningData.AmbTemp + "', " + Constants.SCAV_AIR_TEMP + "='" +
                        rngRunningData.ScavAirTemp + "', " + Constants.ENG_ROOM_TEMP + "='" +
                        rngRunningData.EngRoomTemp + "', " + Constants.CYLINDER_OIL_CONSUMP + "='" +
                        rngRunningData.CylinderOilConsump + "', " + Constants.FEDERATE + "='" +
                        rngRunningData.Federate + "', " + Constants.SAMPLE_SENT_RCC + "='" +
                        rngRunningData.SampleSentRCC + "', " + Constants.NO_OF_TC_IN_USE + "='" +
                        rngRunningData.NoOfTCInUse + "', " + Constants.COMMENTS + "='" +
                        rngRunningData.Comments +
                        "' where Date_Of_Reading='" + rngRunningData.DateOfReading + "' AND Vessel_No =" + rngRunningData.VesselNo + " AND Engine_No = " + rngRunningData.EngineNo;
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    //insert
                    //con.Open();
                    SqlCeCommand cmd = con.CreateCommand();
                    cmd.CommandText = "INSERT INTO Running_Data (" + Constants.DATE_OF_READING + "," +
                        Constants.PORTSEA + "," + Constants.NO_OF_CYLINDERS + "," + Constants.TOT_ENGINE_HOURS + "," +
                        Constants.CYLINDER_RPM + "," + Constants.POWER + "," + Constants.PERCENT_MCR + "," +
                        Constants.PERCENT_S + "," + Constants.CATFINES + "," + Constants.VANADIUM + "," +
                        Constants.CONSUMPTION + "," + Constants.REL_HUMIDITY + "," + Constants.AMB_TEMP + "," +
                        Constants.SCAV_AIR_TEMP + "," + Constants.ENG_ROOM_TEMP + "," + Constants.CYLINDER_OIL_CONSUMP + "," +
                        Constants.FEDERATE + "," + Constants.SAMPLE_SENT_RCC + "," + Constants.NO_OF_TC_IN_USE + "," +
                        Constants.COMMENTS + "," + Constants.VESSEL_NO + "," + Constants.ENGINE_NO + ") VALUES ('" +
                        rngRunningData.DateOfReading + "',' " + rngRunningData.PortSea + "', " +
                        rngRunningData.NoOfCylinders + ", " + rngRunningData.TotEngineHours + ", " +
                        rngRunningData.CylinderRPM + ", " + rngRunningData.Power + ", " + rngRunningData.PercentMCR + ", " +
                        rngRunningData.PercentS + ", " + rngRunningData.Catfines + ", " + rngRunningData.Vanadium + ", " +
                        rngRunningData.Consumption + ", " + rngRunningData.RelativeHumidity + ", " +
                        rngRunningData.AmbTemp + ", " + rngRunningData.ScavAirTemp + ", " + rngRunningData.EngRoomTemp + ", " +
                        rngRunningData.CylinderOilConsump + ", " + rngRunningData.Federate + ",' " + rngRunningData.SampleSentRCC + "', " +
                        rngRunningData.NoOfTCInUse + ",' " + rngRunningData.Comments + "'," + rngRunningData.VesselNo + "," + rngRunningData.EngineNo + ")";
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                rngRngData = new List<RunningData>();
                rngRngData = GetRunningDataPerDate(rngRunningData.DateOfReading, rngRunningData.EngineNo, rngRunningData.VesselNo);
                if (rngRngData.Count() > 0)
                {
                    inUniqueId = rngRngData[0].UniqueId;
                }
            }
            catch (Exception ex)
            {
                inUniqueId = 0;
                Common.WriteTextFile(ex, Common.strUser);
            }
            return inUniqueId;
        }
        #endregion

        #region InsertCylinderData
        /// <summary>
        /// This method inserts new cylinder data
        /// </summary>
        /// <param name="cynData">the cylinder data to be inserted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertCylinderData(CylinderData cynData)
        {
            int intStatus = 0;

            try
            {
                
                //insert
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Cylinder_Data (" + Constants.UNIQUE_ID + "," +
                    Constants.CYLINDER_NUMBER + "," + Constants.AA_READING + "," + Constants.PMAX + "," +
                    Constants.FUEL_INDEX + "," + Constants.COOLING_WATER_TEMP + "," + Constants.LINEAR_WALL_TEMP_MIN + "," +
                    Constants.LINEAR_WALL_TEMP_MAX + "," + Constants.FEDERATE_SETPOINT + "," + Constants.BN_MEASURED_ONBOARD + "," + Constants.VESSEL_NO + "," + Constants.ENGINE_NO
                   + "," + Constants.MAGNETIC_IRON + "," + Constants.CORROSIVE_IRON 
                   + ") VALUES (@UniqueID ,@CylinderNumber , @AAReading, @PMax , @FuelIndex , @CoolingWaterTemp , @LinearWallTempMin, " +
                    "@LinearWallTempMax,@FederateSetPoint, @BNMeasuredOnboard,@VesselNo,@EngineNo,@MagneticIron, @CorrosiveIron)";
                cmd.Parameters.Add("@UniqueID", SqlDbType.BigInt).Value = cynData.UniqueID;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = cynData.CylinderNumber;
                cmd.Parameters.Add("@AAReading", SqlDbType.Int).Value = cynData.AAReading;
                cmd.Parameters.Add("@PMax", SqlDbType.Decimal).Value = cynData.PMax;
                cmd.Parameters.Add("@FuelIndex", SqlDbType.Decimal).Value = cynData.FuelIndex;
                cmd.Parameters.Add("@CoolingWaterTemp", SqlDbType.Decimal).Value = cynData.CoolingWaterTemp;
                cmd.Parameters.Add("@LinearWallTempMin", SqlDbType.Decimal).Value = cynData.LinearWallTempMin;
                cmd.Parameters.Add("@LinearWallTempMax", SqlDbType.Decimal).Value = cynData.LinearWallTempMax;
                cmd.Parameters.Add("@FederateSetPoint", SqlDbType.Decimal).Value = cynData.FederateSetPoint;
                cmd.Parameters.Add("@BNMeasuredOnboard", SqlDbType.Decimal).Value = cynData.BNMeasuredOnboard;
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = cynData.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = cynData.EngineNo;
                #region Changes for Including Magnetic and Corrosive Iron
                cmd.Parameters.Add("@MagneticIron", SqlDbType.Int).Value = cynData.MagneticIron;
                cmd.Parameters.Add("@CorrosiveIron", SqlDbType.Int).Value = cynData.CorrosiveIron;
                #endregion
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region UpdateCylinderData
        /// <summary>
        /// This method updates the cylinder data
        /// </summary>
        /// <param name="cynData">the cylinder data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateCylinderData(CylinderData cynData)
        {
            int intStatus = 0;

            try
            {
                
                //update
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Cylinder_Data SET " + Constants.AA_READING + "=@AAReading, " + Constants.PMAX + "=@PMax, "
                    + Constants.FUEL_INDEX + "=@FuelIndex, " + Constants.COOLING_WATER_TEMP + "=@CoolingWaterTemp, "
                    + Constants.LINEAR_WALL_TEMP_MIN + "=@LinearWallTempMin, " + Constants.LINEAR_WALL_TEMP_MAX + "=@LinearWallTempMax, "
                    + Constants.FEDERATE_SETPOINT + "=@FederateSetPoint, " + Constants.BN_MEASURED_ONBOARD + "=@BNMeasuredOnboard,"
                     + Constants.MAGNETIC_IRON + "=@MagneticIron, " + Constants.CORROSIVE_IRON + "=@CorrosiveIron" 
                    + " where Unique_Id=@UniqueID AND Cylinder_Number = @CylinderNumber AND Vessel_No = @VesselNo AND Engine_No = @EngineNo";
                cmd.Parameters.Add("@UniqueID", SqlDbType.BigInt).Value = cynData.UniqueID;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = cynData.CylinderNumber;
                cmd.Parameters.Add("@AAReading", SqlDbType.Int).Value = cynData.AAReading;
                cmd.Parameters.Add("@PMax", SqlDbType.Decimal).Value = cynData.PMax;
                cmd.Parameters.Add("@FuelIndex", SqlDbType.Decimal).Value = cynData.FuelIndex;
                cmd.Parameters.Add("@CoolingWaterTemp", SqlDbType.Decimal).Value = cynData.CoolingWaterTemp;
                cmd.Parameters.Add("@LinearWallTempMin", SqlDbType.Decimal).Value = cynData.LinearWallTempMin;
                cmd.Parameters.Add("@LinearWallTempMax", SqlDbType.Decimal).Value = cynData.LinearWallTempMax;
                cmd.Parameters.Add("@FederateSetPoint", SqlDbType.Decimal).Value = cynData.FederateSetPoint;
                cmd.Parameters.Add("@BNMeasuredOnboard", SqlDbType.Decimal).Value = cynData.BNMeasuredOnboard;
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = cynData.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = cynData.EngineNo;
                #region Changes for Including Magnetic and Corrosive Iron
                cmd.Parameters.Add("@MagneticIron", SqlDbType.Int).Value = cynData.MagneticIron;
                cmd.Parameters.Add("@CorrosiveIron", SqlDbType.Int).Value = cynData.CorrosiveIron;
                #endregion
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region GetBunkerInformation
        /// <summary>
        /// This methods gets existing bunker information for the given vessel no. and engine no.
        /// </summary>
        /// <param name="strVesselNo">The vessel no. for which bunker information needs to be fetched</param>
        /// <param name="engNo">The engine no. for which bunker information needs to be fetched</param>
        /// <returns>The list of bunker information for the given parameters</returns>
        public List<BunkerInformation> GetBunkerInformation(int strVesselNo, int engNo)
        {
            List<BunkerInformation> lstBunkerInfo = new List<BunkerInformation>();
            BunkerInformation bunkerInfo = new BunkerInformation();
            DataSet dsBunkerData = new DataSet();
            try
            {
                
                SqlCeDataAdapter sdaBunkerData = new SqlCeDataAdapter("select * from Bunker_Information where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'", con);
                sdaBunkerData.Fill(dsBunkerData);

                if (dsBunkerData.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsBunkerData.Tables[0].Rows)
                    {
                        bunkerInfo = new BunkerInformation();
                        bunkerInfo.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        bunkerInfo.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        bunkerInfo.QuantityBunkered = dr[Constants.QUANTITY_BUNKERED].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.QUANTITY_BUNKERED].ToString());
                        bunkerInfo.BDNSContent = dr[Constants.BDNS_CONTENT].ToString() == string.Empty ? 0.000 : Convert.ToDouble(dr[Constants.BDNS_CONTENT].ToString());
                        bunkerInfo.DateBunkered = dr[Constants.DATE_BUNKERED].ToString() == string.Empty ? string.Empty : dr[Constants.DATE_BUNKERED].ToString();

                        lstBunkerInfo.Add(bunkerInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return lstBunkerInfo;
        }
        #endregion

        #region InsertBunkerInformation
        /// <summary>
        /// This method inserts new bunker information
        /// </summary>
        /// <param name="bnkInfo">The bunker information to be inserted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertBunkerInformation(BunkerInformation bnkInfo)
        {
            int intStatus = 0;

            try
            {
            
                
                //insert
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Bunker_Information (" + Constants.VESSEL_NO + "," +
                    Constants.DATE_BUNKERED + "," + Constants.QUANTITY_BUNKERED + "," + Constants.BDNS_CONTENT + "," +
                    Constants.ENGINE_NO + ") VALUES (@VesselNo , @DOR , @QuantityBunkered, @BDNSContent ,@EngineNo )";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(bnkInfo.DateBunkered, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = bnkInfo.VesselNo;
                cmd.Parameters.Add("@QuantityBunkered", SqlDbType.Decimal).Value = bnkInfo.QuantityBunkered;
                cmd.Parameters.Add("@BDNSContent", SqlDbType.Decimal).Value = bnkInfo.BDNSContent;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = bnkInfo.EngineNo;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region UpdateBunkerInformation
        /// <summary>
        /// This method updates the bunker information
        /// </summary>
        /// <param name="bnkInfo">the bunker to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateBunkerInformation(BunkerInformation bnkInfo)
        {
            int intStatus = 0;

            try
            {
                
                //update
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Bunker_Information SET " + Constants.QUANTITY_BUNKERED + "=@QuantityBunkered, " + Constants.BDNS_CONTENT
                    + "=@BDNSContent where Vessel_No=@VesselNo AND Engine_No = @EngineNo AND Date_Bunkered = @DOR";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(bnkInfo.DateBunkered, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = bnkInfo.VesselNo;
                cmd.Parameters.Add("@QuantityBunkered", SqlDbType.Decimal).Value = bnkInfo.QuantityBunkered;
                cmd.Parameters.Add("@BDNSContent", SqlDbType.Decimal).Value = bnkInfo.BDNSContent;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = bnkInfo.EngineNo;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }


            return intStatus;
        }
        #endregion

        #region GetCylinderInspection
        /// <summary>
        /// This method gives the cylinder inspection information for the given vessel no. and engine no.
        /// </summary>
        /// <param name="strVesselNo">Vessel no. for which cylinder information needs to be fetched</param>
        /// <param name="engNo">Engine no. for which cylinder information needs to be fetched</param>
        /// <returns>The list of cylinder inspection data</returns>
        public List<CylinderInspection> GetCylinderInspection(int strVesselNo, int engNo)
        {
            List<CylinderInspection> lstCylinderInspection = new List<CylinderInspection>();
            CylinderInspection cylInspection = new CylinderInspection();
            DataSet dsCylInspection = new DataSet();

            try
            {
                
                SqlCeDataAdapter sdaCylInspection = new SqlCeDataAdapter("select * from Cylinder_Inspection where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'", con);
                sdaCylInspection.Fill(dsCylInspection);

                if (dsCylInspection.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsCylInspection.Tables[0].Rows)
                    {
                        cylInspection = new CylinderInspection();
                        cylInspection.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        cylInspection.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        cylInspection.CylinderNumber = dr[Constants.CYLINDER_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NO].ToString());
                        cylInspection.DateOfInspection = dr[Constants.DATE_OF_INSPECTION].ToString() == string.Empty ? string.Empty : dr[Constants.DATE_OF_INSPECTION].ToString();

                        lstCylinderInspection.Add(cylInspection);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return lstCylinderInspection;
        }
        #endregion

        #region InsertCylinderInspection
        /// <summary>
        /// This method inserts the cylinder inspection data
        /// </summary>
        /// <param name="cylInfo">The cylinder inspection data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertCylinderInspection(CylinderInspection cylInfo)
        {
            int intStatus = 0;

            try
            {
                
                //insert
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Cylinder_Inspection (" + Constants.VESSEL_NO + "," +
                    Constants.ENGINE_NO + "," + Constants.CYLINDER_NO + "," + Constants.DATE_OF_INSPECTION + ") VALUES (@VesselNo ,@EngineNo , @CylinderNumber, @DOR)";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(cylInfo.DateOfInspection, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = cylInfo.VesselNo;
                cmd.Parameters.Add ("@EngineNo", SqlDbType.Int).Value = cylInfo.EngineNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = cylInfo.CylinderNumber;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region UpdateCylinderInspection
        /// <summary>
        /// This method updates the cylinder inspection data
        /// </summary>
        /// <param name="cylInfo">The cylinder inspection data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateCylinderInspection(CylinderInspection cylInfo)
        {
            int intStatus = 0;

            try
            {
                //update
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Cylinder_Inspection SET " + Constants.DATE_OF_INSPECTION + "= @DOR where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND Cylinder_No = @CylinderNumber";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = cylInfo.DateOfInspection == "" ? System.DateTime.MaxValue : Convert.ToDateTime(cylInfo.DateOfInspection, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = cylInfo.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = cylInfo.EngineNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = cylInfo.CylinderNumber;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region DeleteCylinderInspection
        /// <summary>
        /// This method updates the cylinder inspection data
        /// </summary>
        /// <param name="cylInfo">The cylinder inspection data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int DeleteSupportInformation(int inVesselNo, int inEngineNo,string strDOR)
        {
            int intStatus = 0;

            try
            {
                //update
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "DELETE FROM Cylinder_Inspection where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND DATE_OF_INSPECTION = @DOR "
                    + "; DELETE FROM Bunker_Information where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND DATE_BUNKERED = @DOR "
                    + "; DELETE FROM Linear_Wear where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND DATE_MEASURED = @DOR "
                    + "; DELETE FROM Running_Hour where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND READING_DATE = @DOR "
                    + "; DELETE FROM Support_Information where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND READING_DATE = @DOR ";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(strDOR, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = inVesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = inEngineNo;

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        public int DeleteCylinderInspection(CylinderInspection cylInspection)
        {
            int intStatus = 0;

            try
            {
                //update
                con.Open();
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "DELETE FROM Cylinder_Inspection where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND CYLINDER_NO = @CylNo AND DATE_OF_INSPECTION = @DOR ";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(cylInspection.DateOfInspection, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = cylInspection.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = cylInspection.EngineNo;
                cmd.Parameters.Add("@CylNo", SqlDbType.Int).Value = cylInspection.CylinderNumber;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }

        #region GetRunningHour
        /// <summary>
        /// This method get the running hour data for the given vessel no. and engine no.
        /// </summary>
        /// <param name="strVesselNo">The vessel no. for which running hour data needs to be fetched</param>
        /// <param name="engNo">The engine no. for which running hour data needs to be fetched</param>
        /// <returns>The list of running hour data for the given parameters</returns>
        public List<RunningHour> GetRunningHour(int strVesselNo, int engNo)
        {
            List<RunningHour> lstRunningHour = new List<RunningHour>();
            RunningHour rngHour = new RunningHour();
            DataSet dsRngHour= new DataSet();
            try
            {
                SqlCeDataAdapter sdaRngHour = new SqlCeDataAdapter("select * from Running_Hour where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'", con);
                sdaRngHour.Fill(dsRngHour);

                if (dsRngHour.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsRngHour.Tables[0].Rows)
                    {
                        rngHour = new RunningHour();
                        rngHour.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        rngHour.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        rngHour.CylinderNumber = dr[Constants.CYLINDER_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NO].ToString());
                        rngHour.ReadingDate = dr[Constants.READING_DATE].ToString() == string.Empty ? string.Empty : dr[Constants.READING_DATE].ToString();
                        rngHour.Liner = dr[Constants.LINEAR_DB].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.LINEAR_DB].ToString());
                        rngHour.Prings = dr[Constants.PRINGS_DB].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PRINGS_DB].ToString());
                        rngHour.PCrown = dr[Constants.PCROWN_DB].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PCROWN_DB].ToString());

                        lstRunningHour.Add(rngHour);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return lstRunningHour;
        }
        #endregion

        #region InsertRunningHour
        /// <summary>
        /// This method inserts the running hour data
        /// </summary>
        /// <param name="rngHourInfo">The running hour data to be inserted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertRunningHour(RunningHour rngHourInfo)
        {
            int intStatus = 0;

            try
            {
                //insert
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Running_Hour (" + Constants.VESSEL_NO + "," +
                    Constants.CYLINDER_NO + "," + Constants.READING_DATE + "," + Constants.LINEAR_DB + "," +
                    Constants.PRINGS_DB + "," + Constants.PCROWN_DB + "," +
                    Constants.ENGINE_NO + ") VALUES (@VesselNo,@CylinderNumber, @DOR, @Linear, @Prings , @PCrown , @EngineNo )";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(rngHourInfo.ReadingDate, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = rngHourInfo.VesselNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = rngHourInfo.CylinderNumber;
                cmd.Parameters.Add("@Linear", SqlDbType.Decimal).Value = rngHourInfo.Liner;
                cmd.Parameters.Add("@Prings", SqlDbType.Decimal).Value = rngHourInfo.Prings;
                cmd.Parameters.Add("@PCrown", SqlDbType.Decimal).Value = rngHourInfo.PCrown;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = rngHourInfo.EngineNo;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }


            return intStatus;
        }
        #endregion

        #region UpdateRunningHour
        /// <summary>
        /// THis method updates the running hour data
        /// </summary>
        /// <param name="rngHourInfo">The running hour data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateRunningHour(RunningHour rngHourInfo)
        {
            int intStatus = 0;

            try
            {
                //Update
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Running_Hour SET " + Constants.LINEAR + "=@Linear ," + Constants.PRINGS + "=@Prings ," + Constants.PCROWN + "=@PCrown" +
                    " where Vessel_No=@VesselNo AND Engine_No = @EngineNo AND Cylinder_No = @CylinderNumber AND Reading_Date = @DOR";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(rngHourInfo.ReadingDate, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = rngHourInfo.VesselNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = rngHourInfo.CylinderNumber;
                cmd.Parameters.Add("@Linear", SqlDbType.Decimal).Value = rngHourInfo.Liner;
                cmd.Parameters.Add("@Prings", SqlDbType.Decimal).Value = rngHourInfo.Prings;
                cmd.Parameters.Add("@PCrown", SqlDbType.Decimal).Value = rngHourInfo.PCrown;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = rngHourInfo.EngineNo;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch(Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region GetLinearWear
        /// <summary>
        /// This method gets the linear wear data for the given parameters
        /// </summary>
        /// <param name="strVesselNo">the vessel no. for which linear wear data needs to be fetched.</param>
        /// <param name="engNo">the engine no. for which linear wear data needs to be fetched.</param>
        /// <returns>The list of linear wear data for the given parameters</returns>
        public List<LinearWear> GetLinearWear(int strVesselNo, int engNo)
        {
            List<LinearWear> lstLinearWear = new List<LinearWear>();
            LinearWear linearWear = new LinearWear();
            DataSet dsLinearWear = new DataSet();
            SqlCeDataAdapter sdaLinearWear = new SqlCeDataAdapter("select * from Linear_Wear where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "'", con);
            sdaLinearWear.Fill(dsLinearWear);

            if (dsLinearWear.Tables.Count > 0)
            {
                foreach (DataRow dr in dsLinearWear.Tables[0].Rows)
                {
                    linearWear = new LinearWear();
                    linearWear.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                    linearWear.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                    linearWear.CylinderNumber = dr[Constants.CYLINDER_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NO].ToString());
                    linearWear.DateMeasured = dr[Constants.DATE_MEASURED].ToString() == string.Empty ? string.Empty : dr[Constants.DATE_MEASURED].ToString();
                    linearWear.Forward = dr[Constants.FORWARD].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.FORWARD].ToString());
                    linearWear.PortStarBoard = dr[Constants.PORT_STARBOARD].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PORT_STARBOARD].ToString());

                    lstLinearWear.Add(linearWear);
                }
            }

            return lstLinearWear;
        }
        #endregion

        #region InsertLinearWear
        /// <summary>
        /// This method inserts the linear wear data
        /// </summary>
        /// <param name="linearWearInfo">The linear wear data to be inserted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int InsertLinearWear(LinearWear linearWearInfo)
        {
            int intStatus = 0;

            try
            {
                //insert
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Linear_Wear (" + Constants.VESSEL_NO + "," + Constants.ENGINE_NO + "," +
                    Constants.CYLINDER_NO + "," + Constants.DATE_MEASURED + "," + Constants.FORWARD + "," +
                    Constants.PORT_STARBOARD + ") VALUES (@VesselNo,@EngineNo,@CylinderNumber,@DOR, @Forward,@PortStarBoard)";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(linearWearInfo.DateMeasured, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = linearWearInfo.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = linearWearInfo.EngineNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = linearWearInfo.CylinderNumber;
                cmd.Parameters.Add("@Forward", SqlDbType.Decimal).Value = linearWearInfo.Forward;
                cmd.Parameters.Add("@PortStarBoard", SqlDbType.Decimal).Value = linearWearInfo.PortStarBoard;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                Common.WriteTextFile(ex, Common.strUser);
                intStatus = 1;
            }

            return intStatus;
        }
        #endregion

        #region UpdateLinearWear
        /// <summary>
        /// THis method updates the linear wear data
        /// </summary>
        /// <param name="linearWearInfo">the linear wear data to be updated</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int UpdateLinearWear(LinearWear linearWearInfo)
        {
            int intStatus = 0;

            try
            {
                //update
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "UPDATE Linear_Wear SET " + Constants.FORWARD + "=@Forward," + Constants.PORT_STARBOARD + "=@PortStarBoard " +
                    " where Vessel_No=@VesselNo  AND Engine_No = @EngineNo AND Cylinder_No = @CylinderNumber  AND Date_Measured = @DOR";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(linearWearInfo.DateMeasured, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = linearWearInfo.VesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = linearWearInfo.EngineNo;
                cmd.Parameters.Add("@CylinderNumber", SqlDbType.Int).Value = linearWearInfo.CylinderNumber;
                cmd.Parameters.Add("@Forward", SqlDbType.Decimal).Value = linearWearInfo.Forward;
                cmd.Parameters.Add("@PortStarBoard", SqlDbType.Decimal).Value = linearWearInfo.PortStarBoard;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }

            return intStatus;
        }
        #endregion

        #region DeleteProjectData
        /// <summary>
        /// This method deletes the project data
        /// </summary>
        /// <param name="inVesselNo">The vessel no. for which data needs to be deleted</param>
        /// <param name="inEngineNo">The engine no. for which data needs to be deleted</param>
        /// <returns>int indicating whether the operation was successful or not.
        ///  0 = Success
        ///  1 = Failure </returns>
        public int DeleteProjectData(int inVesselNo, int inEngineNo)
        {
            int intStatus = 0;

            try
            {
                //delete
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "DELETE FROM Bunker_Information WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo +
                    "; DELETE FROM Running_Data WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo +
                    "; DELETE FROM Cylinder_Inspection WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo +
                "; DELETE FROM Linear_Wear WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo
                + "; DELETE FROM Running_Hour WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo
                + "; DELETE FROM Cylinder_Data WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo
                + "; DELETE FROM Vessel_Information WHERE Vessel_No =" + inVesselNo + " AND Engine_No=" + inEngineNo;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }
            return intStatus;
        }

        public int DeleteLogBookDetail(int inVesselNo, int inEngineNo, string strDOR, int uniqueID)
        {
            int intStatus = 0;

            try
            {
                //delete
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "DELETE FROM Running_Data where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND Date_Of_Reading = @DOR "
                + "; DELETE FROM Cylinder_Data where Vessel_No=@VesselNo AND Engine_No = @EngineNo" +
                    " AND UNIQUE_ID = @UniqueID ";
                cmd.Parameters.Add("@DOR", SqlDbType.DateTime).Value = Convert.ToDateTime(strDOR, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = inVesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = inEngineNo;
                cmd.Parameters.Add("@UniqueID", SqlDbType.Int).Value = uniqueID;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                intStatus = 1;
                Common.WriteTextFile(ex, Common.strUser);
                con.Close();
            }
            return intStatus;
        }
        #endregion

        public int InsertIntoSupportInformation(int vesselNo, int engineNo, string dateOfReading)
        {
            int intStatus = 0;

            try
            {
                //insert
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                SqlCeCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO Support_Information (" + Constants.VESSEL_NO + "," + Constants.ENGINE_NO + ",Reading_Date" 
                    + ") VALUES (@VesselNo,@EngineNo,@DateOfReading)";
                cmd.Parameters.Add("@DateOfReading", SqlDbType.DateTime).Value = Convert.ToDateTime(dateOfReading, CultureInfo.CurrentCulture);
                cmd.Parameters.Add("@VesselNo", SqlDbType.Int).Value = vesselNo;
                cmd.Parameters.Add("@EngineNo", SqlDbType.Int).Value = engineNo;

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                Common.WriteTextFile(ex, Common.strUser);
                intStatus = 1;
            }

            return intStatus;
        }

        public List<SupportInformation> GetSupportInformation(int strVesselNo, int engNo)
        {
            List<SupportInformation> lstSupportInfo = new List<SupportInformation>();
            SupportInformation supportInfo = new SupportInformation();
            DataSet dsSupportInfo = new DataSet();
            try
            {

                SqlCeDataAdapter sdaBunkerData = new SqlCeDataAdapter("select * from Support_Information where Vessel_No = '" + strVesselNo.ToString() + "' AND Engine_No ='" + engNo.ToString() + "' ORDER BY Reading_Date", con);
                sdaBunkerData.Fill(dsSupportInfo);

                if (dsSupportInfo.Tables.Count > 0)
                {
                    foreach (DataRow dr in dsSupportInfo.Tables[0].Rows)
                    {
                        supportInfo = new SupportInformation();
                        supportInfo.VesselNo = dr[Constants.VESSEL_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.VESSEL_NO].ToString());
                        supportInfo.EngineNo = dr[Constants.ENGINE_NO].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.ENGINE_NO].ToString());
                        supportInfo.DateOfReading = dr["Reading_Date"].ToString() == string.Empty ? string.Empty : dr["Reading_Date"].ToString();
                        
                        lstSupportInfo.Add(supportInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return lstSupportInfo;
        }

        public bool CheckAndUpgradeDB()
        {
            bool isSuccess = false;
            string tableName = "DB_Version";

            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            try
            {
                SqlCeCommand cmd = con.CreateCommand();
                var sql = string.Format(
                    "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = '{0}'",
                     tableName);
                cmd.CommandText = sql;
                var count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {
                    //To be used in later releases to update DB schema
                    var maxVerionSQL = string.Format("SELECT MAX(Version_No) FROM DB_Version");
                    cmd = new SqlCeCommand();
                    cmd = con.CreateCommand();

                    cmd.CommandText = maxVerionSQL;
                    var VersionNo = Convert.ToDouble(cmd.ExecuteScalar());

                    //if version no. is 1.0, add columns oil grade and density in running hour instead of vessel_information
                    if (VersionNo == 1.0)
                    {
                        cmd = new SqlCeCommand();
                        cmd = con.CreateCommand();

                        cmd.CommandText = "ALTER TABLE Running_Data ADD COLUMN Oil_Grade NVARCHAR(100) NULL; ALTER TABLE Running_Data ADD COLUMN Density NVARCHAR(100) NULL;";
                        cmd.ExecuteNonQuery();

                        //Increment the version no.
                        SqlCeCommand cmdInsert = con.CreateCommand();
                        cmdInsert.CommandText = "INSERT INTO DB_Version (Version_No,Updated_At) VALUES (@VersionNo,@Updated_At)";
                        cmdInsert.Parameters.Add("@Updated_At", SqlDbType.DateTime).Value = Convert.ToDateTime(System.DateTime.Now, CultureInfo.CurrentCulture);
                        cmdInsert.Parameters.Add("@VersionNo", SqlDbType.NVarChar).Value = "1.1";

                        cmdInsert.CommandType = CommandType.Text;
                        cmdInsert.ExecuteNonQuery();
                        VersionNo = 1.1;
                    }

                    #region Changes for Including Magnetic and Corrosive Iron
                    //if version no. is 1.1, add columns magnetic iron and corrosive iron for cylinder data
                    if (VersionNo == 1.1)
                    {
                        cmd = new SqlCeCommand();
                        cmd = con.CreateCommand();

                        cmd.CommandText = "ALTER TABLE Cylinder_Data ADD COLUMN Magnetic_Iron INT NULL; ALTER TABLE Cylinder_Data ADD COLUMN Corrosive_Iron INT NULL;";
                        cmd.ExecuteNonQuery();

                        //Increment the version no.
                        SqlCeCommand cmdInsert = con.CreateCommand();
                        cmdInsert.CommandText = "INSERT INTO DB_Version (Version_No,Updated_At) VALUES (@VersionNo,@Updated_At)";
                        cmdInsert.Parameters.Add("@Updated_At", SqlDbType.DateTime).Value = Convert.ToDateTime(System.DateTime.Now, CultureInfo.CurrentCulture);
                        cmdInsert.Parameters.Add("@VersionNo", SqlDbType.NVarChar).Value = "1.2";

                        cmdInsert.CommandType = CommandType.Text;
                        cmdInsert.ExecuteNonQuery();
                    }
                    #endregion


                }
                else
                {
                    //Create a table to hold version information
                    SqlCeCommand cmdCreateTable = con.CreateCommand();
                    cmdCreateTable.CommandText = "CREATE TABLE DB_Version (Version_No nvarchar(50) NOT NULL, Updated_At datetime)";
                    cmdCreateTable.ExecuteNonQuery();

                    SqlCeCommand cmdInsert = con.CreateCommand();
                    cmdInsert.CommandText = "INSERT INTO DB_Version (Version_No,Updated_At) VALUES (@VersionNo,@Updated_At)";
                    cmdInsert.Parameters.Add("@Updated_At", SqlDbType.DateTime).Value = Convert.ToDateTime(System.DateTime.Now, CultureInfo.CurrentCulture);
                    cmdInsert.Parameters.Add("@VersionNo", SqlDbType.NVarChar).Value = "1.0";

                    //Make changes for version 1.1
                    cmdInsert.CommandType = CommandType.Text;
                    cmdInsert.ExecuteNonQuery();

                    cmd = con.CreateCommand();

                    cmd.CommandText = "ALTER TABLE Running_Data ADD COLUMN Oil_Grade NVARCHAR(100) NULL; ALTER TABLE Running_Data ADD COLUMN Density NVARCHAR(100) NULL;";
                    cmd.ExecuteNonQuery();

                    //Increment the version no.
                    cmdInsert = con.CreateCommand();
                    cmdInsert.CommandText = "INSERT INTO DB_Version (Version_No,Updated_At) VALUES (@VersionNo,@Updated_At)";
                    cmdInsert.Parameters.Add("@Updated_At", SqlDbType.DateTime).Value = Convert.ToDateTime(System.DateTime.Now, CultureInfo.CurrentCulture);
                    cmdInsert.Parameters.Add("@VersionNo", SqlDbType.NVarChar).Value = "1.1";

                    cmdInsert.CommandType = CommandType.Text;
                    cmdInsert.ExecuteNonQuery();

                    #region Changes for Including Magnetic and Corrosive Iron
                    //Make changes for version 1.2
                    cmd = con.CreateCommand();

                    cmd.CommandText = "ALTER TABLE Cylinder_Data ADD COLUMN Magnetic_Iron INT NULL; ALTER TABLE Cylinder_Data ADD COLUMN Corrosive_Iron INT NULL;";
                    cmd.ExecuteNonQuery();

                    //Increment the version no.
                    cmdInsert = con.CreateCommand();
                    cmdInsert.CommandText = "INSERT INTO DB_Version (Version_No,Updated_At) VALUES (@VersionNo,@Updated_At)";
                    cmdInsert.Parameters.Add("@Updated_At", SqlDbType.DateTime).Value = Convert.ToDateTime(System.DateTime.Now, CultureInfo.CurrentCulture);
                    cmdInsert.Parameters.Add("@VersionNo", SqlDbType.NVarChar).Value = "1.2";

                    cmdInsert.CommandType = CommandType.Text;
                    cmdInsert.ExecuteNonQuery();
                    #endregion

                }
                con.Close();

            }
            catch (Exception ex)
            {
                con.Close();
                Common.WriteTextFile(ex, Common.strUser);
            }

            return isSuccess;
        }

        public string GetDBVersionDetails()
        {
            string UpdatedAt = string.Empty;
             if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
             try
             {
                 SqlCeCommand cmd = con.CreateCommand();
                 var sql = string.Format(
                     "SELECT TOP 1 Updated_At FROM DB_Version ORDER BY Version_No DESC");
                 cmd.CommandText = sql;
                 var up = Convert.ToString(cmd.ExecuteScalar());
                 UpdatedAt = up;

                 con.Close();
             }
             catch (Exception ex)
             {
                 con.Close();
                 Common.WriteTextFile(ex, Common.strUser);
             }

             return UpdatedAt;
        }
    }
}
