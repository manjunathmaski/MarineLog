﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class LinearWear
    {
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public int CylinderNumber { get; set; }
        public string DateMeasured { get; set; }
        public double Forward { get; set; }
        public double PortStarBoard { get; set; }
    }
}
