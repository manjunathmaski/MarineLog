﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MLBCaptureVesselData;


namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class VesselDataForSubmission
    {
        public VesselInfoDataEntity CoverPage { get; set; }

        public List<RunningDataForSubmission> LogBookDetail { get; set; }
        public List<BunkerInformation> BunkerInfoForSubmission { get; set; }
        public List<CylinderInspection> CylInspecForSubmission { get; set; }
        public List<LinearWear> LinearWearForSubmission { get; set; }
        public List<RunningHour> RunningHourData { get; set; }
    }
}
