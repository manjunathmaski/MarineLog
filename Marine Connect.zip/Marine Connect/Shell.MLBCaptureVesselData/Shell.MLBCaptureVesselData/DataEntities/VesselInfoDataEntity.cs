﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MLBCaptureVesselData
{
    [Serializable]
    public class VesselInfoDataEntity
    {
        public int VesselNo { get; set; }
        public string CompanyName { get; set; }
        public  string  NoOfVessels { get; set; }
        public  string  CustomerContact { get; set; }
        public  string  Address { get; set; }
        public  string  Email { get; set; }
        public  string  Telephone { get; set; }
        public  string  SMPContactName { get; set; }
        public  string  StartDateOfProj { get; set; }
        public  string  TargetCompletionDate { get; set; }
        public  string  VesselName { get; set; }
        public  string  IMONo { get; set; }
        public  string  VesselID { get; set; }
        public  string  DateDelivered { get; set; }
        public  string  MainEngManuf { get; set; }
        public  string  MainEngType { get; set; }
        public  string  MainEngSerialNo { get; set; }
        public  string  MainEngLoc { get; set; }
        public  string  MainEngNo { get; set; }
        public  string  MCR { get; set; }
        public  string  RPM { get; set; }
        public  string  LubricatorType { get; set; }
        public  string  MinFeedRate { get; set; }
        public  string  CurrentFeedRate { get; set; }
        public  string  TargetFeedRate { get; set; }
        public  string  OilGrade { get; set; }
        public  string  Density { get; set; }
        public  string  NoOfTurbos { get; set; }
        public  string  TurboCutOutAvailable { get; set; }
        public  string  PistonCleaningRing { get; set; }
        public string ProjectID { get; set; }
        public string SMPAddress { get; set; }
        public string SMPTelephone { get; set; }
        public string SMPEmail { get; set; }
        public int NoOfEngines { get; set; }
        public int EngineNo { get; set; }
        public int NoOfCylinders { get; set; }
        public string ProjectStatus { get; set; }

    }
}
