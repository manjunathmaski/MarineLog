﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class SupportInformation
    {
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public string DateOfReading { get; set; }
    }
}
