﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class RunningData
    {
        public int UniqueId { get; set; }
       
        public string DateOfReading { get; set; }
        public string PortSea { get; set; }
        public int NoOfCylinders { get; set; }
        public double TotEngineHours { get; set; }
        public double CylinderRPM { get; set; }
        public double Power { get; set; }
        public double PercentMCR { get; set; }
        public double PercentS { get; set; }
        public double Catfines { get; set; }
        public double Vanadium { get; set; }
        public double Consumption { get; set; }
        public double RelativeHumidity { get; set; }
        public double AmbTemp { get; set; }
        public double ScavAirTemp { get; set; }
        public double EngRoomTemp { get; set; }
        public double CylinderOilConsump { get; set; }
        public double Federate { get; set; }
        public string SampleSentRCC { get; set; }
        public int NoOfTCInUse { get; set; }
        public string Comments { get; set; }
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public int IsDataSubmitted { get; set; }
        public string OilGrade { get; set; }
        public string Density { get; set; }
    }
}
