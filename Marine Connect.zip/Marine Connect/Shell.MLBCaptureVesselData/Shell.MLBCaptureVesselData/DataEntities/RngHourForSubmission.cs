﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class RngHourForSubmission
    {
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public int CylinderNumber { get; set; }
        public string ReadingDate { get; set; }
        public List<Test1> Test { get; set; }
    }

    //public class RunningHourOnEng
    //{ 
    //    [XmlAttribute("Name")]
    //    public string Name { get; set; }
    //    [XmlAttribute("ID")]
    //    public int ID { get; set; }
    //    public List<CylinderPart> Result { get; set; }
    //}

    //public class Result
    //{
    //    public List<CylinderPart> cylPart { get; set; }
    //}

    //public class CylinderPart
    //{
    //    [XmlAttribute("id")]
    //    public string Id { get; set; }
    //    [XmlText]
    //    public double Value { get; set; }

    //}

    public class Test1
    {
        [XmlAttribute("Name")]
        public string Name { get; set; }
        [XmlAttribute("ID")]
        public int ID { get; set; }
        public Result Result { get; set; }
    }

    public class Result
    {
        public double Value { get; set; }
    }
}
