﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class CylinderInspection
    {
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public int CylinderNumber { get; set; }
        public string DateOfInspection{ get; set; }
        
    }
}
