﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class BunkerInformation
    {
        public int VesselNo { get; set; }
        public string DateBunkered { get; set; }
        public double QuantityBunkered { get; set; }
        public double BDNSContent { get; set; }
        public int EngineNo { get; set; }
    }
}
