﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class RunningHour
    {
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        public int CylinderNumber { get; set; }
        public string ReadingDate { get; set; }
        public double Liner { get; set; }
        public double Prings { get; set; }
        public double PCrown { get; set; }
       
    }
}
