﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    public class Test
    {
        public int TestId { get; set; }
        public string TestName { get; set; }
        public string NodeName { get; set; }
    }
}
