﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shell.MLBCaptureVesselData
{
    [Serializable]
    public class CylinderData
    {
        public int UniqueID { get; set; }
        public int CylinderNumber { get; set; }
        #region Changes for Including Magnetic and Corrosive Iron
        public int MagneticIron { get; set; }
        public int CorrosiveIron { get; set; }
        #endregion
        public int AAReading { get; set; }
        public double PMax { get; set; }
        public double FuelIndex { get; set; }
        public double CoolingWaterTemp { get; set; }
        public double LinearWallTempMin { get; set; }
        public double LinearWallTempMax { get; set; }
        public double FederateSetPoint { get; set; }
        public double BNMeasuredOnboard { get; set; }
        public int VesselNo { get; set; }
        public int EngineNo { get; set; }
        
    }
}
