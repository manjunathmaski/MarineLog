﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Shell.MLBCaptureVesselData;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.Net.Mail;


namespace MLBCaptureVesselData
{
    public partial class CustomerVesselData : Form
    {
        #region Global Variables
        VesselInfoDataEntity vdeOldVesselEntity = new VesselInfoDataEntity();
        VesselInfoDataEntity vdeSecondEngine = new VesselInfoDataEntity();
        public DataTable dtCylinderData { get; set; }
        public DataTable dtCylinderDataReadOnly { get; set; }
        List<RunningData> lstRunningData = new List<RunningData>();
        List<CylinderData> lstCylinderData = new List<CylinderData>();
        List<VesselInfoDataEntity> lstVesselData = new List<VesselInfoDataEntity>();
        int inVesselNo = 0;
        int inEngineNo = 0;
        string strMaxVesselNo = string.Empty;
        string strNoOfCylinders = string.Empty;
        CultureInfo culture = new CultureInfo("en-US");
        DateTimePicker dtp = new DateTimePicker();
        DateTimePicker dtpRngHour = new DateTimePicker();
        DateTimePicker dtpLinearWear = new DateTimePicker();
        DateTimePicker dtpCylInspection = new DateTimePicker();
        DataTable dtBunkerInfo = new DataTable();
        HomeDataAccess hdaDataAccess = new HomeDataAccess();
        DataTable dtRunningHourData = new DataTable();
        List<RunningHour> lstRngHour = new List<RunningHour>();
        List<LinearWear> lstLinearWear = new List<LinearWear>();
        List<CylinderInspection> lstCylInspection = new List<CylinderInspection>();
        DataTable dtLinearWear = new DataTable();
        List<BunkerInformation> lstBunkerInfo = new List<BunkerInformation>();
        DataTable dtCylInspection = new DataTable();
        BackgroundWorker m_Worker = new BackgroundWorker();
        bool isEngineInsert = false;

        int noOfEngines = 0;
        string strProjectStatus = string.Empty;
        string strCommaCultures;
        string[] arrCommaCultures;

        string fileName = string.Empty;

        #endregion
        
        #region CustomerVesselData
        /// <summary>
        /// This the main method of the class
        /// </summary>
        public CustomerVesselData()
        {


            Thread.CurrentThread.CurrentCulture = culture;
            Thread.CurrentThread.CurrentUICulture = culture;
            InitializeComponent();
                                     
            SetUpTheDatabaseFile();
            if (IsAppExpired())
            {
                MessageBox.Show("The application has expired", "Expired", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                if (System.Windows.Forms.Application.MessageLoop)
                {
                    // WinForms app
                    System.Windows.Forms.Application.Exit();
                }
                else
                {
                    // Console app
                    System.Environment.Exit(1);
                }
            }
            HideUnhidePanels(pnlHome.Name);
            dgvCylinderData.CellEndEdit += dgvCylinderData_CellEndEdit;
            dgvCylinderData.CellValidating += dgvCylinderData_CellValidating;
            dgvCylinderData.ColumnAdded += dgvCylinderData_ColumnAdded;
            
            dgvProjectData.CellClick += dgvProjectData_CellClick;
            tsTxtHistory.Click += tsTxtHistory_Click;
            tsTxtSupportHistory.Click += tsTxtSupportHistory_Click;
            dgvReadOnlyHistory.CellClick += dgvReadOnlyHistory_CellClick;
            dgvProjectData.CellContentClick += dgvProjectData_CellContentClick;
            dgvProjectData.DataBindingComplete += dgvProjectData_DataBindingComplete;
            dgvBunkerInfo.CellValidating += dgvBunkerInfo_CellValidating;
            dgvBunkerInfo.CellEndEdit += dgvBunkerInfo_CellEndEdit;

            dgvLinearWear.CellValidating += dgvLinearWear_CellValidating;
            dgvLinearWear.CellEndEdit += dgvLinearWear_CellEndEdit;

            dgvRunningHour.CellValidating += dgvRunningHour_CellValidating;
            dgvRunningHour.CellEndEdit += dgvRunningHour_CellEndEdit;

            dgvSupportHistReadOnly.CellClick += dgvSupportHistReadOnly_CellClick;

            dgvCylInpsection.CellContentClick += dgvCylInpsection_CellContentClick;
            

            imgHeader.ImageLocation = Path.GetFullPath("Files/ShellLubeMonitor.png");
            //imgShellLogo.ImageLocation = Path.GetFullPath("Files/Pecten.png");
            imgHome.ImageLocation = Path.GetFullPath("Files/Home.jpg");
            //imgEngine.ImageLocation = Path.GetFullPath("Files/Engine.png");
            imgShellMarine.ImageLocation = Path.GetFullPath("Files/ShellMarine.jpg");

            imgLubeMonitorPgm.ImageLocation = Path.GetFullPath("Files/programme-overview-icon.JPG");
            imgOilAnalysis.ImageLocation = Path.GetFullPath("Files/cylinder-drain-oil-analysis-icon.JPG");
            imgAlexia.ImageLocation = Path.GetFullPath("Files/shell-alexia-cylinder-oils-icon.JPG");
            imgOtherProducts.ImageLocation = Path.GetFullPath("Files/other-products-and-services-icon.JPG");
            imbLubeMonitorBroch.ImageLocation = Path.GetFullPath("Files/shell-lubemonitor-brochure-icon.png");
            imgLubMonUserGuide.ImageLocation = Path.GetFullPath("Files/shell-lubemonitor-userguide-icon.png");
            imgLubricantsLeaflet.ImageLocation = Path.GetFullPath("Files/shell-rapid-lubricants-analysis-icon-leaflet.png");
            //imgLeaflet.ImageLocation = Path.GetFullPath("Files/shell-rapid-lubricants-analysis-icon-leaflet.png");
            imgBrochure.ImageLocation = Path.GetFullPath("Files/brochure.png");
            imgOnboardBroch.ImageLocation = Path.GetFullPath("Files/shell-rapid-lubricants-onboardalert-icon-Broc.png");
            imgUserGuide.ImageLocation = Path.GetFullPath("Files/shell-rapid-lubricants-onboardalert-icon-UserGuide.png");
            imgOnBoardUserGuide.ImageLocation = Path.GetFullPath("Files/shell-rapid-lubricants-onboardplus-icon_broch.png");
            imgAlexiaBroch.ImageLocation = Path.GetFullPath("Files/shell-alexia-brochure-icon.png");
            imgS6MSDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s6-msds.png");
            imgS6TDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s6-TDS.png");
            imgS4MSDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s4-icon-msds.png");
            imgS4TDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s6-TDS.png");
            img50MSDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-50-msds.png");
            img50TDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s6-TDS.png");
            imgS3Brochure.ImageLocation = Path.GetFullPath("Files/shell-alexia-s3-broch.png");
            imgS3MSDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s3-msds.png");
            imgS3TDS.ImageLocation = Path.GetFullPath("Files/shell-alexia-s6-TDS.png");
            imgProducts.ImageLocation = Path.GetFullPath("Files/products-table-icon.png");

            strCommaCultures = ConfigurationManager.AppSettings["CulturesWithCommasAsDecimal"].ToString();
            arrCommaCultures = strCommaCultures.Split(',');

            SetButtonBackgroundColors(this, System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(46)))), ((int)(((byte)(18))))));
            SetLabelStyles(this);

            cmbNoOfCyl.SelectedIndex = 0;
            //cmbOilGrade.SelectedIndex = 0;
            cmbOilGrade2.SelectedIndex = 0;
            cmbPistonCleaning.SelectedIndex = 0;
            cmbPistonCleaningRing2.SelectedIndex = 0;
            cmbTCCutavail.SelectedIndex = 0;
            cmbTCCutOutAvail2.SelectedIndex = 0;
            cmbNoOfEngines.SelectedIndex = 0;
            cmbProjectStatus.SelectedIndex = 1;

            if (Shell.MLBCaptureVesselData.Properties.Settings.Default.VesselId != string.Empty)
            {
                inVesselNo = int.Parse(Shell.MLBCaptureVesselData.Properties.Settings.Default.VesselId);
                GetAllVesselData();
            }

            cmbXAxis.SelectedIndex = 0;
            cmbXAxis.SelectedIndexChanged += cmbXAxis_SelectedIndexChanged;
            cmbIronAxis.SelectedIndex = 0;
            cmbIronAxis.SelectedIndexChanged += new System.EventHandler(this.cmbIronAxis_SelectedIndexChanged);
        }

        



        private bool IsAppExpired()
        {
            bool isExpired = true;
            //int period = 365 * 5;
            string lastUpdatedAt = string.Empty;
            lastUpdatedAt = hdaDataAccess.GetDBVersionDetails();
            DateTime dtExpiry = Convert.ToDateTime("07/07/2019", culture);
            dtExpiry = dtExpiry.AddDays(10);
            long expiry = dtExpiry.Ticks;
            //long expiry = 0;
            long today = DateTime.Today.Ticks;

            if (today > expiry)
                isExpired = true;
            else
                isExpired = false;

            return isExpired;
        }

        private void SetUpTheDatabaseFile()
        {
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userFilePath = Path.Combine(localAppData, "SHELL");

            if (!Directory.Exists(userFilePath))
                Directory.CreateDirectory(userFilePath);

            //if it's not already there, 
            //copy the file from the deployment location to the folder
            string sourceFilePath = Path.Combine(
              System.Windows.Forms.Application.StartupPath, "Files\\MLBDataCapture.sdf");
            string destFilePath = Path.Combine(userFilePath, "MLBDataCapture.sdf");
            if (!File.Exists(destFilePath))
                File.Copy(sourceFilePath, destFilePath);

            //string brochurePath = Path.Combine(localAppData, "SHELL\\Brochures_Marine Connect");
            //string brocureSourcePath = Path.Combine(System.Windows.Forms.Application.StartupPath, "Files\\Brochures_Marine Connect");
            //if(!Directory.Exists(brochurePath))
            //{
            //    Copy(brocureSourcePath, brochurePath);
            //}

            hdaDataAccess.CheckAndUpgradeDB();

        }          
        #endregion

        #region EVENTS

        public static void Copy(string sourceDirectory, string targetDirectory)
        {
            DirectoryInfo diSource = new DirectoryInfo(sourceDirectory);
            DirectoryInfo diTarget = new DirectoryInfo(targetDirectory);

            CopyAll(diSource, diTarget);
        }

        public static void CopyAll(DirectoryInfo source, DirectoryInfo target)
        {
            Directory.CreateDirectory(target.FullName);

            // Copy each file into the new directory.
            foreach (FileInfo fi in source.GetFiles())
            {
                Console.WriteLine(@"Copying {0}\{1}", target.FullName, fi.Name);
                fi.CopyTo(Path.Combine(target.FullName, fi.Name), true);
            }

            // Copy each subdirectory using recursion.
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                DirectoryInfo nextTargetSubDir =
                    target.CreateSubdirectory(diSourceSubDir.Name);
                CopyAll(diSourceSubDir, nextTargetSubDir);
            }
        }

        #region tstxtEngInfo_Click
        /// <summary>
        /// This event is fired when Engine information tab is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tstxtEngInfo_Click(object sender, System.EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            try
            {
                if (inEngineNo == 0)
                {
                    inEngineNo = 1;
                }

                if (noOfEngines == 1)
                {
                    btnSecondEngine.Visible = false;
                }
                else
                {
                    btnSecondEngine.Visible = true;
                }

                if (inEngineNo == 1)
                {
                    HideUnhidePanels(pnlEngineInfo.Name);
                    SetResetBackGroundColor(tstxtEngInfo);
                    PopulateVesselInformation();
                }
                else
                {
                    HideUnhidePanels(pnlEngine2.Name);
                    SetResetBackGroundColor(tstxtEngInfo);
                    PopulateSecondEngineData();
                }
                SetEngineLabelNo();
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region pnlMain_Paint
        /// <summary>
        /// This method makes the panel border color gold.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pnlMain_Paint(object sender, PaintEventArgs e)
        {
            Rectangle rect = pnlMain.ClientRectangle;
            rect.Width--;
            rect.Height--;
            e.Graphics.DrawRectangle(Pens.Gold, rect);
        }
        #endregion

        #region cmbOilGrade_SelectedIndexChanged
        /// <summary>
        /// This method changes the density value based on the oil grade selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void cmbOilGrade_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    string strSelectedItem = string.Empty;
        //    if (cmbOilGrade.SelectedIndex > 0)
        //    {
        //        strSelectedItem = cmbOilGrade.SelectedItem.ToString();
        //    }

        //    try
        //    {
        //        txtDensity.Text = GetDensityPerOilGrade(strSelectedItem);
        //    }
        //    catch (Exception ex)
        //    {
        //      Common.WriteTextFile(ex, Common.strUser);
        //    }

        //}
        #endregion

        #region tsTxtLogBookDetail_Click
        /// <summary>
        /// This event is triggered on clicking the log book detail 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsTxtLogBookDetail_Click(object sender, EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            HideUnhidePanels(pnlLogBookInfo.Name);
            SetResetBackGroundColor(tsTxtLogBookDetail);
            SetEngineLabelNo();

            try
            {
                lstRunningData = hdaDataAccess.GetRunningData(inVesselNo, inEngineNo);
                lstCylinderData = hdaDataAccess.GetCylinderData(inVesselNo, inEngineNo);

                if (lstRunningData.Count > 0)
                {
                    var item = lstRunningData.Max(x => Convert.ToDateTime(x.DateOfReading, CultureInfo.CurrentCulture));
                    if (item != null)
                    {
                        PopulateLogBookDetail(item.ToString());
                    }
                }
                else
                {
                    PopulateLogBookDetail("Empty");
                    txtNoOfCyl.Text = strNoOfCylinders;
                    // txtEnngNo.Text = inEngineNo.ToString();
                    dtCylinderData = GetCylinderInformationPerUniqueId(Convert.ToInt32(strNoOfCylinders), 0);
                }

                dgvCylinderData.DataSource = dtCylinderData;
                dgvCylinderData.Columns[Constants.CYLINDER_NUMBER_GRID].ReadOnly = true;
                dgvCylinderData.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region GetCylinderInformationPerUniqueId
        private DataTable GetCylinderInformationPerUniqueId(int intNoOfCylinders, int intUniqueId)
        {

            DataTable dtTempCylinderData = new DataTable();
            dtTempCylinderData.Columns.Add(Constants.CYLINDER_NUMBER_GRID);
            #region Changes for Including Magnetic and Corrosive Iron
            dtTempCylinderData.Columns.Add(Constants.MAGNETIC_IRON_GRID);
            dtTempCylinderData.Columns.Add(Constants.CORROSIVE_IRON_GRID);
            #endregion
            dtTempCylinderData.Columns.Add(Constants.AA_READING_GRID);
            dtTempCylinderData.Columns.Add(Constants.FEDERATE_SETPOINT_GRID);
            dtTempCylinderData.Columns.Add(Constants.BN_MEASURED_ONBOARD_GRID);
            dtTempCylinderData.Columns.Add(Constants.PMAX_GRID);
            dtTempCylinderData.Columns.Add(Constants.FUEL_INDEX_GRID);
            dtTempCylinderData.Columns.Add(Constants.COOLING_WATER_TEMP_GRID);
            dtTempCylinderData.Columns.Add(Constants.LINEAR_WALL_TEMP_MIN_GRID);
            dtTempCylinderData.Columns.Add(Constants.LINEAR_WALL_TEMP_MAX_GRID);
            

            dtTempCylinderData.AcceptChanges();

            if (intUniqueId == 0)
            {
                for (int i = 1; i <= intNoOfCylinders; i++)
                {
                    dtTempCylinderData.Rows.Add(i.ToString(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                }
                dtTempCylinderData.AcceptChanges();

            }
            else
            {
                int intSavedCylinderNo = lstCylinderData.Count(x => x.UniqueID == intUniqueId);
                var query = from a in lstCylinderData
                            where a.UniqueID == intUniqueId
                            select a;

                //Added two more fields for magnetic and corrosive iron
                foreach (var a in query)
                {
                    dtTempCylinderData.Rows.Add(a.CylinderNumber, a.MagneticIron, a.CorrosiveIron, a.AAReading, a.FederateSetPoint, a.BNMeasuredOnboard, a.PMax, a.FuelIndex, a.CoolingWaterTemp, a.LinearWallTempMin, a.LinearWallTempMax);
                }
                
                dtTempCylinderData.AcceptChanges();
                if (intSavedCylinderNo == intNoOfCylinders)
                {

                    //no changes needed
                }
                else if (intSavedCylinderNo > intNoOfCylinders)
                {
                    //remove extra rows
                    for (int j = intNoOfCylinders; j <= intSavedCylinderNo - 1; j++)
                    {
                        dtTempCylinderData.Rows.RemoveAt(j);
                    }
                    dtTempCylinderData.AcceptChanges();
                }
                else if (intSavedCylinderNo < intNoOfCylinders)
                {
                    //insert extra dummy rows
                    for (int k = intSavedCylinderNo; k < intNoOfCylinders; k++)
                    {
                        dtTempCylinderData.Rows.Add((k + 1).ToString(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    }
                }
            }
            return dtTempCylinderData;
        }
        #endregion

        #region PopulateLogBookDetail
        private void PopulateLogBookDetail(string item)
        {
            RunningData rngData = new RunningData();

            SetEngineLabelNo();

            if (item == "New")
            {
                dtDateOfReading.Enabled = true;
            }
            else
            {
                dtDateOfReading.Enabled = false;
            }

            var query = from a in lstRunningData
                        where a.DateOfReading == item
                        select a;

            var lstDate = (from v in lstVesselData
                           where v.VesselNo == inVesselNo
                           select new { v.TargetCompletionDate }).FirstOrDefault();
            string dtLastDate = string .Empty ; 

            if (lstDate != null)
            {
                if (Convert.ToDateTime(lstDate.TargetCompletionDate) < DateTime.Now)
                {
                    dtLastDate = lstDate.TargetCompletionDate;
                }
                else
                {
                    dtLastDate = DateTime.Now.ToShortDateString();
                }
            }

            foreach (var a in query)
            {
                rngData = a;
            }
            if (rngData != null)
            {
                if (rngData.NoOfCylinders == 0)
                {
                    dtCylinderData = GetCylinderInformationPerUniqueId(Convert.ToInt32(strNoOfCylinders), 0);
                }
                else
                {
                    dtCylinderData = GetCylinderInformationPerUniqueId(rngData.NoOfCylinders, rngData.UniqueId);
                }
                dgvCylinderData.DataSource = dtCylinderData;
                dgvCylinderData.AllowUserToAddRows = false;

                txtTotalEngineHours.Text = rngData.TotEngineHours == 0.0 ? string.Empty : rngData.TotEngineHours.ToString();
                txtCylinderRPM.Text = rngData.CylinderRPM == 0.0 ? string.Empty : rngData.CylinderRPM.ToString();
                txtPower.Text = rngData.Power == 0.0 ? string.Empty : rngData.Power.ToString();
                txtRelHumidity.Text = rngData.RelativeHumidity == 0.0 ? string.Empty : rngData.RelativeHumidity.ToString();
                txtAmpTemp.Text = rngData.AmbTemp == 0.0 ? string.Empty : rngData.AmbTemp.ToString();
                txtScavAirTemp.Text = rngData.ScavAirTemp == 0.0 ? string.Empty : rngData.ScavAirTemp.ToString();
                txtEngRoomTemp.Text = rngData.EngRoomTemp == 0.0 ? string.Empty : rngData.EngRoomTemp.ToString();
                txtCylinderOilCons.Text = rngData.CylinderOilConsump == 0.0 ? string.Empty : rngData.CylinderOilConsump.ToString();
                if (rngData.SampleSentRCC != null && rngData.SampleSentRCC != string.Empty)
                {
                    cmbSampleForRCC.SelectedItem = rngData.SampleSentRCC.ToString();
                }
                else
                {
                    cmbSampleForRCC.SelectedIndex = 0;
                }
                txtNoOfTCInUse.Text = rngData.NoOfTCInUse == 0 ? string.Empty : rngData.NoOfTCInUse.ToString();
                txtComments.Text = rngData.Comments;
                if (rngData.DateOfReading != dtDateOfReading.Text)
                {
                    dtDateOfReading.Text = rngData.DateOfReading == null ? dtLastDate : rngData.DateOfReading.ToString();
                }
                if (rngData.PortSea != null && rngData.PortSea != string.Empty)
                {
                    cmbPortSea.SelectedItem = rngData.PortSea.ToString();
                }
                else
                {
                    cmbPortSea.SelectedIndex = 0;
                }
                if (rngData.NoOfCylinders != 0)
                {
                    //cmbNoOfCylinders.SelectedItem = rngData.NoOfCylinders.ToString();
                    txtNoOfCyl.Text = rngData.NoOfCylinders.ToString();
                }
                else
                {
                    //cmbNoOfCylinders.SelectedItem = "4";
                    txtNoOfCyl.Text = strNoOfCylinders;
                }
                //txtEnngNo.Text = inEngineNo.ToString();
                txtPercentS.Text = rngData.PercentS == 0.0 ? string.Empty : rngData.PercentS.ToString();
                txtCatfines.Text = rngData.Catfines == 0.0 ? string.Empty : rngData.Catfines.ToString();
                txtVanadium.Text = rngData.Vanadium == 0.0 ? string.Empty : rngData.Vanadium.ToString();
                txtConsump.Text = rngData.Consumption == 0.0 ? string.Empty : rngData.Consumption.ToString();

                #region Change to include Oil Grade and Density at sample date level
                if (rngData.OilGrade != null && rngData.OilGrade != string.Empty)
                {
                    cmbOilGrade2.SelectedItem = rngData.OilGrade.ToString();
                }
                else
                {
                    cmbOilGrade2.SelectedIndex = 0;
                }
                txtDensity2.Text = rngData.Density;
                #endregion

                //this.dtDateOfReading.ValueChanged += new System.EventHandler(this.dtDateOfReading_ValueChanged);
            }

        }
        #endregion

        #region btnSaveData_Click
        private void btnSaveData_Click(object sender, EventArgs e)
        {
            int intUniqueId = 0;
            int inStatus = 0;
            bool update = true;

            try
            {
                #region Change to include Oil Grade and Density at sample date level
                if (cmbOilGrade2.SelectedIndex <= 0 || txtPower.Text == string.Empty || txtCylinderOilCons.Text == string .Empty )
                {
                    MessageBox.Show("Please enter all mandatory fields marked with (*)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                #endregion

                if (!ValidateLogBookDate())
                {
                    MessageBox.Show("Date of reading should be between the start and end date of the project", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int count = (from a in lstRunningData
                             where ConvertToShortDate( a.DateOfReading) == dtDateOfReading.Text.ToString()
                             && a.VesselNo == inVesselNo
                             && a.EngineNo == inEngineNo
                             select a).Count();
                if (count > 0 && lblIsNew.Text == "Yes")
                {
                    var confirmResult =  MessageBox.Show("Data for this date already exists? Are you sure you want to overwrite?",
                                     "Confirm Overwrite",
                                     MessageBoxButtons.YesNo);
                    if (confirmResult == DialogResult.Yes)
                    {
                        var rndata = (from a in lstRunningData
                                      where ConvertToShortDate(a.DateOfReading) == dtDateOfReading.Text.ToString()
                                         && a.VesselNo == inVesselNo
                                         && a.EngineNo == inEngineNo
                                      select a).FirstOrDefault();
                        int seqNo = rndata.UniqueId;
                        update = true;
                    }
                    else
                    {
                        update = false;
                    }
                }

                if (update)
                {
                    intUniqueId = SaveRunningData();
                    if (intUniqueId > 0)
                    {
                        inStatus = SaveCylinderData(intUniqueId);
                        if (inStatus == 0)
                        {
                            lstRunningData = hdaDataAccess.GetRunningData(inVesselNo, inEngineNo);
                            lstCylinderData = hdaDataAccess.GetCylinderData(inVesselNo, inEngineNo);
                            MessageBox.Show(Constants.SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dtDateOfReading.Enabled = false;
                            return;
                        }
                        else
                        {
                            MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            dtDateOfReading.Enabled = false;
                            return;
                        }
                    }

                    else
                    {
                        MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        dtDateOfReading.Enabled = false;
                        return;
                    }
                }
                
                
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }


        }

        
        #endregion

        #region SaveCylinderData
        private int SaveCylinderData(int intUniqueId)
        {
            int inStatus = 0;
            CylinderData cylData = new CylinderData();

            try
            {
                foreach (DataRow dr in dtCylinderData.Rows)
                {
                    cylData.UniqueID = intUniqueId;
                    cylData.VesselNo = inVesselNo;
                    cylData.EngineNo = inEngineNo;
                    cylData.CylinderNumber = dr[Constants.CYLINDER_NUMBER_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NUMBER_GRID].ToString());
                    #region Changes for Including Magnetic and Corrosive Iron
                    cylData.MagneticIron = dr[Constants.MAGNETIC_IRON_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.MAGNETIC_IRON_GRID].ToString());
                    cylData.CorrosiveIron = dr[Constants.CORROSIVE_IRON_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CORROSIVE_IRON_GRID].ToString());
                    #endregion
                    cylData.AAReading = dr[Constants.AA_READING_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.AA_READING_GRID].ToString());
                    cylData.PMax = dr[Constants.PMAX_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PMAX_GRID].ToString());
                    cylData.FuelIndex = dr[Constants.FUEL_INDEX_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.FUEL_INDEX_GRID].ToString());
                    cylData.CoolingWaterTemp = dr[Constants.COOLING_WATER_TEMP_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.COOLING_WATER_TEMP_GRID].ToString());
                    cylData.LinearWallTempMin = dr[Constants.LINEAR_WALL_TEMP_MIN_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.LINEAR_WALL_TEMP_MIN_GRID].ToString());
                    cylData.LinearWallTempMax = dr[Constants.LINEAR_WALL_TEMP_MAX_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.LINEAR_WALL_TEMP_MAX_GRID].ToString());
                    cylData.FederateSetPoint = dr[Constants.FEDERATE_SETPOINT_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.FEDERATE_SETPOINT_GRID].ToString());
                    cylData.BNMeasuredOnboard = dr[Constants.BN_MEASURED_ONBOARD_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.BN_MEASURED_ONBOARD_GRID].ToString());

                    if (dr.RowState == DataRowState.Added)
                    {
                        hdaDataAccess.InsertCylinderData(cylData);
                    }
                    if (dr.RowState == DataRowState.Modified || dr.RowState ==  DataRowState.Unchanged)
                    {
                        int count = (from a in lstCylinderData
                                     where a.UniqueID == intUniqueId
                                     && a.CylinderNumber == cylData.CylinderNumber
                                     select a).Count();
                        if (count > 0)
                        {
                            inStatus = hdaDataAccess.UpdateCylinderData(cylData);
                        }
                        else
                        {
                            inStatus = hdaDataAccess.InsertCylinderData(cylData);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return inStatus;

        }
        #endregion

        #region SaveRunningData
        private int SaveRunningData()
        {
            RunningData rngData = new RunningData();
            int inUniqueId = 0;

            try
            {
                rngData.TotEngineHours = txtTotalEngineHours.Text == string.Empty ? 0.0 : Convert.ToDouble(txtTotalEngineHours.Text);
                rngData.CylinderRPM = txtCylinderRPM.Text == string.Empty ? 0.0 : Convert.ToDouble(txtCylinderRPM.Text);
                rngData.Power = txtPower.Text == string.Empty ? 0.0 : Convert.ToDouble(txtPower.Text);
                rngData.RelativeHumidity = txtRelHumidity.Text == string.Empty ? 0.0 : Convert.ToDouble(txtRelHumidity.Text);
                rngData.AmbTemp = txtAmpTemp.Text == string.Empty ? 0.0 : Convert.ToDouble(txtAmpTemp.Text);
                rngData.ScavAirTemp = txtScavAirTemp.Text == string.Empty ? 0.0 : Convert.ToDouble(txtScavAirTemp.Text);
                rngData.EngRoomTemp = txtEngRoomTemp.Text == string.Empty ? 0.0 : Convert.ToDouble(txtEngRoomTemp.Text);
                rngData.CylinderOilConsump = txtCylinderOilCons.Text == string.Empty ? 0.0 : Convert.ToDouble(txtCylinderOilCons.Text);
                if (cmbSampleForRCC.SelectedIndex > 0)
                {
                    rngData.SampleSentRCC = cmbSampleForRCC.SelectedItem.ToString();
                }
                rngData.NoOfTCInUse = txtNoOfTCInUse.Text == string.Empty ? 0 : Convert.ToInt32(txtNoOfTCInUse.Text);
                rngData.Comments = txtComments.Text;

                rngData.DateOfReading = dtDateOfReading.Value.ToString();
                cmbPortSea.SelectedItem = "Sea";
                if (cmbPortSea.SelectedIndex > 0)
                {
                    rngData.PortSea = cmbPortSea.SelectedItem.ToString();
                }
                rngData.NoOfCylinders = txtNoOfCyl.Text == string.Empty ? 0 : Convert.ToInt32(txtNoOfCyl.Text);

                rngData.PercentS = txtPercentS.Text == string.Empty ? 0.0 : Convert.ToDouble(txtPercentS.Text);
                rngData.Catfines = txtCatfines.Text == string.Empty ? 0.0 : Convert.ToDouble(txtCatfines.Text);
                rngData.Vanadium = txtVanadium.Text == string.Empty ? 0.0 : Convert.ToDouble(txtVanadium.Text);
                rngData.Consumption = txtConsump.Text == string.Empty ? 0.0 : Convert.ToDouble(txtConsump.Text);
                rngData.VesselNo = inVesselNo;
                rngData.EngineNo = inEngineNo;
                rngData.IsDataSubmitted = 0;

                #region Change to include Oil Grade and Density at sample date level
                if (cmbOilGrade2.SelectedIndex > 0)
                {
                    rngData.OilGrade = cmbOilGrade2.SelectedItem.ToString();
                }
                rngData.Density = txtDensity2.Text;
                #endregion

                //Need to add calculation:
                if (vdeOldVesselEntity.MCR != string.Empty && Convert.ToDouble(vdeOldVesselEntity.MCR) != 0)
                {
                    rngData.PercentMCR = (rngData.Power / Convert.ToDouble(vdeOldVesselEntity.MCR)) * 100;
                }


                if (rngData.Power != 0 && rngData.Density != string.Empty)
                {
                    rngData.Federate = (rngData.CylinderOilConsump * GetDensityInNumeric(rngData.Density) * 1000) / (24 * rngData.Power);
                }
                //rngData.Federate = 0.0;


                int count = (from a in lstRunningData
                             where a.DateOfReading == rngData.DateOfReading
                             && a.VesselNo == rngData.VesselNo
                             && a.EngineNo == rngData.EngineNo
                             select a).Count();
                if (count > 0)
                {

                    inUniqueId = hdaDataAccess.UpdateRunningData(rngData);
                }
                else
                {
                    inUniqueId = hdaDataAccess.InsertRunningData(rngData);
                }

                //int inUniqueId = hdaDataAccess.SaveRunningData(rngData);
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            return inUniqueId;
        }
        #endregion

       
        #region btnAddNewDate_Click
        private void btnAddNewDate_Click(object sender, EventArgs e)
        {
            PopulateLogBookDetail("New");
            lblIsNew.Text = "Yes";
        }
        #endregion

        #region dgvCylinderData_CellValidating
        private void dgvCylinderData_CellValidating(object sender, System.Windows.Forms.DataGridViewCellValidatingEventArgs e)
        {
            string headerText =
            dgvCylinderData.Columns[e.ColumnIndex].HeaderText;

            // Abort validation if cell is empty.
            if (e.FormattedValue.ToString() != string.Empty)
            {
                if (headerText.Equals(Constants.CORROSIVE_IRON_GRID))
                {
                    Regex expression = new Regex("^\\d+$");
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvCylinderData.Rows[e.RowIndex].ErrorText =
                           "Corrosive Iron must be a number with no decimals";
                        e.Cancel = true;
                        return;
                    }
                    if (Convert.ToInt32(e.FormattedValue.ToString()) != 0)
                    {
                        int magneticIron = 0;
                        if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].Value.ToString() != string.Empty)
                        {
                            magneticIron = Convert.ToInt32(dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].Value);
                        }
                        else
                        {
                            magneticIron = 0;
                        }
                        if (magneticIron == 0)
                        {
                            dgvCylinderData.Rows[e.RowIndex].ErrorText =
                              "Corrosive Iron can only be entered when magnetic iron is greater than 0. Please make this value 0";
                            e.Cancel = true;
                            
                        }
                        else
                        {
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = Convert.ToInt32(e.FormattedValue.ToString()) + magneticIron;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = true;
                        }
                    }
                    else if (Convert.ToInt32(e.FormattedValue.ToString()) == 0)
                    {
                        int magIron = 0;
                        if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].FormattedValue.ToString() != string.Empty)
                        {
                            magIron = Convert.ToInt32(dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].Value);
                        }
                        if (magIron == 0
                            && dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly == false)
                        {
                            //dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = 0;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false;
                        }
                        if (magIron == 0
                           && dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly == true)
                        {
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = 0;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false;
                        }
                        else if (magIron != 0)
                        {
                            //dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = 0;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false ;
                        }
                    }
                    else if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].Value.ToString() != string.Empty)
                    {
                        if (Convert.ToInt32(e.FormattedValue.ToString()) == 0 && Convert.ToInt32(dgvCylinderData.Rows[e.RowIndex].Cells[Constants.MAGNETIC_IRON_GRID].Value) == 0)
                        {
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false;
                        }
                    }
                }
                if (headerText.Equals(Constants.MAGNETIC_IRON_GRID))
                {
                    Regex expression = new Regex("^\\d+$");
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvCylinderData.Rows[e.RowIndex].ErrorText =
                           "Magnetic Iron must be a number with no decimals";
                        e.Cancel = true;
                        return;
                    }
                    if (e.FormattedValue.ToString() != string.Empty)
                    {
                        dgvCylinderData.Rows[e.RowIndex].Cells[Constants.CORROSIVE_IRON_GRID].ReadOnly = false;
                        int corrosiveIron = 0;
                        if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.CORROSIVE_IRON_GRID].Value.ToString() != string.Empty)
                        {
                            corrosiveIron = Convert.ToInt32(dgvCylinderData.Rows[e.RowIndex].Cells[Constants.CORROSIVE_IRON_GRID].Value);
                        }
                        if (corrosiveIron != 0)
                        {
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = Convert.ToInt32(e.FormattedValue.ToString()) + corrosiveIron;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = true;
                        }
                        else if(corrosiveIron == 0)// && dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly == true)
                        {
                            //dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = 0;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false;
                        }
                        if (Convert.ToInt32(e.FormattedValue.ToString()) == 0)
                        {
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.CORROSIVE_IRON_GRID].Value = 0;
                            dgvCylinderData.Rows[e.RowIndex].Cells[Constants.CORROSIVE_IRON_GRID].ReadOnly = true;
                            if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly == false)
                            {

                            }
                            else if (dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly == true)
                            {
                                dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].Value = 0;
                                dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly = false;
                            }
                        }
                    }
                   
                }
                if (headerText.Equals(Constants.AA_READING_GRID))
                {
                    if (!dgvCylinderData.Rows[e.RowIndex].Cells[Constants.AA_READING_GRID].ReadOnly)
                    {
                        Regex expression = new Regex("^\\d+$");
                        if (!expression.IsMatch(e.FormattedValue.ToString()))
                        {
                            dgvCylinderData.Rows[e.RowIndex].ErrorText =
                               "On Board Total Iron must be a number with no decimals";
                            e.Cancel = true;
                        }
                        else if (Convert.ToDouble(e.FormattedValue.ToString()) > 2500)
                        {
                            dgvCylinderData.Rows[e.RowIndex].ErrorText =
                               "On Board Total Iron must be less than or equal to 2,500";
                            e.Cancel = true;
                        }
                    }
                }
                else
                {
                    Regex expression;
                    if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\,[0-9]{1,3})?$");
                    }
                    else
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                    }
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvCylinderData.Rows[e.RowIndex].ErrorText =
                           "Values must be numeric with maximum 3 decimals";
                        e.Cancel = true;
                    }
                    if (headerText.Equals(Constants.BN_MEASURED_ONBOARD_GRID))
                    {
                        if (Convert.ToDouble(e.FormattedValue.ToString()) > 160)
                        {
                            dgvCylinderData.Rows[e.RowIndex].ErrorText =
                               "BN Measured must be less than or equal to 160";
                            e.Cancel = true;
                        }
                    }
                }
            }

            //if (e.Cancel == false)
            //{
            //    if (e.ColumnIndex == 8 && e.RowIndex == Convert.ToInt32(strNoOfCylinders) - 1)
            //    {
                    
            //        SelectNextControl(pnlRunningData, false, true, true, false);
            //    }
            //}

        }
        #endregion

        #region dgvCylinderData_CellEndEdit
        private void dgvCylinderData_CellEndEdit(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            dgvCylinderData.Rows[e.RowIndex].ErrorText = string.Empty;
            if (e.ColumnIndex == 8 && e.RowIndex == Convert.ToInt32(strNoOfCylinders) - 1)
            {

                SelectNextControl(pnlRunningData, false, true, true, false);
            }
        }
        #endregion

        #region dgvRunningHour_CellEndEdit
        void dgvRunningHour_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            dgvRunningHour.Rows[e.RowIndex].ErrorText = string.Empty;
            
        }
        #endregion

        #region dgvRunningHour_CellValidating
        void dgvRunningHour_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                return;
            }
            if (e.ColumnIndex != 0 && e.ColumnIndex != 1)
            {
                if (e.FormattedValue.ToString() != string.Empty)
                {
                    Regex expression;
                    if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\,[0-9]{1,3})?$");
                    }
                    else
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                    }
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvRunningHour.Rows[e.RowIndex].ErrorText =
                           "Values must be numeric with maximum 3 decimals";
                        e.Cancel = true;
                    }
                }
            }
        }
        #endregion

        #region dgvLinearWear_CellEndEdit
        void dgvLinearWear_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            dgvLinearWear.Rows[e.RowIndex].ErrorText = string.Empty;
        }
        #endregion

        #region dgvLinearWear_CellValidating
        void dgvLinearWear_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
            {
                return;
            }
            if (e.ColumnIndex != 0 && e.ColumnIndex != 1)
            {
                if (e.FormattedValue.ToString() != string.Empty)
                {
                    Regex expression;
                    if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\,[0-9]{1,3})?$");
                    }
                    else
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                    }
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvLinearWear.Rows[e.RowIndex].ErrorText =
                           "Values must be numeric with maximum 3 decimals";
                        e.Cancel = true;
                    }
                }
            }
        }
        #endregion

        #region dgvBunkerInfo_CellEndEdit
        void dgvBunkerInfo_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            dgvBunkerInfo.Rows[e.RowIndex].ErrorText = string.Empty;
        }
        #endregion

        #region dgvBunkerInfo_CellValidating
        void dgvBunkerInfo_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            string headerText =
                            dgvBunkerInfo.Columns[e.ColumnIndex].HeaderText;
            if (e.ColumnIndex == 0)
            {
                return;
            }
            if (e.ColumnIndex != 0 )
            {
                if (e.FormattedValue.ToString() != string.Empty)
                {
                    Regex expression;
                    if(arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\,[0-9]{1,3})?$");
                    }
                    else
                    {
                        expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                    }
                    if (!expression.IsMatch(e.FormattedValue.ToString()))
                    {
                        dgvBunkerInfo.Rows[e.RowIndex].ErrorText =
                           "Values must be numeric with maximum 3 decimals";
                        e.Cancel = true;
                    }                    
                    else if (headerText.Equals(Constants.QUANTITY_BUNKERED_COL))
                    {
                        if(Convert.ToDouble (e.FormattedValue.ToString()) > 100)
                        {
                            dgvBunkerInfo.Rows[e.RowIndex].ErrorText =
                                "BN Measured must be less than or equal to 100";
                            e.Cancel = true;
                        }
                    }
                    else if (headerText.Equals(Constants.BDNS_CONTENT_COL))
                    {
                        if (Convert.ToDouble(e.FormattedValue.ToString()) > 6.0)
                        {
                            dgvBunkerInfo.Rows[e.RowIndex].ErrorText =
                                "Sulphur,% must be less than or equal to 6.0";
                            e.Cancel = true;
                        }
                    }
                }
            }
        }
        #endregion

        #region lblNoOfVessels_Click
        private void lblNoOfVessels_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region btnSaveSetting_Click
        private void btnSaveSetting_Click(object sender, EventArgs e)
        {
            bool isSuccessful = false;
            try
            {
                if (!ValidateSettingInformation())
                {
                    return;
                }
                else
                {
                    isSuccessful = SaveEngineInformation(0);
                    if (!isSuccessful)
                    {
                        MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        strNoOfCylinders = cmbNoOfCyl.SelectedItem.ToString();
                        
                        //inEngineNo = Convert.ToInt32(cmbEngineNo.SelectedItem.ToString());
                        GetAllVesselData();
                        if (isEngineInsert)
                        {
                            PopulateVesselInformation();
                            dgvProjectData.CurrentCell = dgvProjectData.Rows[dgvProjectData.Rows.Count - 1].Cells["Project Id"];
                            dgvProjectData.CurrentCell.Selected = true;
                            
                        }

                        MessageBox.Show(Constants.SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region btnNew_Click
        private void btnNew_Click(object sender, EventArgs e)
        {
            inVesselNo = 0;
            dgvProjectData.ClearSelection();
            PopulateVesselInformation();
        }
        #endregion

        #region lblLinkSetting_LinkClicked
        private void lblLinkSetting_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            chkCylinderNumber.Items.Clear();
            GetAllVesselData();
            SetResetBackGroundColorForLinks("Setting");
            //SetResetBackGroundColorForLinks("Setting");
            HideUnhidePanels(pnlSetting.Name);
            
        }
        #endregion

        #region dgvProjectData_CellClick
        void dgvProjectData_CellClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1)
            {
                int inBeginIndex = dgvProjectData.CurrentCell.Value.ToString().LastIndexOf("-");
                inVesselNo = Convert.ToInt32(dgvProjectData.CurrentCell.Value.ToString().Substring(inBeginIndex + 1));
                Shell.MLBCaptureVesselData.Properties.Settings.Default.VesselId = inVesselNo.ToString();
                Shell.MLBCaptureVesselData.Properties.Settings.Default.Save();
                inEngineNo = 0;
                PopulateVesselInformation();
                
                
                strNoOfCylinders = cmbNoOfCyl.SelectedItem.ToString();
                
            }
            dgvProjectData.CurrentCell.Selected = true;

        }
        #endregion

        #region btnSaveEngineInfo_Click
        private void  btnSaveEngineInfo_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateEngineInformation())
                {
                    return;
                }
                else
                {
                    if (SaveEngineInformation(1))
                    {
                        lstVesselData = hdaDataAccess.GetVesselData();
                        vdeOldVesselEntity = new VesselInfoDataEntity();
                        var query = from a in lstVesselData
                                    where (a.VesselNo == inVesselNo && a.EngineNo == inEngineNo)
                                    select a;

                        foreach (var a in query)
                        {
                            vdeOldVesselEntity = a;
                        }
                        MessageBox.Show(Constants.SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region lblLubeMonInfo_LinkClicked
        private void lblLubeMonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SetResetBackGroundColorForLinks("LubeMonitor");
            //HideUnhidePanels(pnlSetting.Name);
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/Marine Connect Help Document V.2.0.pdf");
            process.Start();
        }
        #endregion

        #region tsTxtGraph_Click
        private void tsTxtGraph_Click(object sender, EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            SetEngineLabelNo();
            HideUnhidePanels(pnlGraph.Name);
            SetResetBackGroundColor(tsTxtGraph);

            try
            {
                
                if (chkCylinderNumber.Items.Count == 0)
                {
                    for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                    {
                        chkCylinderNumber.Items.Add("Cyl " + i.ToString(), true);
                    }
                }

                //if (cmbXAxis.SelectedIndex < 0)
                //{
                    //cmbXAxis.SelectedIndex = 0;
                //}
                //else
                //{
                txtRefBN.Text = "15";
                txtReferenceIron.Text = "200";
                PopulateGraph(cmbXAxis.SelectedItem.ToString(), false, "On-board Total Fe");
                    //cmbXAxis.SelectedIndex = 0;
                    //cmbIronAxis.SelectedIndex = 0;
                //}
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

        }
        #endregion

        #region lnkContactUs_LinkClicked
        private void lnkContactUs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            HideUnhidePanels(pnlConUs.Name);
            SetResetBackGroundColorForLinks("ContactUs");
        }
        #endregion

        #region lnkHere_LinkClicked
        private void lnkHere_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            chkCylinderNumber.Items.Clear();
            GetAllVesselData();
            SetResetBackGroundColorForLinks("Setting");
            HideUnhidePanels(pnlSetting.Name);
        }
        #endregion

        #region cmbEngineNo_SelectedIndexChanged
        private void cmbEngineNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbEngineNo.SelectedIndex > 0)
            //{
            //    inEngineNo = Convert.ToInt32(cmbEngineNo.SelectedItem.ToString());
            //}
        }
        #endregion             

        #region tsTxtHistory_Click
        private void tsTxtHistory_Click(object sender, System.EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            SetEngineLabelNo();
            HideUnhidePanels(pnlHistory.Name);
            SetResetBackGroundColor(tsTxtHistory);

            try
            {
                lstRunningData = hdaDataAccess.GetRunningData(inVesselNo, inEngineNo);

                lstCylinderData = hdaDataAccess.GetCylinderData(inVesselNo, inEngineNo);

                dtCylinderDataReadOnly = new DataTable();
                dtCylinderDataReadOnly.Columns.Add("Date");
                dtCylinderDataReadOnly.Columns.Add("Is Data Submitted");
                dtCylinderDataReadOnly.Columns.Add("Location");
                for (int j = 1; j <= vdeOldVesselEntity.NoOfCylinders; j++)
                {
                    //dtCylinderDataReadOnly.Columns.Add("Cyliner Number - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Magnetic Iron - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Corrosive Iron - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Total Iron - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Pmax - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Fuel Index - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Cooling Water Temp - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Liner Wall Temp Min - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Liner Wall Temp Max - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("Feedrate Setpoint - " + ((j).ToString()));
                    dtCylinderDataReadOnly.Columns.Add("BN Measured Onboard - " + ((j).ToString()));
                }
                dtCylinderDataReadOnly.Columns.Add("Tot Eng Hours");
                dtCylinderDataReadOnly.Columns.Add("RPM");
                dtCylinderDataReadOnly.Columns.Add("Power, kW");
                dtCylinderDataReadOnly.Columns.Add("% MCR");
                dtCylinderDataReadOnly.Columns.Add("Sulphur, %");
                dtCylinderDataReadOnly.Columns.Add("Catfines (Al + Si), ppm");
                dtCylinderDataReadOnly.Columns.Add("Vanadium Content, ppm");
                dtCylinderDataReadOnly.Columns.Add("Fuel Consump, kg/hr");
                dtCylinderDataReadOnly.Columns.Add("Rel Hum %");
                dtCylinderDataReadOnly.Columns.Add("Amb Temp °C");
                dtCylinderDataReadOnly.Columns.Add("Scav Air Temp°C");
                dtCylinderDataReadOnly.Columns.Add("Eng Room T°C");
                dtCylinderDataReadOnly.Columns.Add("Cylinder Oil Cons ltrs/day (measured)");
                dtCylinderDataReadOnly.Columns.Add("Feed Rate (measured/calculated),g/kWh");
                dtCylinderDataReadOnly.Columns.Add("Sample Sent To Lab");
                dtCylinderDataReadOnly.Columns.Add("No of Turbochargers in use");
                dtCylinderDataReadOnly.Columns.Add("Oil Grade");
                dtCylinderDataReadOnly.Columns.Add("Density");
                dtCylinderDataReadOnly.Columns.Add("Comments");

                int startPosOfCyl = 3;
                int cylColumnNo = 10;
                DataRow dr = dtCylinderDataReadOnly.NewRow();
               // CultureInfo cult = new CultureInfo("nl-NL");
                DateTime dtDOR = new DateTime();
                IFormatProvider nlDateFormat = CultureInfo.CurrentCulture.DateTimeFormat;


                foreach (RunningData rng in lstRunningData)
                {
                    dr = dtCylinderDataReadOnly.NewRow();
                    //dr[0] = ConvertToShortDate(rng.DateOfReading);
                    dtDOR = DateTime.Parse(rng.DateOfReading, culture);
                    dr[0] = dtDOR.ToString("dd-MMM-yyyy");
                    dr[1] = rng.IsDataSubmitted == 0 ? "No" : "Yes";
                    dr[2] = rng.PortSea;
                    var query = from a in lstCylinderData
                                where a.UniqueID == rng.UniqueId
                                select a;
                    int k = 0;

                    foreach (var a in query)
                    {
                        //dr[2 + (k*vdeOldVesselEntity.NoOfCylinders)] = a.AAReading;
                        //dr[3 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.PMax;
                        //dr[4 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.FuelIndex;
                        //dr[5 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.CoolingWaterTemp;
                        //dr[6 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.LinearWallTempMin;
                        //dr[7 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.LinearWallTempMax;
                        //dr[8 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.FederateSetPoint;
                        //dr[9 + (k * vdeOldVesselEntity.NoOfCylinders)] = a.BNMeasuredOnboard;
                        dr[startPosOfCyl + 0 + (k * cylColumnNo)] = a.MagneticIron;
                        dr[startPosOfCyl + 1 + (k * cylColumnNo)] = a.CorrosiveIron;
                        dr[startPosOfCyl + 2 +  (k * cylColumnNo)] = a.AAReading;
                        dr[startPosOfCyl + 3 + (k * cylColumnNo)] = a.PMax;
                        dr[startPosOfCyl + 4 + (k * cylColumnNo)] = a.FuelIndex;
                        dr[startPosOfCyl + 5 + (k * cylColumnNo)] = a.CoolingWaterTemp;
                        dr[startPosOfCyl + 6 + (k * cylColumnNo)] = a.LinearWallTempMin;
                        dr[startPosOfCyl + 7 + (k * cylColumnNo)] = a.LinearWallTempMax;
                        dr[startPosOfCyl + 8 + (k * cylColumnNo)] = a.FederateSetPoint;
                        dr[startPosOfCyl + 9 + (k * cylColumnNo)] = a.BNMeasuredOnboard;

                        k++;

                    }
                    k--;
                    k = startPosOfCyl + 9 + (k * cylColumnNo);
                    dr[k + 1] = rng.TotEngineHours;
                    dr[k + 2] = rng.CylinderRPM;
                    dr[k + 3] = rng.Power;
                    dr[k + 4] = rng.PercentMCR;
                    dr[k + 5] = rng.PercentS;
                    dr[k + 6] = rng.Catfines;
                    dr[k + 7] = rng.Vanadium;
                    dr[k + 8] = rng.Consumption;
                    dr[k + 9] = rng.RelativeHumidity;
                    dr[k + 10] = rng.AmbTemp;
                    dr[k + 11] = rng.ScavAirTemp;
                    dr[k + 12] = rng.EngRoomTemp;
                    dr[k + 13] = rng.CylinderOilConsump;
                    dr[k + 14] = rng.Federate;
                    dr[k + 15] = rng.SampleSentRCC;
                    dr[k + 16] = rng.NoOfTCInUse;
                    dr[k + 17] = rng.OilGrade;
                    dr[k + 18] = rng.Density;
                    dr[k + 19] = rng.Comments;
                    

                    dtCylinderDataReadOnly.Rows.Add(dr);

                }
                
                dgvReadOnlyHistory.DataSource = dtCylinderDataReadOnly;
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

        }
        #endregion

        #region dgvReadOnlyHistory_CellClick
        void dgvReadOnlyHistory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                HideUnhidePanels(pnlLogBookInfo.Name);
                SetResetBackGroundColor(tsTxtLogBookDetail);

                string strDOR = dgvReadOnlyHistory.CurrentCell.Value.ToString();
                strDOR = Convert.ToDateTime(strDOR, culture).ToString();
                PopulateLogBookDetail(strDOR);


                dgvCylinderData.DataSource = dtCylinderData;
                dgvCylinderData.Columns[Constants.CYLINDER_NUMBER_GRID].ReadOnly = true;
                dgvCylinderData.AllowUserToAddRows = false;
                lblIsNew.Text = "No";
            }
        }
        #endregion

        #region tsTxtSupport_Click
        private void tsTxtSupport_Click(object sender, EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            SetEngineLabelNo();
            HideUnhidePanels(pnlSupportInfo.Name);
            SetResetBackGroundColor(tsTxtSupport);

            //dgvCylInpsection.ReadOnly = true;

            PopulateSupportInformation("View");

            
        }
        #endregion

        #region PopulateSupportInformation
        private void PopulateSupportInformation(string mode)
        {
            string strDateOfReading = string.Empty;
            #region Bunker Information
            lstBunkerInfo = new List<BunkerInformation>();

            if (mode == "New")
            {
                dtpSupportInfo.Enabled = true;
            }
            else
            {
                dtpSupportInfo.Enabled = false;
            }

            lstBunkerInfo = hdaDataAccess.GetBunkerInformation(inVesselNo, inEngineNo);

            lstCylInspection = new List<CylinderInspection>();
            lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, inEngineNo);

            DateTime dateOfReading = Convert.ToDateTime(DateTime.Now.ToShortDateString(), CultureInfo.CurrentCulture);
            if (mode == "View" || mode == "New")
            {
                dateOfReading = Convert.ToDateTime("12/12/9999", culture);
                dtpSupportInfo.Text = System.DateTime.Today.ToShortDateString();
            }
            else
            {
                dateOfReading = Convert.ToDateTime(mode, culture);
                dtpSupportInfo.Value = dateOfReading;
            }
            
            var query = from a in lstBunkerInfo.AsEnumerable()
                        where ConvertToShortDate(a.DateBunkered) == ConvertToShortDate(dateOfReading.ToString())
                        select new { a.DateBunkered, a.QuantityBunkered, a.BDNSContent };

            dtBunkerInfo = new DataTable();
            //dtBunkerInfo.Columns.Add("Date Bunkered");
            dtBunkerInfo.Columns.Add(Constants.QUANTITY_BUNKERED_COL);
            dtBunkerInfo.Columns.Add(Constants.BDNS_CONTENT_COL);

            foreach (var a in query)
            {
                DataRow dr = dtBunkerInfo.NewRow();
                //dr["Date Bunkered"] = ConvertToShortDate(a.DateBunkered);
                //dr["Date Bunkered"] = ConvertToShortDate(a.DateBunkered);
                dr["Quantity Bunkered"] = a.QuantityBunkered;
                dr["Sulphur, %"] = a.BDNSContent;

                dtBunkerInfo.Rows.Add(dr);

            }

            if (dtBunkerInfo.Rows.Count == 0)
            {
                dtBunkerInfo.Rows.Add("","");
            }
            dtBunkerInfo.AcceptChanges();
            dgvBunkerInfo.DataSource = dtBunkerInfo;
            dgvBunkerInfo.AllowUserToAddRows = false;
            dgvBunkerInfo.ReadOnly = false;
            #endregion

            #region Running Hour
            DataTable dtRngHour = new DataTable();
            dtRngHour = GetRunningHourData(Convert.ToInt32(strNoOfCylinders), dateOfReading.ToString());

            dgvRunningHour.DataSource = dtRngHour;
            dgvRunningHour.AllowUserToAddRows = false;
            dgvRunningHour.ReadOnly = false;
            dgvRunningHour.Columns[0].ReadOnly = true;
            #endregion

            #region Linear Wear
            DataTable dtLinWear = new DataTable();
            dtLinWear = GetLinearWearData(Convert.ToInt32(strNoOfCylinders), dateOfReading.ToString());

            dgvLinearWear.DataSource = dtLinWear;
            dgvLinearWear.AllowUserToAddRows = false;
            dgvLinearWear.ReadOnly = false;
            dgvLinearWear.Columns[0].ReadOnly = true;
            #endregion

            #region Cylinder Inspection
            //DataTable dtCylInspection = new DataTable();
            //dtCylInspection = GetCylinderInspectionData(Convert.ToInt32(strNoOfCylinders), dateOfReading.ToString());

            //dgvCylInpsection.DataSource = dtCylInspection;
            //dgvCylInpsection.AllowUserToAddRows = false;
            //dgvCylInpsection.ReadOnly = true;
            
            chkLstCylInspection.Items.Clear();
            if (chkLstCylInspection.Items.Count == 0)
            {
                //for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                //{
                //    chkLstCylInspection.Items.Add("Cyl " + i.ToString(), false);
                //}

                chkLstCylInspection.Items.Add("Cylinders Inspected", false);

            }

            lstCylInspection = new List<CylinderInspection>();
            lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, inEngineNo);

            var cylQuery = from a in lstCylInspection
                        where ConvertToShortDate(a.DateOfInspection) == ConvertToShortDate(dateOfReading.ToString())
                        select a;

            foreach (CylinderInspection cylIns in cylQuery)
            {
                chkLstCylInspection.SetItemCheckState(cylIns.CylinderNumber - 1, CheckState.Checked);
            }

            if (mode == "New" ||  mode == "View")
            {
                //for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                //{
                //    chkLstCylInspection.SetItemCheckState(i - 1, CheckState.Unchecked);
                //}
                chkLstCylInspection.SetItemCheckState(0, CheckState.Unchecked);
            }

            //DataGridViewCheckBoxColumn chkColumn = new DataGridViewCheckBoxColumn();
            //chkColumn.Name = "Select";
            //chkColumn.TrueValue = true;
            //int columnIndex = 0;
            //if (dgvCylInpsection.Columns["Select"] == null)
            //{
            //    dgvCylInpsection.Columns.Insert(columnIndex, chkColumn);
            //}
            //dgvCylInpsection.Columns[1].ReadOnly = true;
            //dgvCylInpsection.Columns[2].ReadOnly = true;

            //foreach (DataGridViewRow dr in dgvCylInpsection.Rows)
            //{
            //    if (dr.Cells[2].Value.ToString() != string.Empty)
            //    {
            //        if (dr.Cells[2].Value.ToString() != System.DateTime.MaxValue.ToString())
            //        {
            //            DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dr.Cells[0];
            //            chk.Value = chk.TrueValue;
            //        }
            //        //else
            //        //{
            //        //    DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dr.Cells[0];
            //        //    chk.Value = false;
            //        //}
            //    }
            //    //else
            //    //{
            //    //    DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dr.Cells[0];
            //    //    chk.Value = false;
            //    //}
            //}
            #endregion
        }
        #endregion

        //#region dgvBunkerInfo_CellClick
        //private void dgvBunkerInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.ColumnIndex == 0 && e.RowIndex != -1)
        //    {
        //        dtp = new DateTimePicker();
        //        dgvBunkerInfo.Controls.Add(dtp);
        //        dtp.Format = DateTimePickerFormat.Short;
        //        Rectangle Rectangle = dgvBunkerInfo.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
        //        dtp.Size = new Size(Rectangle.Width, Rectangle.Height);
        //        dtp.Location = new Point(Rectangle.X, Rectangle.Y);

        //        // dtp.CloseUp += new EventHandler(dtp_CloseUp);
        //        dtp.TextChanged += new EventHandler(dtp_OnTextChange);
        //        dtp.KeyDown += dtp_KeyDown;


        //        dtp.Visible = true;
        //    }

        //}

        //void dtp_KeyDown(object sender, KeyEventArgs e)
        //{
        //    e.SuppressKeyPress = true;
        //}
        //#endregion

        //#region dtp_OnTextChange
        //private void dtp_OnTextChange(object sender, EventArgs e)
        //{

        //    dgvBunkerInfo.CurrentCell.Value = dtp.Value.ToShortDateString();
        //    dgvBunkerInfo.InvalidateCell(dgvBunkerInfo.CurrentCell);
        //    dtp.Visible = false;

        //}
        //#endregion

        //#region dtp_CloseUp
        //void dtp_CloseUp(object sender, EventArgs e)
        //{
        //    dtp.Visible = false;
        //}
        //#endregion

        #region btnSaveSupportInfo_Click
        private void btnSaveSupportInfo_Click(object sender, EventArgs e)
        {
            int inStatus = 0;
            bool update = true;
            List<SupportInformation> lstSupportInfo = new List<SupportInformation>();
            lstSupportInfo = hdaDataAccess.GetSupportInformation(inVesselNo, inEngineNo);

            try
            {
                if (!ValidateSupportDate())
                {
                    MessageBox.Show("Date of reading should be between the start and end date of the project", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int count1 = (from a in lstSupportInfo
                             where ConvertToShortDate(a.DateOfReading) == ConvertToShortDate(dtpSupportInfo.Value.ToString())
                             && a.VesselNo == inVesselNo
                             && a.EngineNo == inEngineNo
                             select a).Count();
                if (count1 > 0 && lblNewSupport.Text == "Yes")
                {
                    var confirmResult = MessageBox.Show("Data for this date already exists? Are you sure you want to overwrite?",
                                     "Confirm Overwrite",
                                     MessageBoxButtons.YesNo);
                    if (confirmResult == DialogResult.Yes)
                    {
                        hdaDataAccess.DeleteSupportInformation(inVesselNo, inEngineNo, dtpSupportInfo.Value.ToShortDateString());
                        update = true;
                    }
                    else
                    {
                        update = false;
                    }
                }

                if (update)
                {
                    if (count1 == 0)
                    {
                        inStatus = hdaDataAccess.InsertIntoSupportInformation(inVesselNo, inEngineNo, dtpSupportInfo.Value.ToShortDateString());
                    }
                    foreach (DataRow dr in dtBunkerInfo.Rows)
                    {
                        //if (dr["Date Bunkered"].ToString() != string.Empty)
                        //{
                        BunkerInformation bnkInfo = new BunkerInformation();
                        bnkInfo.VesselNo = inVesselNo;
                        bnkInfo.EngineNo = inEngineNo;
                        //bnkInfo.DateBunkered = dr["Date Bunkered"].ToString();
                        bnkInfo.DateBunkered = dtpSupportInfo.Value.ToString();
                        bnkInfo.QuantityBunkered = dr[Constants.QUANTITY_BUNKERED_COL].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.QUANTITY_BUNKERED_COL].ToString());
                        bnkInfo.BDNSContent = dr[Constants.BDNS_CONTENT_COL].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.BDNS_CONTENT_COL].ToString());
                        if (dr.RowState == DataRowState.Modified)
                        {
                            int count = (from a in lstBunkerInfo
                                         where ConvertToShortDate(a.DateBunkered) == dtpSupportInfo.Value.ToShortDateString()
                                         select a).Count();
                            if (count > 0)
                            {
                                inStatus = hdaDataAccess.UpdateBunkerInformation(bnkInfo);
                            }
                            else
                            {
                                inStatus = hdaDataAccess.InsertBunkerInformation(bnkInfo);
                            }
                        }
                        else if (dr.RowState == DataRowState.Added)
                        {
                            inStatus = hdaDataAccess.InsertBunkerInformation(bnkInfo);
                        }
                        //}
                    }
                    dtBunkerInfo.AcceptChanges();

                    if (inStatus == 0)
                    {
                        inStatus = SaveRunningHourData();

                        if (inStatus == 0)
                        {
                            inStatus = SaveLinearData();

                            if (inStatus == 0)
                            {
                                inStatus = SaveCylinderInspectionData();

                                if (inStatus == 0)
                                {
                                    MessageBox.Show(Constants.SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show(Constants.SAVE_FAILURE, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                dtpSupportInfo.Enabled = false;
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }


        }
        #endregion

        //#region dgvRunningHour_CellClick
        //private void dgvRunningHour_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.ColumnIndex == 1 && e.RowIndex != -1)
        //    {
        //        dtpRngHour = new DateTimePicker();
        //        dgvRunningHour.Controls.Add(dtpRngHour);
        //        dtpRngHour.Format = DateTimePickerFormat.Short;
        //        Rectangle Rectangle = dgvRunningHour.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
        //        dtpRngHour.Size = new Size(Rectangle.Width, Rectangle.Height);
        //        dtpRngHour.Location = new Point(Rectangle.X, Rectangle.Y);

        //        // dtp.CloseUp += new EventHandler(dtp_CloseUp);
        //        dtpRngHour.TextChanged += new EventHandler(dtpRngHour_OnTextChange);
        //        dtpRngHour.KeyDown += dtpRngHour_KeyDown;

        //        dtpRngHour.Visible = true;
        //    }

        //}

        //void dtpRngHour_KeyDown(object sender, KeyEventArgs e)
        //{
        //    e.SuppressKeyPress = true;
        //}
        //#endregion

        //#region dtpRngHour_OnTextChange
        //private void dtpRngHour_OnTextChange(object sender, EventArgs e)
        //{

        //    dgvRunningHour.CurrentCell.Value = dtpRngHour.Value.ToShortDateString();
        //    dgvRunningHour.InvalidateCell(dgvRunningHour.CurrentCell);
        //    dtpRngHour.Visible = false;

        //}
        //#endregion

        //#region dgvLinearWear_CellClick
        //private void dgvLinearWear_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.ColumnIndex == 1 && e.RowIndex != -1)
        //    {
        //        dtpLinearWear = new DateTimePicker();
        //        dgvLinearWear.Controls.Add(dtpLinearWear);
        //        dtpLinearWear.Format = DateTimePickerFormat.Short;
        //        Rectangle Rectangle = dgvLinearWear.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
        //        dtpLinearWear.Size = new Size(Rectangle.Width, Rectangle.Height);
        //        dtpLinearWear.Location = new Point(Rectangle.X, Rectangle.Y);

        //        // dtp.CloseUp += new EventHandler(dtp_CloseUp);
        //        dtpLinearWear.TextChanged += new EventHandler(dtpLinearWear_OnTextChange);
        //        dtpLinearWear.KeyDown += dtpLinearWear_KeyDown;

        //        dtpLinearWear.Visible = true;
        //    }

        //}

        //void dtpLinearWear_KeyDown(object sender, KeyEventArgs e)
        //{
        //    e.SuppressKeyPress = true;
        //}
        //#endregion

        //#region dtpLinearWear_OnTextChange
        //private void dtpLinearWear_OnTextChange(object sender, EventArgs e)
        //{

        //    dgvLinearWear.CurrentCell.Value = dtpLinearWear.Value.ToShortDateString();
        //    dgvLinearWear.InvalidateCell(dgvLinearWear.CurrentCell);
        //    dtpLinearWear.Visible = false;

        //}
        //#endregion

        //#region dgvCylInpsection_CellClick
        //private void dgvCylInpsection_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.ColumnIndex == 1 && e.RowIndex != -1)
        //    {
        //        dtpCylInspection = new DateTimePicker();
        //        dgvCylInpsection.Controls.Add(dtpCylInspection);
        //        dtpCylInspection.Format = DateTimePickerFormat.Short;
        //        Rectangle Rectangle = dgvCylInpsection.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
        //        dtpCylInspection.Size = new Size(Rectangle.Width, Rectangle.Height);
        //        dtpCylInspection.Location = new Point(Rectangle.X, Rectangle.Y);

        //        // dtp.CloseUp += new EventHandler(dtp_CloseUp);
        //        dtpCylInspection.TextChanged += new EventHandler(dtpCylInspection_OnTextChange);

        //        dtpCylInspection.KeyDown += dtpCylInspection_KeyDown;


        //        dtpCylInspection.Visible = true;
        //    }

        //}

        //void dtpCylInspection_KeyDown(object sender, KeyEventArgs e)
        //{
        //    e.SuppressKeyPress = true;
        //}
        //#endregion

        //#region dtpCylInspection_OnTextChange
        //private void dtpCylInspection_OnTextChange(object sender, EventArgs e)
        //{

        //    dgvCylInpsection.CurrentCell.Value = dtpCylInspection.Value.ToShortDateString();
        //    dgvCylInpsection.InvalidateCell(dgvCylInpsection.CurrentCell);
        //    dtpCylInspection.Visible = false;

        //}
        //#endregion

        #region btnSecondEngine_Click
        private void btnSecondEngine_Click(object sender, EventArgs e)
        {
            inEngineNo = 2;
            SetEngineLabelNo();
            HideUnhidePanels(pnlEngine2.Name);
            chkCylinderNumber.Items.Clear();
            SetResetBackGroundColor(tstxtEngInfo);
            PopulateSecondEngineData();
            
        }
        #endregion

        #region btnSaveEngine2_Click
        private void btnSaveEngine2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateSecondEngineInformation())
                {
                    return;
                }
                else
                {
                    if (SaveSecondEngineInformation())
                    {
                        lstVesselData = hdaDataAccess.GetVesselData();
                        vdeOldVesselEntity = new VesselInfoDataEntity();
                        var query = from a in lstVesselData
                                    where (a.VesselNo == inVesselNo && a.EngineNo == inEngineNo)
                                    select a;

                        foreach (var a in query)
                        {
                            vdeOldVesselEntity = a;
                        }
                        MessageBox.Show(Constants.SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region cmbOilGrade2_SelectedIndexChanged
        private void cmbOilGrade2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSelectedItem = string.Empty;
            if (cmbOilGrade2.SelectedIndex > 0)
            {
                strSelectedItem = cmbOilGrade2.SelectedItem.ToString();
            }

            txtDensity2.Text = GetDensityPerOilGrade(strSelectedItem);
        }
        #endregion

        #region btnFirstEngine_Click
        private void btnFirstEngine_Click(object sender, EventArgs e)
        {
            //Set the engine number to 1
            inEngineNo = 1;
            SetEngineLabelNo();
            chkCylinderNumber.Items.Clear();
            HideUnhidePanels(pnlEngineInfo.Name);
            SetResetBackGroundColor(tstxtEngInfo);
            PopulateVesselInformation();
            
        }
        #endregion        

        #region dgvProjectData_CellContentClick
        void dgvProjectData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            int inStatus = 0;
            int k;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                var confirmResult =  MessageBox.Show("Are you sure to delete this item ?",
                                     "Confirm Delete!!",
                                     MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    int inBeginIndex = senderGrid.CurrentRow.Cells[1].Value.ToString().LastIndexOf("-");
                    int inDelVesselNo = Convert.ToInt32(senderGrid.CurrentRow.Cells[1].Value.ToString().Substring(inBeginIndex + 1));

                    var query = (from a in lstVesselData
                                 where (a.VesselNo == inDelVesselNo)
                                 select a);

                    foreach (var t in query)
                    {
                        k = t.EngineNo;
                        inStatus = hdaDataAccess.DeleteProjectData(inDelVesselNo, k);
                    }
                    if (inStatus == 0)
                    {
                        MessageBox.Show(Constants.DELETE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    inVesselNo = 0;
                    PopulateVesselInformation();
                    GetAllVesselData();
                }
            }
           
        }
        #endregion

        #region btnSubmitData_Click
        private void btnSubmitData_Click(object sender, EventArgs e)
        {
            try
            {
                int k = 0;
                bool isDataAvailable = false;

                if (dtpDateTo.Value <= dtpDateFrom.Value)
                {
                    MessageBox.Show("Date To cannot be less than or equal to Date From", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                List<RunningData> lstRunData = new List<RunningData>();
                //Common.GenerateXMLForObject();
                var query = (from a in lstVesselData
                             where (a.VesselNo == inVesselNo)
                             select a);

                string strDateFrom = dtpDateFrom.Value.ToShortDateString();
                string strToDate = dtpDateTo.Value.ToShortDateString();

                foreach (var t in query)
                {
                    k = t.EngineNo;

                    lstRunData = hdaDataAccess.GetRunningData(inVesselNo, k);
                    var data = (from a in lstRunData
                                where Convert.ToDateTime(a.DateOfReading, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                && Convert.ToDateTime(a.DateOfReading, culture) <= Convert.ToDateTime(strToDate, culture)
                                select a).Count();

                    if (data > 0)
                    {
                        isDataAvailable = true;
                        break;
                    }
                    else
                    {
                        isDataAvailable = false;
                    }

                }
                if (isDataAvailable)
                {
                    GenerateXML();
                }
                else
                {
                    MessageBox.Show("There is no data for the time period selected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                //MessageBox.Show(Constants.FILE_SAVE_SUCCESS, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }
        #endregion

        #region tsTxtDataSubmission_Click
        private void tsTxtDataSubmission_Click(object sender, EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            SetEngineLabelNo();
            HideUnhidePanels(pnlDataSubmission.Name);
            SetResetBackGroundColor(tsTxtDataSubmission);


        }
        #endregion

        #region btnSubmitGraph_Click
        private void btnSubmitGraph_Click(object sender, EventArgs e)
        {
            if (!IsNumber(txtReferenceIron.Text))
            {
                MessageBox.Show("Reference value must be a number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtReferenceIron.Text = "200";
                return;
            }
            if (!IsNumber(txtRefBN.Text))
            {
                MessageBox.Show("Reference value must be a number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRefBN.Text = "15";
                return;
            }
            PopulateGraph(cmbXAxis.SelectedItem.ToString(), true, cmbIronAxis.SelectedItem.ToString());
        }
        #endregion

        #region cmbXAxis_SelectedIndexChanged
        private void cmbXAxis_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateGraph(cmbXAxis.SelectedItem.ToString(), true , cmbIronAxis.SelectedItem.ToString());
        }
        #endregion

        #region txtPercentS_Leave
        private void txtPercentS_Leave(object sender, EventArgs e)
        {

            if (txtPercentS.Text != string.Empty && ValidateNumberFormat(txtPercentS) && Convert.ToDouble(txtPercentS.Text) > 6.0)
            {
                MessageBox.Show("Sulphur,% should be less than 6.0", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPercentS.Text = string.Empty;
                //return false;
            }
        }
        #endregion

        private void txtPower_Validating(object sender, CancelEventArgs e)
        {
            if (txtPower.Text != string.Empty && ValidateNumberFormat(txtPower) && Convert.ToDouble(txtPower.Text) >= 100000)
            {
                MessageBox.Show("Power should be less than 100,000", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPower.Text = string.Empty;
            }
        }

        private void txtCatfines_Validating(object sender, CancelEventArgs e)
        {
            ValidateNumberFormat(txtCatfines);
        }

        private void txtVanadium_Validating(object sender, CancelEventArgs e)
        {
            ValidateNumberFormat(txtVanadium);
        }

        private void txtConsump_Validating(object sender, CancelEventArgs e)
        {
            if (ValidateNumberFormat(txtConsump))
            {
                txtTotalEngineHours.Focus();
            }
        }

        private void txtTotalEngineHours_Validating(object sender, CancelEventArgs e)
        {
            ValidateNumberFormat(txtTotalEngineHours);
        }

        private void txtCylinderRPM_Validating(object sender, CancelEventArgs e)
        {
            if(txtCylinderRPM.Text != string.Empty && ValidateNumberFormat(txtCylinderRPM) && Convert.ToDouble(txtCylinderRPM.Text) >= 150)
            {
                MessageBox.Show("RPM should be less than 150", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCylinderRPM.Text = string.Empty;
            }
        }

        private void txtRelHumidity_Validating(object sender, CancelEventArgs e)
        {
            if (txtRelHumidity.Text != string.Empty && ValidateNumberFormat(txtRelHumidity) && Convert.ToDouble(txtRelHumidity.Text) >= 100)
            {
                MessageBox.Show("Relative Humidity should be less than 100", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRelHumidity.Text = string.Empty;
            }
        }

        private void txtAmpTemp_Validating(object sender, CancelEventArgs e)
        {
            if (txtAmpTemp.Text != string.Empty && ValidateNumberFormat(txtAmpTemp) && Convert.ToDouble(txtAmpTemp.Text) >= 60)
            {
                MessageBox.Show("Ambient Temperature should be less than 60", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAmpTemp.Text = string.Empty;
            }
        }

        private void txtScavAirTemp_Validating(object sender, CancelEventArgs e)
        {
            if (txtScavAirTemp.Text != string.Empty && ValidateNumberFormat(txtScavAirTemp) && Convert.ToDouble(txtScavAirTemp.Text) >= 80)
            {
                MessageBox.Show("Scav Air Temperature should be less than 80", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtScavAirTemp.Text = string.Empty;
            }
        }

        private void txtEngRoomTemp_Validating(object sender, CancelEventArgs e)
        {
            if (txtEngRoomTemp.Text != string.Empty && ValidateNumberFormat(txtEngRoomTemp) && Convert.ToDouble(txtEngRoomTemp.Text) >= 80)
            {
                MessageBox.Show("Eng Room Temperature should be less than 80", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEngRoomTemp.Text = string.Empty;
            }
        }

        private void txtCylinderOilCons_Validating(object sender, CancelEventArgs e)
        {
            if (txtCylinderOilCons.Text != string.Empty && ValidateNumberFormat(txtCylinderOilCons) && Convert.ToDouble(txtCylinderOilCons.Text) >= 1000)
            {
                MessageBox.Show("Cylinder Oil Consumption should be less than 1,000", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCylinderOilCons.Text = string.Empty;
            }
        }

        private void txtNoOfTCInUse_Validating(object sender, CancelEventArgs e)
        {
            Regex expression;
            string strToBeValidated = txtNoOfTCInUse.Text;
            if (strToBeValidated != string.Empty)
            {
                //if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                //{
                    expression = new Regex("^\\d+$");
                //}
                //else
                //{
                //    expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                //}
                if (!expression.IsMatch(strToBeValidated))
                {
                    MessageBox.Show("The Value must be a number with no decimals", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNoOfTCInUse.Text = string.Empty;

                }
                else
                {
                    if (Convert.ToDouble(txtNoOfTCInUse.Text) >= 5)
                    {
                        MessageBox.Show("No. of turbo engines should be less than 5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtNoOfTCInUse.Text = string.Empty;
                    }
                }
            }
        }

        private void dtpTargetEndDate_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void dtDateOfReading_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void dtpDateDelivered2_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void dtDateDelivered_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void dtpStartDate_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void cmbNoOfEngines_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dtpSupportInfo_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        
        private void btnAddNewSupport_Click(object sender, EventArgs e)
        {
            dtpSupportInfo.Text = System.DateTime.Today.ToShortDateString();
            PopulateSupportInformation("New");
            lblNewSupport.Text = "Yes";
        }

        private void tsTxtSupportHistory_Click(object sender, EventArgs e)
        {
            if (inVesselNo == 0)
            {
                MessageBox.Show("Please select a project from the settings!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            SetEngineLabelNo();
            HideUnhidePanels(pnlSupportHistory.Name);
            SetResetBackGroundColor(tsTxtSupportHistory);
            List<SupportInformation> lstSupportInfo = new List<SupportInformation>();

            try
            {
                lstRngHour = hdaDataAccess.GetRunningHour(inVesselNo, inEngineNo);
                lstLinearWear = hdaDataAccess.GetLinearWear(inVesselNo, inEngineNo);
                lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, inEngineNo);
                lstBunkerInfo = hdaDataAccess.GetBunkerInformation(inVesselNo, inEngineNo);
                lstSupportInfo = hdaDataAccess.GetSupportInformation(inVesselNo, inEngineNo);

                DataTable dtSupportDataReadOnly = new DataTable();
                dtSupportDataReadOnly.Columns.Add("Date");
                dtSupportDataReadOnly.Columns.Add("Quantity Bunkered");
                dtSupportDataReadOnly.Columns.Add("Sulphur, %");
                dtSupportDataReadOnly.Columns.Add("Date of Inspection");

                for (int j = 1; j <= vdeOldVesselEntity.NoOfCylinders; j++)
                {
                    //dtCylinderDataReadOnly.Columns.Add("Cyliner Number - " + ((j).ToString()));
                    dtSupportDataReadOnly.Columns.Add("Liner - " + ((j).ToString()));
                    dtSupportDataReadOnly.Columns.Add("Piston Ring - " + ((j).ToString()));
                    dtSupportDataReadOnly.Columns.Add("Piston Crown - " + ((j).ToString()));
                    dtSupportDataReadOnly.Columns.Add("Forward - " + ((j).ToString()));
                    dtSupportDataReadOnly.Columns.Add("Port/Starboard - " + ((j).ToString()));
                    //dtSupportDataReadOnly.Columns.Add("Cylinder Inspection - " + ((j).ToString()));

                }

                dtSupportDataReadOnly.AcceptChanges();

                DataRow dr = dtSupportDataReadOnly.NewRow();

                var query = (from a in lstSupportInfo.AsEnumerable()
                             select new { a.DateOfReading }).Distinct();
                DateTime dtDOR = new DateTime();

                foreach (var dt in query)
                {
                    dr = dtSupportDataReadOnly.NewRow();
                    //string strCurrDate = string.Empty;
                    string strCurrDate = ConvertToShortDate(dt.DateOfReading.ToString());
                    dtDOR = DateTime.Parse(dt.DateOfReading, culture);
                    //strCurrDate = dtDOR.ToString("dd-MMM-yyyy");
                    dr[0] = dtDOR.ToString("dd-MMM-yyyy");

                    var bunkerInfo = from a in lstBunkerInfo
                                     where ConvertToShortDate(a.DateBunkered) == strCurrDate
                                     select a;
                    //int k = 0;

                    foreach (var b in bunkerInfo)
                    {
                        dr[1] = b.QuantityBunkered;
                        dr[2] = b.BDNSContent;
                    }
                    var cylInsp = (from c in lstCylInspection
                                   where ConvertToShortDate(c.DateOfInspection) == strCurrDate && c.CylinderNumber == 1
                                   select c).FirstOrDefault();
                    if (cylInsp != null)
                    {
                        dr[3] = ConvertToShortDate(cylInsp.DateOfInspection);
                    }
                    else
                    {
                        dr[3] = string.Empty;
                    }


                    for (int i = 0; i < Convert.ToInt32(strNoOfCylinders); i++)
                    {
                        var rnghr = from r in lstRngHour
                                    where ConvertToShortDate(r.ReadingDate) == strCurrDate && r.CylinderNumber == i + 1
                                    select r;
                        foreach (var x in rnghr)
                        {
                            dr[4 + (i * 5)] = x.Liner;
                            dr[5 + (i * 5)] = x.Prings;
                            dr[6 + (i * 5)] = x.PCrown;
                        }

                        var linWear = from l in lstLinearWear
                                      where ConvertToShortDate(l.DateMeasured) == strCurrDate && l.CylinderNumber == i + 1
                                      select l;
                        foreach (var y in linWear)
                        {
                            dr[7 + (i * 5)] = y.Forward;
                            dr[8 + (i * 5)] = y.PortStarBoard;
                        }

                        //var cylInsp = from c in lstCylInspection
                        //              where ConvertToShortDate(c.DateOfInspection) == strCurrDate && c.CylinderNumber == i + 1
                        //              select c;
                        //foreach (var z in cylInsp)
                        //{
                        //    dr[8 + (i * 6)] = ConvertToShortDate(z.DateOfInspection);
                        //}
                    }


                    dtSupportDataReadOnly.Rows.Add(dr);

                }
                dgvSupportHistReadOnly.DataSource = dtSupportDataReadOnly;
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }
        }

        private void dgvSupportHistReadOnly_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                HideUnhidePanels(pnlSupportInfo.Name);
                SetResetBackGroundColor(tsTxtSupport);

                string strDOR = dgvSupportHistReadOnly.CurrentCell.Value.ToString();
                strDOR = Convert.ToDateTime(strDOR, culture).ToString();
                PopulateSupportInformation(strDOR);
                lblNewSupport.Text = "No";
            }
        }

        private void cmbSampleForRCC_KeyDown(object sender, KeyEventArgs e)
        {
            //e.SuppressKeyPress = true;
        }

        void dgvCylInpsection_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.ColumnIndex == 0 && e.RowIndex > -1)
            //{
            //    DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)dgvCylInpsection.Rows[e.RowIndex].Cells[e.ColumnIndex];
            //    if (chk.Value == chk.TrueValue)
            //    {
            //        dgvCylInpsection.Rows[e.RowIndex].Cells[2].Value = dtpSupportInfo.Value.ToShortDateString();
            //    }
            //    else
            //    {
            //        dgvCylInpsection.Rows[e.RowIndex].Cells[2].Value = string.Empty;
            //    }
            //    lblCylInfoSupport.Focus();
            //}
        }

        private void txtComments_Validating(object sender, CancelEventArgs e)
        {
            btnSaveData.Focus();
        }

        private void cmbNoOfCyl_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void cmbNoOfEngines_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        void dgvProjectData_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            //dgvProjectData.ClearSelection();
        }

        private void imgHeader_Click(object sender, EventArgs e)
        {
            SetResetBackGroundColorForLinks("");
            HideUnhidePanels(pnlHome.Name);
        }

        private void dtpDateFrom_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void dtpDateTo_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void lnkTandC_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //HideUnhidePanels(pnlTermsAndConditions.Name);
            SetResetBackGroundColorForLinks("TermsAndConditions");
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/Shell Marine Connect Licence Agreement V1.0.pdf");
            process.Start();
        }

        #endregion

        #region PRIVATE METHODS

        #region GenerateXML
        private void GenerateXML()
        {
            string strFileSavedMessage = string.Empty;
            string strDateFrom = dtpDateFrom.Value.ToShortDateString();
            string strToDate = dtpDateTo.Value.ToShortDateString();
            int inNoOfEngines = (from a in lstVesselData
                                 where (a.VesselNo == inVesselNo)
                                 select a).Count();
            List<VesselDataForSubmission> lstVesselDataForSubmission = new List<VesselDataForSubmission>();
            VesselDataForSubmission vslDataForSub = new VesselDataForSubmission();
            VesselInfoDataEntity vdeForSub = new VesselInfoDataEntity();
            RunningDataForSubmission rngSub = new RunningDataForSubmission();
            List<RunningDataForSubmission> lstRngSub = new List<RunningDataForSubmission>();
            List<CylinderInspection> newlstCylInspec = new List<CylinderInspection>();
            CylinderInspection cylIns = new CylinderInspection();

            try
            {

                for (int k = 1; k <= inNoOfEngines; k++)
                {
                    vslDataForSub = new VesselDataForSubmission();
                    vdeForSub = new VesselInfoDataEntity();
                    rngSub = new RunningDataForSubmission();
                    lstRngSub = new List<RunningDataForSubmission>();
                    newlstCylInspec = new List<CylinderInspection>();
                    cylIns = new CylinderInspection();

                    var query = from a in lstVesselData
                                where (a.VesselNo == inVesselNo && a.EngineNo == k)
                                select a;
                    if (query.Count() > 0)
                    { 
                        foreach (var a in query)
                        {
                            vdeForSub = a;                           
                        }


                        vdeForSub.DateDelivered = ConvertDateFormatForXML(vdeForSub.DateDelivered);
                        vdeForSub.StartDateOfProj = ConvertDateFormatForXML(vdeForSub.StartDateOfProj);
                        vdeForSub.TargetCompletionDate = ConvertDateFormatForXML(vdeForSub.TargetCompletionDate);
                        vslDataForSub.CoverPage = vdeForSub;
                        vslDataForSub.CoverPage = Common.ReplaceEmptyStringWithDash(vslDataForSub.CoverPage);
                        

                        #region Log Book Detail

                        lstRunningData = hdaDataAccess.GetRunningData(inVesselNo, k);

                        var data = from a in lstRunningData
                                   where Convert.ToDateTime(a.DateOfReading, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                    && Convert.ToDateTime(a.DateOfReading, culture) <= Convert.ToDateTime(strToDate, culture)
                                   select a;

                        lstCylinderData = hdaDataAccess.GetCylinderData(inVesselNo, k);


                        foreach (RunningData rng in data)
                        {
                            rngSub = new RunningDataForSubmission();
                            rngSub.AmbTemp = rng.AmbTemp;
                            rngSub.Catfines = rng.Catfines;
                            rngSub.Comments = rng.Comments == string.Empty? "-" : rng.Comments;
                            rngSub.Consumption = rng.Consumption;
                            rngSub.CylinderOilConsump = rng.CylinderOilConsump;
                            rngSub.CylinderRPM = rng.CylinderRPM;
                            rngSub.DateOfReading = ConvertDateFormatForXML(rng.DateOfReading);
                            rngSub.EngineNo = rng.EngineNo;
                            rngSub.EngRoomTemp = rng.EngRoomTemp;
                            rngSub.Federate = rng.Federate;
                            rngSub.NoOfCylinders = rng.NoOfCylinders;
                            rngSub.NoOfTCInUse = rng.NoOfTCInUse;
                            rngSub.PercentMCR = rng.PercentMCR;
                            rngSub.PercentS = rng.PercentS;
                            rngSub.PortSea = rng.PortSea;
                            rngSub.Power = rng.Power;
                            rngSub.RelativeHumidity = rng.RelativeHumidity;
                            rngSub.SampleSentRCC = rng.SampleSentRCC == "Yes" ? "1" : "0";
                            rngSub.ScavAirTemp = rng.ScavAirTemp;
                            rngSub.TotEngineHours = rng.TotEngineHours;
                            rngSub.UniqueId = rng.UniqueId;
                            rngSub.Vanadium = rng.Vanadium;
                            rngSub.VesselNo = rng.VesselNo;
                            #region Change to include Oil Grade and Density at sample date level
                            rngSub.OilGrade = rng.OilGrade == string.Empty ? "-" : rng.OilGrade ;
                            rngSub.Density = rng.Density == string.Empty ? "-" : rng.Density;
                            #endregion

                            var query1 = from b in lstCylinderData
                                         where b.UniqueID == rng.UniqueId
                                         select b;
                            List<CylinderData> lstCylTemp = new List<CylinderData>();

                            foreach (CylinderData b in query1)
                            {
                                lstCylTemp.Add(b);
                            }
                            rngSub.lstCylinders = lstCylTemp;

                            lstRngSub.Add(rngSub);
                        }

                        vslDataForSub.LogBookDetail = lstRngSub;
                        #endregion

                        #region Bunker Informaion

                        lstBunkerInfo = hdaDataAccess.GetBunkerInformation(inVesselNo, k);

                        var bunkerData = from b in lstBunkerInfo
                                         where Convert.ToDateTime(b.DateBunkered, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                        && Convert.ToDateTime(b.DateBunkered, culture) <= Convert.ToDateTime(strToDate, culture)
                                         select b;

                        foreach (var bnk in bunkerData)
                        {
                            bnk.DateBunkered = ConvertDateFormatForXML(bnk.DateBunkered);
                        }

                        vslDataForSub.BunkerInfoForSubmission = bunkerData.ToList();
                        #endregion

                        #region Running Hour
                        RngHourForSubmission rngSubmission = new RngHourForSubmission();
                        List<RngHourForSubmission> lstRngHourForSub = new List<RngHourForSubmission>();
                        //Result res = new Result();

                        List<Test1> lstTest = new List<Test1>();
                        Test1 tst = new Test1();
                        Result result = new Result();
                        
                        lstRngHour = hdaDataAccess.GetRunningHour(inVesselNo, k);
                        var rngHourData = from c in lstRngHour
                                          where Convert.ToDateTime(c.ReadingDate, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                            && Convert.ToDateTime(c.ReadingDate, culture) <= Convert.ToDateTime(strToDate, culture)
                                          select c;

                        foreach (var rng in rngHourData)
                        {
                            //rngSubmission = new RngHourForSubmission();
                            //rngSubmission.VesselNo = rng.VesselNo;
                            //rngSubmission.EngineNo = rng.EngineNo;
                            //rngSubmission.CylinderNumber = rng.CylinderNumber;
                            rng.ReadingDate = ConvertDateFormatForXML(rng.ReadingDate);
                            //tst = new Test1();
                            //result = new Result();
                            //tst.ID = 526;
                            //tst.Name = "Liner";
                            //result.Value = rng.Linear;
                            //tst.Result = result;
                            //lstTest.Add(tst);

                            //tst = new Test1();
                            //result = new Result();
                            //tst.ID = 526;
                            //tst.Name = "Prings";
                            //result.Value = rng.Prings;
                            //tst.Result = result;
                            //lstTest.Add(tst);

                            //tst = new Test1();
                            //result = new Result();
                            //tst.ID = 526;
                            //tst.Name = "PCrown";
                            //result.Value = rng.PCrown;
                            //tst.Result = result;
                            //lstTest.Add(tst);
                            ////rngHourOnEng.ID = 526;
                            ////rngHourOnEng.Name = "Running Hour On Engine";
                            ////cylPart = new CylinderPart();
                            ////cylPart.Id = "Liner";
                            ////cylPart.Value = rng.Linear;
                            ////lstCylPart.Add(cylPart);

                            ////cylPart = new CylinderPart();
                            ////cylPart.Id = "Prings";
                            ////cylPart.Value = rng.Prings;
                            ////lstCylPart.Add(cylPart);

                            ////cylPart = new CylinderPart();
                            ////cylPart.Id = "PCrown";
                            ////cylPart.Value = rng.PCrown;
                            ////lstCylPart.Add(cylPart);

                            ////res.cylPart = lstCylPart;



                            //rngSubmission.Test = lstTest;
                            //lstRngHourForSub.Add(rngSubmission);
                            
                        }
                        vslDataForSub.RunningHourData = rngHourData.ToList();
                        #endregion

                        #region Linear Wear
                        lstLinearWear = hdaDataAccess.GetLinearWear(inVesselNo, k);
                        var linearData = from d in lstLinearWear
                                         where Convert.ToDateTime(d.DateMeasured, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                            && Convert.ToDateTime(d.DateMeasured, culture) <= Convert.ToDateTime(strToDate, culture)
                                         select d;

                        foreach (var lin in linearData)
                        {
                            lin.DateMeasured = ConvertDateFormatForXML(lin.DateMeasured);
                        }
                        vslDataForSub.LinearWearForSubmission = linearData.ToList();
                        #endregion

                        #region Cylinder Inspection
                        lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, k);
                        var cylInspData = from e in lstCylInspection
                                          where Convert.ToDateTime(e.DateOfInspection, culture) >= Convert.ToDateTime(strDateFrom, culture)
                                            && Convert.ToDateTime(e.DateOfInspection, culture) <= Convert.ToDateTime(strToDate, culture)
                                          select e;

                        for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                        {
                            var maxDate = (from q in cylInspData
                                      where q.CylinderNumber == i
                                      select q).Max(x => x.DateOfInspection);

                            cylIns = (from a in lstCylInspection
                                      where a.CylinderNumber == i
                                      && a.DateOfInspection == maxDate
                                      select a).FirstOrDefault();
                            if (cylIns != null)
                            {
                                newlstCylInspec.Add(cylIns);
                            }
                        }
                        foreach (var cyl in newlstCylInspec)
                        {
                            cyl.DateOfInspection = ConvertDateFormatForXML(cyl.DateOfInspection);
                        }
                        vslDataForSub.CylInspecForSubmission = newlstCylInspec;
                        #endregion

                        lstVesselDataForSubmission.Add(vslDataForSub);
                    }

                    hdaDataAccess.UpdateRunningDataForSubmission(inVesselNo, k, strDateFrom, strToDate);
                }
                string strDataForSubmission = string.Empty;
                strDataForSubmission = Common.ConvertToXML(lstVesselDataForSubmission);

                

                SaveFileDialog sfdXMLData = new SaveFileDialog();
                sfdXMLData.Filter = "XML File | (*.xml)";
                sfdXMLData.Title = "Save XML Data";
                sfdXMLData.ShowHelp = true;

                string strFileName = vdeForSub.VesselName + "_" + vdeForSub.VesselID + "_" + DateTime.Today.Day + "-" +
                    DateTime.Today.Month + "-" + DateTime.Today.Year + ".xml";
                sfdXMLData.FileName = strFileName;
                System.Windows.Forms.DialogResult result1 = sfdXMLData.ShowDialog();
                if (result1 == System.Windows.Forms.DialogResult.OK)
                {
                    //string path = Path.GetFullPath("Files/" + sfdXMLData.FileName);
                    string strNewFileName = sfdXMLData.FileName.Substring(sfdXMLData.FileName.LastIndexOf("\\") + 1);
                    if (strFileName != strNewFileName)
                    {
                        strFileSavedMessage = "You cannot change the file name. File has been saved with the name " + strFileName;
                        sfdXMLData.FileName = sfdXMLData.FileName.Substring(0, sfdXMLData.FileName.LastIndexOf("\\") + 1) + strFileName;
                    }
                    System.IO.File.WriteAllText(sfdXMLData.FileName, strDataForSubmission);
                    lblFileSavedMessage.Text = strFileSavedMessage;
                    lblFileLocation.Text = "File has been saved at the location " + sfdXMLData.FileName.Substring(0, sfdXMLData.FileName.LastIndexOf("\\"));
                    fileName = sfdXMLData.FileName;
                    //m_Worker.RunWorkerAsync(sfdXMLData.FileName);    
                }
            }
            catch (Exception ex)
            {
                Common.WriteTextFile(ex, Common.strUser);
            }

            
        }
        #endregion

        #region SetButtonBackgroundColors
        internal static void SetButtonBackgroundColors(Control f, Color color)
        {
            foreach (Control c in f.Controls)
            {

                // MessageBox.Show(c.GetType().ToString());
                if (c.HasChildren)
                {
                    SetButtonBackgroundColors(c, color);
                }
                else
                    if (c is Button)
                    {
                        Button lll = (Button)c;
                        lll.BackColor = color;
                    }
            }
        }

        private void SetButtonBackgroundColors()
        {
            foreach (Control cont in this.Controls)
            {
                if (cont.HasChildren)
                {
                    foreach (Control contChild in cont.Controls)
                        if (contChild.GetType() == typeof(Button))
                            contChild.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(46)))), ((int)(((byte)(18)))));
                }
                if (cont.GetType() == typeof(Button))
                    cont.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(46)))), ((int)(((byte)(18)))));
            }

            //this.btnSaveData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(46)))), ((int)(((byte)(18)))));
        }
        #endregion

        #region HideUnhidePanels
        private void HideUnhidePanels(string strVisiblePanel)
        {
            pnlEngineInfo.Visible = false;
            pnlLogBookInfo.Visible = false;
            pnlSetting.Visible = false;
            pnlGraph.Visible = false;
            pnlConUs.Visible = false;
            pnlHistory.Visible = false;
            pnlSupportInfo.Visible = false;
            pnlHome.Visible = false;
            pnlEngine2.Visible = false;
            pnlDataSubmission.Visible = false;
            pnlSupportHistory.Visible = false;
            pnlTermsAndConditions.Visible = false;
            pnlProgramInfo.Visible = false;

            switch (strVisiblePanel)
            {
                case "pnlEngineInfo":
                    {
                        pnlEngineInfo.Visible = true;
                        break;
                    }
                case "pnlLogBookInfo":
                    {
                        pnlLogBookInfo.Visible = true;
                        break;
                    }
                case "pnlSetting":
                    {
                        pnlSetting.Visible = true;
                        break;
                    }
                case "pnlGraph":
                    {
                        pnlGraph.Visible = true;
                        break;
                    }
                case "pnlConUs":
                    {
                        pnlConUs.Visible = true;
                        break;
                    }
                case "pnlHistory":
                    {
                        pnlHistory.Visible = true;
                        break;
                    }
                case "pnlSupportInfo":
                    {
                        pnlSupportInfo.Visible = true;
                        break;
                    }
                case "pnlHome":
                    {
                        pnlHome.Visible = true;
                        break;
                    }
                case "pnlEngine2":
                    {
                        pnlEngine2.Visible = true;
                        break;
                    }
                case "pnlDataSubmission":
                    {
                        pnlDataSubmission.Visible = true;
                        break;
                    }
                case "pnlSupportHistory":
                    {
                        pnlSupportHistory.Visible = true;
                        break;
                    }
                case "pnlTermsAndConditions":
                    {
                        pnlTermsAndConditions.Visible = true;
                        break;
                    }
                case "pnlProgramInfo":
                    {
                        pnlProgramInfo.Visible = true;
                        break;
                    }
                default:
                    {
                        pnlSetting.Visible = true;
                        break;
                    }
            }

            if (strProjectStatus == "Closed")
            {
                EnableDisableButtonsForReadonly(this, false);
            }
            else
            {
                EnableDisableButtonsForReadonly(this, true);
            }
        }

        
        #endregion

         #region SetEngineLabelNo
        private void SetEngineLabelNo()
        {
            string strEngineNo = "Engine Number - " + inEngineNo.ToString();
            lblEngineNoFirstEng.Text = strEngineNo;
            lblEngineNoHistory.Text = strEngineNo;
            lblEngineNoLogBook.Text = strEngineNo;
            lblEngineNoSup.Text = strEngineNo;
            lblSecondEngine.Text = strEngineNo;
            lblEngNoGraph.Text = strEngineNo;
            lblSupportHistEngNo.Text = strEngineNo;
        }
        #endregion

        #region PopulateVesselInformation
        private void PopulateVesselInformation()
        {
            int engNo = 0;
            if (inEngineNo != 0)
            {
                engNo = inEngineNo;
            }
            else
            {
                var query1 = from a in lstVesselData
                            where (a.VesselNo == inVesselNo)
                            select a;
                foreach (var b in query1)
                {
                    engNo = b.EngineNo;
                    inEngineNo = engNo;
                    break;
                }
            }

            if (inVesselNo == 0)
            {
                cmbNoOfEngines.Enabled = true;
                cmbNoOfCyl.Enabled = true;
            }
            else
            {
                cmbNoOfEngines.Enabled = false;
                cmbNoOfCyl.Enabled = false;
            }
            vdeOldVesselEntity = new VesselInfoDataEntity();
            var query = from a in lstVesselData
                        where (a.VesselNo == inVesselNo && a.EngineNo == engNo)
                        select a;

            foreach (var a in query)
            {
                vdeOldVesselEntity = a;
            }

            if (vdeOldVesselEntity != null)
            {
                //Setting
                txtCompName.Text = vdeOldVesselEntity.CompanyName;
                txtNoOfVessels.Text = vdeOldVesselEntity.NoOfVessels;
                txtCustomerContact.Text = vdeOldVesselEntity.CustomerContact;
                txtCustAddress.Text = vdeOldVesselEntity.Address;
                txtCustEmail.Text = vdeOldVesselEntity.Email;
                txtCustTelephone.Text = vdeOldVesselEntity.Telephone;
                txtSMPContact.Text = vdeOldVesselEntity.SMPContactName;
                dtpStartDate.Text = vdeOldVesselEntity.StartDateOfProj;
                dtpTargetEndDate.Text = vdeOldVesselEntity.TargetCompletionDate;
                txtSMPAddress.Text = vdeOldVesselEntity.SMPAddress;
                txtSMPEMail.Text = vdeOldVesselEntity.SMPEmail;
                txtSMPPhone.Text = vdeOldVesselEntity.SMPTelephone;
                txtSettingVesselName.Text = vdeOldVesselEntity.VesselName;
                txtSettingVslId.Text = vdeOldVesselEntity.VesselID;
                txtSettingIMONumber.Text = vdeOldVesselEntity.IMONo;
                //Engine information
                txtVesselName.Text = vdeOldVesselEntity.VesselName;
                txtIMONo.Text = vdeOldVesselEntity.IMONo;
                txtVesselId.Text = vdeOldVesselEntity.VesselID;
                dtDateDelivered.Text = vdeOldVesselEntity.DateDelivered;
                if (vdeOldVesselEntity.MainEngManuf == null || vdeOldVesselEntity.MainEngManuf == string.Empty)
                {
                    cmbEngManuf.SelectedIndex = 0;
                }
                else
                {
                    cmbEngManuf.SelectedItem = vdeOldVesselEntity.MainEngManuf;
                }
                
                txtMainEngType.Text = vdeOldVesselEntity.MainEngType;
                txtMainEngSerialNo.Text = vdeOldVesselEntity.MainEngSerialNo;
                txtMainEngLoc.Text = vdeOldVesselEntity.MainEngLoc;
                txtMainEngNo.Text = vdeOldVesselEntity.MainEngNo;
                txtMCR.Text = vdeOldVesselEntity.MCR;
                txtRPM.Text = vdeOldVesselEntity.RPM;
                txtLubType.Text = vdeOldVesselEntity.LubricatorType;
                txtMinFeedRate.Text = vdeOldVesselEntity.MinFeedRate;
                txtCurrentFeedRate.Text = vdeOldVesselEntity.CurrentFeedRate;
                txtTargetFeedRate.Text = vdeOldVesselEntity.TargetFeedRate;
                //if (vdeOldVesselEntity.OilGrade == null || vdeOldVesselEntity.OilGrade == string.Empty)
                //{
                //    //cmbOilGrade.SelectedIndex = 0;
                //}
                //else
                //{
                //    //cmbOilGrade.SelectedItem = vdeOldVesselEntity.OilGrade;
                //}
                //txtDensity.Text = vdeOldVesselEntity.Density;
                txtNoOfTC.Text = vdeOldVesselEntity.NoOfTurbos;
                if (vdeOldVesselEntity.TurboCutOutAvailable == null || vdeOldVesselEntity.TurboCutOutAvailable == string.Empty)
                {
                    cmbTCCutavail.SelectedIndex = 0;
                }
                else
                {
                    cmbTCCutavail.SelectedItem = vdeOldVesselEntity.TurboCutOutAvailable;
                }
                if (vdeOldVesselEntity.PistonCleaningRing == null || vdeOldVesselEntity.PistonCleaningRing == string.Empty)
                {
                    cmbPistonCleaning.SelectedIndex = 0;
                }
                else
                {
                    cmbPistonCleaning.SelectedItem = vdeOldVesselEntity.PistonCleaningRing;
                }
                txtProjectID.Text = vdeOldVesselEntity.ProjectID;
                cmbNoOfEngines.SelectedItem = vdeOldVesselEntity.NoOfEngines.ToString();
                
                if (vdeOldVesselEntity.NoOfCylinders == 0)
                {
                    cmbNoOfCyl.SelectedIndex = 0;
                }
                else
                {
                    cmbNoOfCyl.SelectedItem = vdeOldVesselEntity.NoOfCylinders.ToString();
                }
                if (vdeOldVesselEntity.ProjectStatus == string.Empty || vdeOldVesselEntity.ProjectStatus==null)
                {
                    cmbProjectStatus.SelectedIndex = 1;
                }
                else
                {
                    cmbProjectStatus.SelectedItem = vdeOldVesselEntity.ProjectStatus;
                }

                //inEngineNo = vdeOldVesselEntity.EngineNo;
                noOfEngines = vdeOldVesselEntity.NoOfEngines;
                strProjectStatus = vdeOldVesselEntity.ProjectStatus;
            }
        }
        #endregion

        #region GetAllVesselData
        private void GetAllVesselData()
        {
            dgvProjectData.Visible = true;
            HomeDataAccess hdaDataClassHelper = new HomeDataAccess();

            lstVesselData = hdaDataClassHelper.GetVesselData();
            strMaxVesselNo = "0";

            if (lstVesselData.Count > 0)
            {
                var item = lstVesselData.Max(x => x.VesselNo);

                strMaxVesselNo = item.ToString();


                var query = (from a in lstVesselData.AsEnumerable()
                             select new { a.VesselNo, a.ProjectID, a.StartDateOfProj, a.TargetCompletionDate, a.ProjectStatus }).Distinct().OrderBy(x => x.VesselNo);



                DataTable dtProjectData = new DataTable();
                dtProjectData.Columns.Add("Project Id");
                dtProjectData.Columns.Add("Start Date");
                dtProjectData.Columns.Add("Target End Date");
                dtProjectData.Columns.Add("Project Status");

                foreach (var a in query)
                {
                    DataRow dr = dtProjectData.NewRow();
                    dr["Project Id"] = a.ProjectID;
                    dr["Start Date"] = ConvertToShortDate(a.StartDateOfProj);
                    dr["Target End Date"] = ConvertToShortDate(a.TargetCompletionDate);
                    dr["Project Status"] = a.ProjectStatus;

                    dtProjectData.Rows.Add(dr);

                }

                dgvProjectData.DataSource = dtProjectData;
                dgvProjectData.AllowUserToAddRows = false;
                dgvProjectData.Columns[1].ReadOnly = true;
                dgvProjectData.Columns[2].ReadOnly = true;

                DataGridViewButtonColumn deleteButtonColumn = new DataGridViewButtonColumn();
                deleteButtonColumn.Name = "Delete";
                deleteButtonColumn.Text = "Delete";
                int columnIndex = 4;
                //if (dgvProjectData.Columns["Delete"] == null)
                //{
                //    dgvProjectData.Columns.Add(deleteButtonColumn);
                //}
                deleteButtonColumn.UseColumnTextForButtonValue = true;


                if (dgvProjectData.Columns["Delete"] == null)
                {
                    dgvProjectData.Columns.Insert(columnIndex, deleteButtonColumn);
                }

                if (inVesselNo != 0)
                {
                    string txtSearchValue = "-" + inVesselNo.ToString();
                    int rowIndex = -1;

                    DataGridViewRow row = dgvProjectData.Rows.Cast<DataGridViewRow>()
                        .Where(r => r.Cells["Project ID"].Value.ToString().Contains(txtSearchValue))
                        .First();
                    rowIndex = row.Index;

                    noOfEngines = (from v in lstVesselData
                                   where v.VesselNo == inVesselNo
                                   select v.NoOfEngines).First();

                    dgvProjectData.CurrentCell = dgvProjectData.Rows[rowIndex].Cells["Project Id"];
                    dgvProjectData.CurrentCell.Selected = true;

                    inEngineNo = 1;
                    PopulateVesselInformation();


                    strNoOfCylinders = cmbNoOfCyl.SelectedItem.ToString();
                }
                else
                {
                    string txtSearchValue = "-" + strMaxVesselNo;
                    int rowIndex = -1;

                    DataGridViewRow row = dgvProjectData.Rows.Cast<DataGridViewRow>()
                        .Where(r => r.Cells["Project ID"].Value.ToString().Contains(txtSearchValue))
                        .First();
                    rowIndex = row.Index;

                    dgvProjectData.CurrentCell = dgvProjectData.Rows[rowIndex].Cells["Project Id"];
                    dgvProjectData.CurrentCell.Selected = true;

                    inVesselNo = Convert.ToInt32(strMaxVesselNo);
                    inEngineNo = 0;
                    PopulateVesselInformation();


                    strNoOfCylinders = cmbNoOfCyl.SelectedItem.ToString();
                }
            }
            else
            {
                //dgvProjectData.DataSource = null;
                dgvProjectData.Visible = false;
            }
        }
        #endregion

        #region ConvertToShortDate
        private string ConvertToShortDate(string strDate)
        {
            string strShortDate = string.Empty;

            if (strDate != string.Empty)
            {
                strShortDate = strDate.Substring(0, strDate.IndexOf(" "));
            }

            return strShortDate;
        }
        #endregion

        #region ConvertDateFormatForXML
        private string ConvertDateFormatForXML(string strDate)
        {
            string strShortDate = string.Empty;

            DateTime dt = new DateTime();
            dt = Convert.ToDateTime(strDate, culture);
            strShortDate = dt.ToString("MM/dd/yyyy");

            return strShortDate;
        }
        #endregion

        #region SaveEngineInformation
        private bool SaveEngineInformation(int engNO)
        {
            bool IsSuccess = true;

            try
            {
                VesselInfoDataEntity vdeVesselInfo = new VesselInfoDataEntity();
                vdeVesselInfo.VesselNo = inVesselNo;
                vdeVesselInfo.EngineNo = 1;
                vdeVesselInfo.CompanyName = txtCompName.Text;
                vdeVesselInfo.NoOfVessels = txtNoOfVessels.Text;
                vdeVesselInfo.CustomerContact = txtCustomerContact.Text;
                vdeVesselInfo.Address = txtCustAddress.Text;
                vdeVesselInfo.Email = txtCustEmail.Text;
                vdeVesselInfo.Telephone = txtCustTelephone.Text;
                vdeVesselInfo.SMPContactName = txtSMPContact.Text;
                vdeVesselInfo.SMPAddress = txtSMPAddress.Text;
                vdeVesselInfo.SMPEmail = txtSMPEMail.Text;
                vdeVesselInfo.SMPTelephone = txtSMPPhone.Text;
                vdeVesselInfo.StartDateOfProj = dtpStartDate.Value.ToShortDateString();
                vdeVesselInfo.TargetCompletionDate = dtpTargetEndDate.Value.ToShortDateString();
                if (pnlEngineInfo.Visible == true)
                {
                    vdeVesselInfo.VesselName = txtVesselName.Text;
                    vdeVesselInfo.IMONo = txtIMONo.Text;
                    vdeVesselInfo.VesselID = txtVesselId.Text;
                }
                else if (pnlSetting.Visible == true)
                {
                    vdeVesselInfo.VesselName = txtSettingVesselName.Text;
                    vdeVesselInfo.IMONo = txtSettingIMONumber.Text;
                    vdeVesselInfo.VesselID = txtSettingVslId.Text;
                }

                vdeVesselInfo.DateDelivered = dtDateDelivered.Value.ToShortDateString();
                if (cmbEngManuf.SelectedIndex > 0)
                {
                    vdeVesselInfo.MainEngManuf = cmbEngManuf.SelectedItem.ToString();
                }
                vdeVesselInfo.MainEngType = txtMainEngType.Text;
                vdeVesselInfo.MainEngSerialNo = txtMainEngSerialNo.Text;
                vdeVesselInfo.MainEngLoc = txtMainEngLoc.Text;
                vdeVesselInfo.MainEngNo = txtMainEngNo.Text;
                vdeVesselInfo.MCR = txtMCR.Text;
                vdeVesselInfo.RPM = txtRPM.Text;
                vdeVesselInfo.LubricatorType = txtLubType.Text;
                vdeVesselInfo.MinFeedRate = txtMinFeedRate.Text;
                vdeVesselInfo.CurrentFeedRate = txtCurrentFeedRate.Text;
                vdeVesselInfo.TargetFeedRate = txtTargetFeedRate.Text;
                //if (cmbOilGrade.SelectedIndex > 0)
                //{
                //    vdeVesselInfo.OilGrade = cmbOilGrade.SelectedItem.ToString();
                //}
                //vdeVesselInfo.Density = txtDensity.Text;
                vdeVesselInfo.NoOfTurbos = txtNoOfTC.Text;
                if (cmbTCCutavail.SelectedIndex > 0)
                {
                    vdeVesselInfo.TurboCutOutAvailable = cmbTCCutavail.SelectedItem.ToString();
                }
                if (cmbPistonCleaning.SelectedIndex > 0)
                {
                    vdeVesselInfo.PistonCleaningRing = cmbPistonCleaning.SelectedItem.ToString();
                }
                vdeVesselInfo.NoOfEngines = Convert.ToInt32(cmbNoOfEngines.SelectedItem.ToString());
                //if (cmbEngineNo.SelectedIndex >= 0)
                //{
                //    vdeVesselInfo.EngineNo = Convert.ToInt32(cmbEngineNo.SelectedItem.ToString());
                //}
               
                vdeVesselInfo.NoOfCylinders = Convert.ToInt32(cmbNoOfCyl.SelectedItem.ToString());
                if (cmbProjectStatus.SelectedIndex > 0)
                {
                    vdeVesselInfo.ProjectStatus = cmbProjectStatus.SelectedItem.ToString();
                }

                
                if (txtProjectID.Text == string.Empty)
                {
                    vdeVesselInfo.VesselNo = (Convert.ToInt32(strMaxVesselNo) + 1);
                    vdeVesselInfo.EngineNo = 1;
                    IsSuccess = hdaDataAccess.InsertVesselData(vdeVesselInfo);
                    if (vdeVesselInfo.NoOfEngines == 2)
                    {
                        vdeVesselInfo.EngineNo = 2;
                        IsSuccess = hdaDataAccess.InsertVesselData(vdeVesselInfo);
                    }
                    isEngineInsert = true;
                    inVesselNo = vdeVesselInfo.VesselNo;
                }
               
                else
                {
                    isEngineInsert = false;
                    IEnumerable<string> strChanges = Common.EnumeratePropertyDifferences(vdeOldVesselEntity, vdeVesselInfo);

                    if (strChanges.Count() > 0)
                    {
                        IsSuccess = hdaDataAccess.UpdateVesselData(vdeVesselInfo);
                        if (engNO == 0)
                        {
                            vdeVesselInfo.EngineNo = 2;
                            IsSuccess = hdaDataAccess.UpdateVesselData(vdeVesselInfo);
                        }
                        
                    }
                }
                
            }
            catch (Exception ex)
            {

                Common.WriteTextFile(ex, Common.strUser);
            }
            return IsSuccess;
        }
        #endregion

        #region ValidateEngineInformation
        private bool ValidateEngineInformation()
        {
            Regex expression = new Regex ("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            bool isValid = false;
            if (txtVesselId.Text.Trim() == "" || txtMainEngLoc.Text.Trim() == "" || txtMainEngNo.Text.Trim() == ""
                || txtMCR.Text.Trim() == "" || txtRPM.Text.Trim() == "" 
                || txtCurrentFeedRate.Text.Trim() == "" || cmbTCCutavail.SelectedIndex <= 0
                || cmbPistonCleaning.SelectedIndex <= 0 || txtNoOfTC.Text.Trim() == "" || txtVesselName.Text.Trim () == string.Empty)
            {
                MessageBox.Show("Please enter all mandatory fields marked with asterik(*)", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                isValid = false;
                return isValid;
            }
            //else if (!expression.IsMatch(txtMCR.Text))
            //{
            //    MessageBox.Show("MCR should be a decimal with max 3 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    isValid = false;
            //    return isValid;
            //}
            //else if (!regexForNumber.IsMatch(txtCurrentFeedRate.Text))
            //{
            //    MessageBox.Show("Current Feed Rate should be numeric!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    isValid =  false;
            //    return isValid;
            //}
            //else if (IsNumber(txtCurrentFeedRate.Text) && Convert.ToDouble(txtCurrentFeedRate.Text) > 2.5)
            //{
            //    //if (Convert.ToDouble(txtCurrentFeedRate.Text) > 2.5)
            //    //{
            //        MessageBox.Show("Current Feed Rate should be less than 2.5!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        isValid =  false;
            //        return isValid;
            //    //}
            //    //else
            //    //{
            //    //    isValid = true;
            //    //}

            //}
            //else if (txtTargetFeedRate.Text != string.Empty && !regexForNumber.IsMatch(txtTargetFeedRate.Text))
            //{
            //    MessageBox.Show("Target Feed Rate should be numeric!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    isValid =  false;
            //    return isValid;
            //}
            //else if (IsNumber(txtTargetFeedRate.Text) && Convert.ToDouble(txtTargetFeedRate.Text) > 2.5)
            //{
            //    //if (Convert.ToDouble(txtTargetFeedRate.Text) > 2.5)
            //    //{
            //        MessageBox.Show("Target Feed Rate should be less than 2.5!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        isValid =  false;
            //        return isValid;
            //    //}
            //    //else
            //    //{
            //    //    isValid =  true;
            //    //}

            //}
            //else if (txtMinFeedRate.Text != string .Empty && !regexForNumber.IsMatch(txtMinFeedRate.Text))
            //{
            //    MessageBox.Show("Minimum Feed Rate should be numeric!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    isValid =  false;
            //    return isValid;
            //}
            //else if (IsNumber(txtMinFeedRate.Text) && Convert.ToDouble(txtMinFeedRate.Text) > 2.5)
            //{
            //    //if (Convert.ToDouble(txtMinFeedRate.Text) > 2.5)
            //    //{
            //        MessageBox.Show("Minimum Feed Rate should be less than 2.5!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        isValid =  false;
            //        return isValid;
            //    //}
            //    //else
            //    //{
            //    //    isValid = true;
            //    //}

            //}
            //else if (txtRPM.Text != string.Empty && !regexForNumber.IsMatch(txtRPM.Text))
            //{
            //    MessageBox.Show("RPM should be numeric!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return false;
            //}
            //else if (IsNumber(txtRPM.Text) && Convert.ToDouble(txtRPM.Text) >= 150)
            //{
            //    MessageBox.Show("RPM should be less than 150!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return false;

            //}
            else
            {
                isValid = true;
                return isValid;
            }

            //return isValid;
        }

        
        #endregion

        #region ValidateSettingInformation
        private bool ValidateSettingInformation()
        {
            Regex expression = new Regex("^\\d+$");
            if (txtSettingVslId.Text.Trim() == string.Empty || txtSettingVesselName.Text.Trim() == string.Empty ||
                 (cmbNoOfEngines.SelectedIndex < 0 ))
            {
                MessageBox.Show("Please enter all mandatory fields marked with asterik(*)", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (dtpTargetEndDate.Value <= dtpStartDate.Value)
            {
                MessageBox.Show("Target end date cannot be lesser than or equal to start date", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            //else if (!expression.IsMatch(txtSettingVslId.Text))
            //{
            //    MessageBox.Show("Vessel Id should be numeric!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return false;
            //}
            else
            {
                return true;
            }
        }
        #endregion

        #region SetResetBackGroundColor
        public void SetResetBackGroundColor(ToolStripTextBox ts)
        {
            SetResetBackGroundColorForLinks("");
            foreach (ToolStripTextBox tsTxbBox in tsMLBToolStrip.Items.OfType<ToolStripTextBox>())
            {
                    if (tsTxbBox.Text == ts.Text)
                    {
                        tsTxbBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                    }
                    else
                    {
                        tsTxbBox.BackColor = System.Drawing.Color.White;
                    }

            }
            //lblLinkSetting.BackColor = System.Drawing.Color.White;
            //pnlSettingLabel.BackColor = System.Drawing.Color.White;
            //lblLubeMonInfo.BackColor = System.Drawing.Color.White;
            //pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
        }
        #endregion

        #region GetDensityPerOilGrade
        private string GetDensityPerOilGrade(string strOilGrade)
        {
            string strDensity = string.Empty;

            switch (strOilGrade)
            {
                case Constants.ALEXIA_50:
                    {
                        strDensity = "0.932 kg/l";
                        break;
                    }
                case Constants.ALEXIA_S3:
                    {
                        strDensity = "0.908 kg/l";
                        break;
                    }
                case Constants.ALEXIA_S4:
                    {
                        strDensity = "0.926 kg/l";
                        break;
                    }
                case Constants.ALEXIA_S5:
                    {
                        strDensity = "0.94 kg/l";
                        break;
                    }
                case Constants.ALEXIA_S6:
                    {
                        strDensity = "0.954 kg/l";
                        break;
                    }
                default:
                    {
                        strDensity = string.Empty;
                        break;
                    }
            }
            return strDensity;
        }
        #endregion

        #region SetResetBackGroundColorForLinks
        private void SetResetBackGroundColorForLinks(string strLinkButton)
        {
            foreach (ToolStripTextBox tsTxbBox in tsMLBToolStrip.Items.OfType<ToolStripTextBox>())
            {
                tsTxbBox.BackColor = System.Drawing.Color.White;
            }
            lblLinkSetting.BackColor = System.Drawing.Color.White;
            pnlSettingLabel.BackColor = System.Drawing.Color.White;
            lblLubeMonInfo.BackColor = System.Drawing.Color.White;
            pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
            lnkContactUs.BackColor = System.Drawing.Color.White;
            pnlContactUs.BackColor = System.Drawing.Color.White;
            lnkTandC.BackColor = System.Drawing.Color.White;
            pnlTandC.BackColor = System.Drawing.Color.White; ;

            switch (strLinkButton)
            {
                case "Setting":
                    {
                        lblLinkSetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        pnlSettingLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        lblLubeMonInfo.BackColor = System.Drawing.Color.White;
                        pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
                        lnkContactUs.BackColor = System.Drawing.Color.White;
                        pnlContactUs.BackColor = System.Drawing.Color.White;
                        break;
                    }
                case "LubeMonitor":
                    {
                        lblLinkSetting.BackColor = System.Drawing.Color.White;
                        pnlSettingLabel.BackColor = System.Drawing.Color.White;
                        lblLubeMonInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        lblLubeMonInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        lnkContactUs.BackColor = System.Drawing.Color.White;
                        pnlContactUs.BackColor = System.Drawing.Color.White;
                        break;
                    }
                case "ContactUs":
                    {
                        lblLinkSetting.BackColor = System.Drawing.Color.White;
                        pnlSettingLabel.BackColor = System.Drawing.Color.White;
                        lblLubeMonInfo.BackColor = System.Drawing.Color.White;
                        pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
                        lnkContactUs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        pnlContactUs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        break;
                    }
                case "TermsAndConditions":
                    {
                        lblLinkSetting.BackColor = System.Drawing.Color.White;
                        pnlSettingLabel.BackColor = System.Drawing.Color.White;
                        lblLubeMonInfo.BackColor = System.Drawing.Color.White;
                        pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
                        lnkContactUs.BackColor = System.Drawing.Color.White;
                        pnlContactUs.BackColor = System.Drawing.Color.White;
                        lnkTandC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        pnlTandC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(209)))), ((int)(((byte)(23)))));
                        break;
                    }
                default:
                    {
                        lblLinkSetting.BackColor = System.Drawing.Color.White;
                        pnlSettingLabel.BackColor = System.Drawing.Color.White;
                        lblLubeMonInfo.BackColor = System.Drawing.Color.White;
                        pnlLubeMonInfo.BackColor = System.Drawing.Color.White;
                        lnkContactUs.BackColor = System.Drawing.Color.White;
                        pnlContactUs.BackColor = System.Drawing.Color.White;
                        break;
                    }
            }
        }
        #endregion

        #region SaveRunningHourData
        private int SaveRunningHourData()
        {
            RunningHour rngHourData = new RunningHour();
            int inStatus = 0;
            lstRngHour = hdaDataAccess.GetRunningHour(inVesselNo, inEngineNo);

            foreach (DataRow dr in dtRunningHourData.Rows)
            {
                rngHourData.VesselNo = inVesselNo;
                rngHourData.EngineNo = inEngineNo;
                rngHourData.CylinderNumber = dr[Constants.CYLINDER_NUMBER_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NUMBER_GRID].ToString());
                //rngHourData.ReadingDate = dr[Constants.READING_DATE_GRID].ToString();
                rngHourData.ReadingDate = dtpSupportInfo.Value.ToString();
                rngHourData.Liner = dr[Constants.LINEAR].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.LINEAR].ToString());
                rngHourData.Prings = dr[Constants.PRINGS].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PRINGS].ToString());
                rngHourData.PCrown = dr[Constants.PCROWN].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PCROWN].ToString());

                if (dr.RowState == DataRowState.Added)
                {
                    hdaDataAccess.InsertRunningHour(rngHourData);
                }
                if (dr.RowState == DataRowState.Modified)
                {
                    int count = (from a in lstRngHour
                                 where ConvertToShortDate(a.ReadingDate) == dtpSupportInfo.Value.ToShortDateString()
                                 && a.CylinderNumber == rngHourData.CylinderNumber
                                 select a).Count();
                    if (count > 0)
                    {
                        inStatus = hdaDataAccess.UpdateRunningHour(rngHourData);
                    }
                    else
                    {
                        inStatus = hdaDataAccess.InsertRunningHour(rngHourData);
                    }

                }
            }
            return inStatus;

        }
        #endregion

        #region GetRunningHourData
        private DataTable GetRunningHourData(int intNoOfCylinders, string strDate)
        {
            lstRngHour = new List<RunningHour>();
            dtRunningHourData = new DataTable();
            dtRunningHourData.Columns.Add(Constants.CYLINDER_NUMBER_GRID);
            //dtRunningHourData.Columns.Add(Constants.READING_DATE_GRID);
            dtRunningHourData.Columns.Add(Constants.LINEAR);
            dtRunningHourData.Columns.Add(Constants.PRINGS);
            dtRunningHourData.Columns.Add(Constants.PCROWN);
            dtRunningHourData.AcceptChanges();

            lstRngHour =  hdaDataAccess.GetRunningHour(inVesselNo, inEngineNo);

            


            int intSavedCylinderNo = lstRngHour.Count();
            

            for (int j = 1; j <= Convert.ToInt32(strNoOfCylinders); j++)
            {
                var query1 = from a in lstRngHour
                            where a.CylinderNumber == j
                            select a;
                //var item = query1.Max(x => x.ReadingDate);

                var query = from a in query1
                            where ConvertToShortDate(a.ReadingDate) == ConvertToShortDate(strDate) 
                            select a;

                foreach (var a in query)
                {
                    dtRunningHourData.Rows.Add(a.CylinderNumber, a.Liner, a.Prings, a.PCrown);
                    //dtRunningHourData.Rows.Add(a.CylinderNumber, ConvertToShortDate(a.ReadingDate), a.Linear, a.Prings, a.PCrown);
                    //dtRunningHourData.Rows.Add(a.CylinderNumber, a.ReadingDate, a.Linear, a.Prings, a.PCrown);
                }
                dtRunningHourData.AcceptChanges();
            }


            if (intSavedCylinderNo == intNoOfCylinders)
            {

                //no changes needed
            }
            //else if (intSavedCylinderNo > intNoOfCylinders)
            //{
            //    //remove extra rows
            //    for (int j = intNoOfCylinders; j <= intSavedCylinderNo - 1; j++)
            //    {
            //        dtRunningHourData.Rows.RemoveAt(j);
            //    }
            //    dtRunningHourData.AcceptChanges();
            //}
            else if (intSavedCylinderNo < intNoOfCylinders)
            {
                //insert extra dummy rows
                for (int k = intSavedCylinderNo; k < intNoOfCylinders; k++)
                {
                    dtRunningHourData.Rows.Add((k + 1).ToString(), "", "", "");
                }
                dtRunningHourData.AcceptChanges();
            }

            if (dtRunningHourData.Rows.Count == 0)
            {
                for (int k = 1; k <= intNoOfCylinders; k++)
                {
                    dtRunningHourData.Rows.Add((k).ToString(), "", "", "");
                }
                dtRunningHourData.AcceptChanges();
            }
            
            return dtRunningHourData;
        }
        #endregion

        #region GetLinearWearData
        private DataTable GetLinearWearData(int intNoOfCylinders, string strDate)
        {
            lstLinearWear = new List<LinearWear>();
            dtLinearWear = new DataTable();
            dtLinearWear.Columns.Add(Constants.CYLINDER_NUMBER_GRID);
            //dtLinearWear.Columns.Add(Constants.DATE_MEASURED_GRID);
            dtLinearWear.Columns.Add(Constants.FORWARD_GRID);
            dtLinearWear.Columns.Add(Constants.PORT_STARBOARD_GRID);
            
            dtLinearWear.AcceptChanges();

            lstLinearWear = hdaDataAccess.GetLinearWear(inVesselNo, inEngineNo);


            int intSavedCylinderNo = 0;
            var query = from a in lstLinearWear
                        where ConvertToShortDate(a.DateMeasured) == ConvertToShortDate(strDate)
                        select a;
            if (query != null)
                intSavedCylinderNo = query.Count();
            foreach (var a in query)
            {
                
                dtLinearWear.Rows.Add(a.CylinderNumber, a.Forward, a.PortStarBoard);
                //dtLinearWear.Rows.Add(a.CylinderNumber, ConvertToShortDate(a.DateMeasured), a.Forward, a.PortStarBoard);
                //dtLinearWear.Rows.Add(a.CylinderNumber, a.DateMeasured, a.Forward, a.PortStarBoard);
            }
            dtLinearWear.AcceptChanges();
            if (intSavedCylinderNo == intNoOfCylinders)
            {

                //no changes needed
            }
            //else if (intSavedCylinderNo > intNoOfCylinders)
            //{
            //    //remove extra rows
            //    for (int j = intNoOfCylinders; j <= intSavedCylinderNo - 1; j++)
            //    {
            //        dtLinearWear.Rows.RemoveAt(j);
            //    }
            //    dtLinearWear.AcceptChanges();
            //}
            else if (intSavedCylinderNo < intNoOfCylinders)
            {
                //insert extra dummy rows
                for (int k = intSavedCylinderNo; k < intNoOfCylinders; k++)
                {
                    dtLinearWear.Rows.Add((k + 1).ToString(), "", "");
                }
                dtLinearWear.AcceptChanges();
            }

            if (dtLinearWear.Rows.Count == 0)
            {
                //insert extra dummy rows
                for (int k = 1; k <= intNoOfCylinders; k++)
                {
                    dtLinearWear.Rows.Add((k).ToString(), "", "");
                }
                dtLinearWear.AcceptChanges();
            }

            return dtLinearWear;
        }
        #endregion

        #region GetCylinderInspectionData
        private DataTable GetCylinderInspectionData(int intNoOfCylinders, string strDate)
        {
            lstCylInspection = new List<CylinderInspection>();
            dtCylInspection = new DataTable();
            dtCylInspection.Columns.Add(Constants.CYLINDER_NUMBER_GRID);
            dtCylInspection.Columns.Add(Constants.DATE_OF_INSPECTION_GRID);

            dtCylInspection.AcceptChanges();

            lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, inEngineNo);


            int intSavedCylinderNo = lstCylInspection.Count();
            var query = from a in lstCylInspection
                        where ConvertToShortDate(a.DateOfInspection) == ConvertToShortDate(strDate) 
                        select a;

            foreach (var a in query)
            {
                dtCylInspection.Rows.Add(a.CylinderNumber, ConvertToShortDate(a.DateOfInspection));
                //dtCylInspection.Rows.Add(a.CylinderNumber, a.DateOfInspection);
            }
            dtCylInspection.AcceptChanges();
            if (intSavedCylinderNo == intNoOfCylinders)
            {

                //no changes needed
            }
            //else if (intSavedCylinderNo > intNoOfCylinders)
            //{
            //    //remove extra rows
            //    for (int j = intNoOfCylinders; j <= intSavedCylinderNo - 1; j++)
            //    {
            //        dtCylInspection.Rows.RemoveAt(j);
            //    }
            //    dtCylInspection.AcceptChanges();
            //}
            else if (intSavedCylinderNo < intNoOfCylinders)
            {
                //insert extra dummy rows
                for (int k = intSavedCylinderNo; k < intNoOfCylinders; k++)
                {
                    dtCylInspection.Rows.Add((k + 1).ToString(), "");
                }
                dtCylInspection.AcceptChanges();
            }

            if (dtCylInspection.Rows.Count == 0)
            {
                //insert extra dummy rows
                for (int k = 1; k <= intNoOfCylinders; k++)
                {
                    dtCylInspection.Rows.Add((k).ToString(), "");
                }
                dtCylInspection.AcceptChanges();
            }

            return dtCylInspection;
        }
        #endregion

        #region SaveLinearData
        private int SaveLinearData()
        {
            LinearWear linearWearData = new LinearWear();
            int inStatus = 0;
            lstLinearWear = hdaDataAccess.GetLinearWear(inVesselNo, inEngineNo);

            foreach (DataRow dr in dtLinearWear.Rows)
            {
                linearWearData.VesselNo = inVesselNo;
                linearWearData.EngineNo = inEngineNo;
                linearWearData.CylinderNumber = dr[Constants.CYLINDER_NUMBER_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NUMBER_GRID].ToString());
                linearWearData.DateMeasured = dtpSupportInfo.Value.ToString();
                //linearWearData.DateMeasured = dr[Constants.DATE_MEASURED_GRID].ToString();
                linearWearData.Forward = dr[Constants.FORWARD_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.FORWARD_GRID].ToString());
                linearWearData.PortStarBoard = dr[Constants.PORT_STARBOARD_GRID].ToString() == string.Empty ? 0.0 : Convert.ToDouble(dr[Constants.PORT_STARBOARD_GRID].ToString());

                if (dr.RowState == DataRowState.Added)
                {
                    hdaDataAccess.InsertLinearWear(linearWearData);
                }
                if (dr.RowState == DataRowState.Modified)
                {
                    int count = (from a in lstLinearWear
                                 where ConvertToShortDate(a.DateMeasured) == dtpSupportInfo.Value.ToShortDateString()
                                 && a.CylinderNumber == linearWearData.CylinderNumber
                                 select a).Count();
                    if (count > 0)
                    {
                        inStatus = hdaDataAccess.UpdateLinearWear(linearWearData);
                    }
                    else
                    {
                        inStatus = hdaDataAccess.InsertLinearWear(linearWearData);
                    }

                }
            }
            return inStatus;

        }
        #endregion

        #region SaveCylinderInspectionData
        private int SaveCylinderInspectionData()
        {
            CylinderInspection cylInspecData = new CylinderInspection();
            int inStatus = 0;
            lstCylInspection = hdaDataAccess.GetCylinderInspection(inVesselNo, inEngineNo);

            //foreach (DataRow dr in dtCylInspection.Rows)
            //{
            //    cylInspecData.VesselNo = inVesselNo;
            //    cylInspecData.EngineNo = inEngineNo;
            //    cylInspecData.CylinderNumber = dr[Constants.CYLINDER_NUMBER_GRID].ToString() == string.Empty ? 0 : Convert.ToInt32(dr[Constants.CYLINDER_NUMBER_GRID].ToString());
            //    cylInspecData.DateOfInspection = dr[Constants.DATE_OF_INSPECTION_GRID].ToString();
            //   // cylInspecData.DateOfInspection = dtpSupportInfo.Value.ToString();
               
            //    if (dr.RowState == DataRowState.Added)
            //    {
            //        inStatus = hdaDataAccess.InsertCylinderInspection(cylInspecData);
            //    }
            //    if (dr.RowState == DataRowState.Modified || dr.RowState == DataRowState.Unchanged)
            //    {
            //        int count = (from a in lstCylInspection
            //                     where a.CylinderNumber == cylInspecData.CylinderNumber
            //                     select a).Count();
            //        if (count > 0)
            //        {
            //            inStatus = hdaDataAccess.UpdateCylinderInspection(cylInspecData);
            //        }
            //        else
            //        {
            //            inStatus = hdaDataAccess.InsertCylinderInspection(cylInspecData);
            //        }

            //    }
            //}

            //for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
            //{
            for (int i = 1; i <= 1; i++)
            {
                cylInspecData.VesselNo = inVesselNo;
                cylInspecData.EngineNo = inEngineNo;
                cylInspecData.CylinderNumber = i;
                cylInspecData.DateOfInspection = ConvertToShortDate(dtpSupportInfo.Value.ToString());

                int count = (from a in lstCylInspection
                             where ConvertToShortDate(a.DateOfInspection) == dtpSupportInfo.Value.ToShortDateString()
                             && a.CylinderNumber == cylInspecData.CylinderNumber
                             select a).Count();


                if (chkLstCylInspection.GetItemChecked(i - 1))
                {
                    if (lstCylInspection.Count > 0)
                    {
                        var dt = lstCylInspection.FirstOrDefault().DateOfInspection;
                        DateTime dtSavedDate = Convert.ToDateTime(dt, CultureInfo.InvariantCulture);
                        DateTime dtNewDate = Convert.ToDateTime(cylInspecData.DateOfInspection, CultureInfo.InvariantCulture);
                        //if (count > 0)
                        //{
                        if (dtNewDate > dtSavedDate)
                            inStatus = hdaDataAccess.UpdateCylinderInspection(cylInspecData);
                        //}
                    }
                    else
                    {
                        inStatus = hdaDataAccess.InsertCylinderInspection(cylInspecData);
                    }
                }
                else
                {
                    //if (count > 0)
                    //{
                        inStatus = hdaDataAccess.DeleteCylinderInspection(cylInspecData);
                    //}
                }
            }

            return inStatus;

        }
        #endregion

        #region PopulateSecondEngineData
        private void PopulateSecondEngineData()
        {
            vdeSecondEngine = new VesselInfoDataEntity();

            int intSecondEngineData = lstVesselData.Count(x => x.VesselNo == inVesselNo && x.EngineNo == 2);
            if (intSecondEngineData == 0)
            {
                vdeSecondEngine.CompanyName = vdeOldVesselEntity.CompanyName;
                vdeSecondEngine.NoOfVessels = vdeOldVesselEntity.NoOfVessels;
                vdeSecondEngine.CustomerContact = vdeOldVesselEntity.CustomerContact;
                vdeSecondEngine.Address = vdeOldVesselEntity.Address;
                vdeSecondEngine.Email = vdeOldVesselEntity.Email;
                vdeSecondEngine.Telephone = vdeOldVesselEntity.Telephone;
                vdeSecondEngine.SMPContactName = vdeOldVesselEntity.SMPContactName;
                vdeSecondEngine.StartDateOfProj = vdeOldVesselEntity.StartDateOfProj;
                vdeSecondEngine.TargetCompletionDate = vdeOldVesselEntity.TargetCompletionDate;
                vdeSecondEngine.SMPAddress = vdeOldVesselEntity.SMPAddress;
                vdeSecondEngine.SMPEmail = vdeOldVesselEntity.SMPEmail;
                vdeSecondEngine.SMPTelephone = vdeOldVesselEntity.SMPTelephone;
                vdeSecondEngine.VesselName = vdeOldVesselEntity.VesselName;
                vdeSecondEngine.VesselID = vdeOldVesselEntity.VesselID;
                //Engine information
                vdeSecondEngine.VesselName = vdeOldVesselEntity.VesselName;
                vdeSecondEngine.IMONo = vdeOldVesselEntity.IMONo;
                vdeSecondEngine.VesselID = vdeOldVesselEntity.VesselID;
                vdeSecondEngine.DateDelivered = vdeOldVesselEntity.DateDelivered;
                vdeSecondEngine.MainEngManuf = vdeOldVesselEntity.MainEngManuf;
                vdeSecondEngine.MainEngType = vdeOldVesselEntity.MainEngType;
                vdeSecondEngine.MainEngSerialNo = "";
                vdeSecondEngine.MainEngLoc = "";
                vdeSecondEngine.MainEngNo = "";
                vdeSecondEngine.MCR = vdeOldVesselEntity.MCR;
                vdeSecondEngine.RPM = vdeOldVesselEntity.RPM;
                vdeSecondEngine.LubricatorType = "";
                vdeSecondEngine.MinFeedRate = vdeOldVesselEntity.MinFeedRate;
                vdeSecondEngine.CurrentFeedRate = "";
                vdeSecondEngine.TargetFeedRate = vdeOldVesselEntity.TargetFeedRate;
                vdeSecondEngine.OilGrade = "";
                vdeSecondEngine.Density = "";
                vdeSecondEngine.NoOfTurbos = vdeOldVesselEntity.NoOfTurbos;
                vdeSecondEngine.TurboCutOutAvailable = vdeOldVesselEntity.TurboCutOutAvailable;
                vdeSecondEngine.PistonCleaningRing = vdeOldVesselEntity.PistonCleaningRing;
                vdeSecondEngine.ProjectID = vdeOldVesselEntity.ProjectID;
                vdeSecondEngine.NoOfEngines = vdeOldVesselEntity.NoOfEngines;
                vdeSecondEngine.EngineNo = 2;
                vdeSecondEngine.NoOfCylinders = vdeOldVesselEntity.NoOfCylinders;
            }
            else
            {
                var query = from a in lstVesselData
                            where (a.VesselNo == inVesselNo && a.EngineNo == 2)
                            select a;

                foreach (var a in query)
                {
                    vdeSecondEngine = a;
                }
            }

            if (vdeSecondEngine != null)
            {
                //Setting
                txtCompName.Text = vdeSecondEngine.CompanyName;
                txtNoOfVessels.Text = vdeSecondEngine.NoOfVessels;
                txtCustomerContact.Text = vdeSecondEngine.CustomerContact;
                txtCustAddress.Text = vdeSecondEngine.Address;
                txtCustEmail.Text = vdeSecondEngine.Email;
                txtCustTelephone.Text = vdeSecondEngine.Telephone;
                txtSMPContact.Text = vdeSecondEngine.SMPContactName;
                dtpStartDate.Text = vdeSecondEngine.StartDateOfProj;
                dtpTargetEndDate.Text = vdeSecondEngine.TargetCompletionDate;
                txtSMPAddress.Text = vdeSecondEngine.SMPAddress;
                txtSMPEMail.Text = vdeSecondEngine.SMPEmail;
                txtSMPPhone.Text = vdeSecondEngine.SMPTelephone;
                txtSettingVesselName.Text = vdeSecondEngine.VesselName;
                txtSettingVslId.Text = vdeSecondEngine.VesselID;
                txtSettingIMONumber.Text = vdeSecondEngine.VesselID;
                //Engine information
                txtVesselName2.Text = vdeSecondEngine.VesselName;
                txtIMONo2.Text = vdeSecondEngine.IMONo;
                txtVesselId2.Text = vdeSecondEngine.VesselID;
                dtpDateDelivered2.Text = vdeSecondEngine.DateDelivered;
                if (vdeSecondEngine.MainEngManuf == null || vdeSecondEngine.MainEngManuf == string.Empty)
                {
                    cmbEngManuf2.SelectedIndex = 0;
                }
                else
                {
                    cmbEngManuf2.SelectedItem = vdeSecondEngine.MainEngManuf;
                }
                //txtMainEngMfr2.Text = vdeSecondEngine.MainEngManuf;
                txtMainEngNo2.Text = vdeSecondEngine.MainEngType;
                txtMainEngSerialNo2.Text = vdeSecondEngine.MainEngSerialNo;
                txtMainEngLoc2.Text = vdeSecondEngine.MainEngLoc;
                txtMainEngNo2.Text = vdeSecondEngine.MainEngNo;
                txtMCR2.Text = vdeSecondEngine.MCR;
                txtRPM2.Text = vdeSecondEngine.RPM;
                txtLubType2.Text = vdeSecondEngine.LubricatorType;
                txtMinFeedRate2.Text = vdeSecondEngine.MinFeedRate;
                txtCurrentFeedRate2.Text = vdeSecondEngine.CurrentFeedRate;
                txtTargetFeedRate2.Text = vdeSecondEngine.TargetFeedRate;
                //if (vdeSecondEngine.OilGrade == null || vdeSecondEngine.OilGrade == string.Empty)
                //{
                //    cmbOilGrade.SelectedIndex = 0;
                //}
                //else
                //{
                //    cmbOilGrade2.SelectedItem = vdeSecondEngine.OilGrade;
                //}
                txtDensity2.Text = vdeSecondEngine.Density;
                txtNoOfTC2.Text = vdeSecondEngine.NoOfTurbos;
                if (vdeSecondEngine.TurboCutOutAvailable == null || vdeSecondEngine.TurboCutOutAvailable == string.Empty)
                {
                    cmbTCCutavail.SelectedIndex = 0;
                }
                else
                {
                    cmbTCCutOutAvail2.SelectedItem = vdeSecondEngine.TurboCutOutAvailable;
                }
                if (vdeSecondEngine.PistonCleaningRing == null || vdeSecondEngine.PistonCleaningRing == string.Empty)
                {
                    cmbPistonCleaning.SelectedIndex = 0;
                }
                else
                {
                    cmbPistonCleaningRing2.SelectedItem = vdeSecondEngine.PistonCleaningRing;
                }
                txtProjectID.Text = vdeSecondEngine.ProjectID;
                cmbNoOfEngines.SelectedItem = vdeSecondEngine.NoOfEngines.ToString();
                
                cmbNoOfCyl.SelectedItem = vdeSecondEngine.NoOfCylinders.ToString();

                inEngineNo = vdeSecondEngine.EngineNo;
            }
        }
        #endregion

        #region ValidateSecondEngineInformation
        private bool ValidateSecondEngineInformation()
        {
            Regex expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtVesselId2.Text.Trim() == "" || txtMainEngLoc2.Text.Trim() == "" || txtMainEngNo2.Text.Trim() == ""
                || txtMCR2.Text.Trim() == "" || txtRPM2.Text.Trim() == "" 
                || txtCurrentFeedRate2.Text.Trim() == "" || cmbTCCutOutAvail2.SelectedIndex <= 0
                || cmbPistonCleaningRing2.SelectedIndex <= 0 || txtNoOfTC2.Text.Trim() == "" || txtVesselName2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please enter all mandatory fields marked with asterik(*)", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (!expression.IsMatch(txtMCR2.Text))
            {
                MessageBox.Show("MCR should be a decimal with max 3 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (!regexForNumber.IsMatch(txtCurrentFeedRate2.Text))
            {
                MessageBox.Show("Current Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtCurrentFeedRate2.Text) && Convert.ToDouble(txtCurrentFeedRate2.Text) > 2.5)
            {
                    MessageBox.Show("Current Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;

            }
            else if (txtTargetFeedRate2.Text != string.Empty && !regexForNumber.IsMatch(txtTargetFeedRate2.Text))
            {
                MessageBox.Show("Target Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtTargetFeedRate2.Text) && Convert.ToDouble(txtTargetFeedRate2.Text) > 2.5)
            {
                    MessageBox.Show("Target Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;

            }
            else if (txtMinFeedRate2.Text != string.Empty && !regexForNumber.IsMatch(txtMinFeedRate2.Text))
            {
                MessageBox.Show("Minimum Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtMinFeedRate2.Text) && Convert.ToDouble(txtMinFeedRate2.Text) > 2.5)
            {
                    MessageBox.Show("Minimum Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;

            }
            else if (txtRPM2.Text != string.Empty && !regexForNumber.IsMatch(txtRPM2.Text))
            {
                MessageBox.Show("RPM should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtRPM2.Text) && Convert.ToDouble(txtRPM2.Text) >= 150)
            {
                MessageBox.Show("RPM should be less than 150", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else
            {
                return true;
            }
        }
        #endregion

        #region SaveSecondEngineInformation
        private bool SaveSecondEngineInformation()
        {

            VesselInfoDataEntity vdeVesselInfo = new VesselInfoDataEntity();
            vdeVesselInfo.VesselNo = inVesselNo;
            vdeVesselInfo.CompanyName = txtCompName.Text;
            vdeVesselInfo.NoOfVessels = txtNoOfVessels.Text;
            vdeVesselInfo.CustomerContact = txtCustomerContact.Text;
            vdeVesselInfo.Address = txtCustAddress.Text;
            vdeVesselInfo.Email = txtCustEmail.Text;
            vdeVesselInfo.Telephone = txtCustTelephone.Text;
            vdeVesselInfo.SMPContactName = txtSMPContact.Text;
            vdeVesselInfo.SMPAddress = txtSMPAddress.Text;
            vdeVesselInfo.SMPEmail = txtSMPEMail.Text;
            vdeVesselInfo.SMPTelephone = txtSMPPhone.Text;
            vdeVesselInfo.StartDateOfProj = dtpStartDate.Text;
            vdeVesselInfo.TargetCompletionDate = dtpTargetEndDate.Text;
            if (pnlEngine2.Visible == true)
            {
                vdeVesselInfo.VesselName = txtVesselName2.Text;
                vdeVesselInfo.IMONo = txtIMONo2.Text;
                vdeVesselInfo.VesselID = txtVesselId2.Text;
            }
            else if (pnlSetting.Visible == true)
            {
                vdeVesselInfo.VesselName = txtSettingVesselName.Text;
                vdeVesselInfo.IMONo = txtSettingIMONumber.Text;
                vdeVesselInfo.VesselID = txtSettingVslId.Text;
            }

            vdeVesselInfo.DateDelivered = dtpDateDelivered2.Text;
            if (cmbEngManuf2.SelectedIndex > 0)
            {
                vdeVesselInfo.MainEngManuf = cmbEngManuf2.SelectedItem.ToString();
            }
            vdeVesselInfo.MainEngType = txtMainEngType2.Text;
            vdeVesselInfo.MainEngSerialNo = txtMainEngSerialNo2.Text;
            vdeVesselInfo.MainEngLoc = txtMainEngLoc2.Text;
            vdeVesselInfo.MainEngNo = txtMainEngNo2.Text;
            vdeVesselInfo.MCR = txtMCR2.Text;
            vdeVesselInfo.RPM = txtRPM2.Text;
            vdeVesselInfo.LubricatorType = txtLubType2.Text;
            vdeVesselInfo.MinFeedRate = txtMinFeedRate2.Text;
            vdeVesselInfo.CurrentFeedRate = txtCurrentFeedRate2.Text;
            vdeVesselInfo.TargetFeedRate = txtTargetFeedRate2.Text;
            //if (cmbOilGrade2.SelectedIndex > 0)
            //{
            //    vdeVesselInfo.OilGrade = cmbOilGrade2.SelectedItem.ToString();
            //}
            //vdeVesselInfo.Density = txtDensity2.Text;
            vdeVesselInfo.NoOfTurbos = txtNoOfTC2.Text;
            if (cmbTCCutOutAvail2.SelectedIndex > 0)
            {
                vdeVesselInfo.TurboCutOutAvailable = cmbTCCutOutAvail2.SelectedItem.ToString();
            }
            if (cmbPistonCleaningRing2.SelectedIndex > 0)
            {
                vdeVesselInfo.PistonCleaningRing = cmbPistonCleaningRing2.SelectedItem.ToString();
            }
            vdeVesselInfo.NoOfEngines = 2;
            //if (cmbEngineNo.SelectedIndex >= 0)
            //{
                vdeVesselInfo.EngineNo = 2;
            //}
            vdeVesselInfo.NoOfCylinders = Convert.ToInt32(cmbNoOfCyl.SelectedItem.ToString());
            if (cmbProjectStatus.SelectedIndex >= 0)
            {
                vdeVesselInfo.ProjectStatus = cmbProjectStatus.SelectedItem.ToString();
            }
            

            int count = (from a in lstVesselData
                         where a.VesselNo == inVesselNo && a.EngineNo == 2
                         select a).Count();
            if (count > 0)
            {
                hdaDataAccess.UpdateVesselData(vdeVesselInfo);
            }
            else
            {
                hdaDataAccess.InsertVesselData(vdeVesselInfo);
            }


            return true;
        }
        #endregion
        
        #region PopulateGraph
        private void PopulateGraph(string strXAxisValue, bool isSubmit, string strYAxisValue)
        {
            List<RunningData> lstRunningGraph = new List<RunningData>();
            List<CylinderData> lstCylinderGraph = new List<CylinderData>();
           
                lstRunningData = hdaDataAccess.GetRunningData(inVesselNo, inEngineNo);
                lstCylinderData = hdaDataAccess.GetCylinderData(inVesselNo, inEngineNo);

                if (lstRunningData.Count > 0 && lstCylinderData.Count > 0)
                {
                    if (chCylinderData.Series.Count > 0)
                    {
                        int chCylinderCount = chCylinderData.Series.Count;
                        for (int a = 0; a < chCylinderCount; a++)
                        {
                            chCylinderData.Series.RemoveAt(0);
                        }
                    }

                    if (chBNData.Series.Count > 0)
                    {
                        int chCylinderBNCount = chBNData.Series.Count;
                        for (int a = 0; a < chCylinderBNCount; a++)
                        {
                            chBNData.Series.RemoveAt(0);
                        }
                    }

                    chCylinderData.ChartAreas[0].AxisY.StripLines.Clear();
                    chBNData.ChartAreas[0].AxisY.StripLines.Clear();

                    if (!isSubmit)
                    {
                        string minDate = lstRunningData.Min(r => r.DateOfReading);
                        string maxDate = lstRunningData.Max(r => r.DateOfReading);

                        lstRunningGraph = lstRunningData;
                        lstCylinderGraph = lstCylinderData;

                        dtpGraphStartDate.Text = minDate;
                        dtpGraphEndDate.Text = maxDate;
                    }
                    else
                    {
                        #region Changes for Including Magnetic and Corrosive Iron
                        lstRunningGraph = (from r in lstRunningData
                                           where Convert.ToDateTime(r.DateOfReading, CultureInfo.InvariantCulture) >= Convert.ToDateTime(dtpGraphStartDate.Value, CultureInfo.CurrentCulture)
                                       && Convert.ToDateTime(r.DateOfReading, CultureInfo.InvariantCulture) <= Convert.ToDateTime(dtpGraphEndDate.Value, CultureInfo.CurrentCulture)
                                       select r).ToList();

                        lstCylinderGraph = (from c in lstCylinderData
                                            join rg in lstRunningGraph on c.UniqueID equals rg.UniqueId
                                            select c).ToList();

                        if (lstRunningGraph.Count <= 0)
                        {
                            MessageBox.Show("There is no data in the selected time range", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        #endregion
                    }

                    double[] strXAxis = new double[lstRunningGraph.Count];
                    double[] strXAxisBN = new double[lstRunningGraph.Count];
                    double[] strXAxisDate = new double[lstRunningGraph.Count];
                    double[] strXAxisDateBN = new double[lstRunningGraph.Count];
                    int[] uniqueID = new int[lstRunningGraph.Count];
                    int k = 0;
                    int uID = 0;


                    foreach (RunningData rng in lstRunningGraph)
                    {
                        if (strXAxisValue == "Running Hours")
                        {
                            strXAxis[k] = rng.TotEngineHours;
                            strXAxisBN[k] = rng.TotEngineHours;
                        }
                        else if (strXAxisValue == "Date")
                        {
                            strXAxisDate[k] = Convert.ToDateTime(rng.DateOfReading, CultureInfo.CurrentCulture).ToOADate();
                            strXAxisDateBN[k] = Convert.ToDateTime(rng.DateOfReading, CultureInfo.CurrentCulture).ToOADate();
                        }
                        uniqueID[k] = rng.UniqueId;
                        k++;
                    }



                    double[] strYAxis = new double[lstRunningGraph.Count];
                    for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                    {
                        k = 0;

                        var query = (from a in lstCylinderGraph
                                    where a.CylinderNumber == i
                                    select a).ToList();

                        foreach (var a in query)
                        {
                            uID = uniqueID[k];
                            var query1 = from b in query
                                         where b.UniqueID == uID
                                         select b;
                            foreach (var c in query1)
                            {
                                if (strYAxisValue == "On-board Total Fe")
                                {
                                    strYAxis[k] = c.AAReading;
                                }
                                else if (strYAxisValue == "Magnetic Fe")
                                {
                                    strYAxis[k] = c.MagneticIron;
                                }
                                k++;
                            }
                        }

                        var series = new Series("Cyl " + i.ToString() + " Fe Reading");

                        // Frist parameter is X-Axis and Second is Collection of Y- Axis
                        if (strXAxisValue == "Running Hours")
                        {
                            series.XValueType = ChartValueType.Double;
                            chCylinderData.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.NotSet;
                            series.Points.DataBindXY(strXAxis, strYAxis);
                        }
                        else if (strXAxisValue == "Date")
                        {
                            series.XValueType = ChartValueType.Date;
                            series.Points.DataBindXY(strXAxisDate, strYAxis);
                        }
                        series.MarkerStyle = MarkerStyle.Diamond;

                        if (chkCylinderNumber.GetItemChecked(i - 1))
                        {
                            chCylinderData.Series.Add(series);
                        }
                        series.ChartType = SeriesChartType.Line;
                    }

                    double[] strYAxisBN = new double[lstRunningGraph.Count];
                    for (int i = 1; i <= Convert.ToInt32(strNoOfCylinders); i++)
                    {
                        k = 0;
                        var query = from a in lstCylinderGraph
                                    where a.CylinderNumber == i
                                    select a;

                        foreach (var a in query)
                        {
                            uID = uniqueID[k];
                            var query1 = from b in query
                                         where b.UniqueID == uID
                                         select b;
                            foreach (var c in query1)
                            {
                                strYAxisBN[k] = c.BNMeasuredOnboard;
                                k++;
                            }
                        }

                        var series = new Series("Cyl " + i.ToString() + " BN measured");

                        // Frist parameter is X-Axis and Second is Collection of Y- Axis
                        if (strXAxisValue == "Running Hours")
                        {
                            series.XValueType = ChartValueType.Double;
                            chBNData.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.NotSet;
                            series.Points.DataBindXY(strXAxis, strYAxisBN);
                        }
                        else if (strXAxisValue == "Date")
                        {
                            series.XValueType = ChartValueType.Date;
                            series.Points.DataBindXY(strXAxisDate, strYAxisBN);
                        }
                        series.MarkerStyle = MarkerStyle.Diamond;
                       // series.MarkerSize = 10;
                        if (chkCylinderNumber.GetItemChecked(i - 1))
                        {
                            chBNData.Series.Add(series);
                        }
                        series.ChartType = SeriesChartType.Line;
                    }

                    if (strXAxisValue == "Running Hours")
                    {
                        chCylinderData.ChartAreas[0].AxisX.Minimum = strXAxis.Min() - 10;
                        chCylinderData.ChartAreas[0].AxisX.Maximum = strXAxis.Max() + 10;

                        chBNData.ChartAreas[0].AxisX.Minimum = strXAxisBN.Min() - 10;
                        chBNData.ChartAreas[0].AxisX.Maximum = strXAxisBN.Max() + 10;
                    }
                    else if (strXAxisValue == "Date")
                    {
                        chCylinderData.ChartAreas[0].AxisX.Minimum = strXAxisDate.Min() - 5;
                        chCylinderData.ChartAreas[0].AxisX.Maximum = strXAxisDate.Max() +5;

                        chBNData.ChartAreas[0].AxisX.Minimum = strXAxisDateBN.Min() - 5;
                        chBNData.ChartAreas[0].AxisX.Maximum = strXAxisDateBN.Max() + 5;
                    }

                    chBNData.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                    chBNData.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                    chBNData.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                    chBNData.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
                    chBNData.ChartAreas[0].AxisY.Title = "BN measured, mg KOH/g";
                    chBNData.ChartAreas[0].AxisY.TitleAlignment = StringAlignment.Center;
                    //chBNData.ChartAreas[0].AxisY.Interval = 10;


                    chCylinderData.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                    chCylinderData.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
                    chCylinderData.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                    chCylinderData.ChartAreas[0].AxisY.MinorGrid.Enabled = false;
                    if (strYAxisValue == "On-board Total Fe")
                    {
                        chCylinderData.ChartAreas[0].AxisY.Title = Constants.AA_READING_GRID;
                    }
                    else if (strYAxisValue == "Magnetic Fe")
                    {
                        chCylinderData.ChartAreas[0].AxisY.Title = "Magentic Iron, ppm";
                    }

                    #region Changes for Including Magnetic and Corrosive Iron
                    //Add reference line for Iron Reading
                    StripLine stripline = new StripLine();
                    stripline.Interval = 0;
                    stripline.IntervalOffset = Convert.ToDouble(txtReferenceIron.Text);  
                    stripline.StripWidth = 0.001;
                    stripline.BackColor = Color.Red;
                    stripline.BackHatchStyle = ChartHatchStyle.DashedVertical;
                    chCylinderData.ChartAreas[0].AxisY.StripLines.Add(stripline);

                    //Add reference line for BN Measured
                    StripLine striplineBN = new StripLine();
                    striplineBN.Interval = 0;
                    striplineBN.IntervalOffset = Convert.ToDouble(txtRefBN.Text);   
                    striplineBN.StripWidth = 0.001;
                    striplineBN.BackColor = Color.Red;
                    striplineBN.BackHatchStyle = ChartHatchStyle.DashedVertical;
                    chBNData.ChartAreas[0].AxisY.StripLines.Add(striplineBN);
                    #endregion
                }

            
        }
        #endregion

        #region GetDensityInNumeric
        private double GetDensityInNumeric(string strDensity)
        {
            double dbDensity = 0;

            strDensity = strDensity.Substring(0, strDensity.IndexOf(" "));
            dbDensity = Convert.ToDouble(strDensity);

            return dbDensity;
        }
        #endregion

        #region EnableDisableButtonsForReadonly
        private void EnableDisableButtonsForReadonly(Control f, bool isEnabled)
        {
            foreach (Control c in f.Controls)
            {

                // MessageBox.Show(c.GetType().ToString());
                if (c.HasChildren)
                {
                    EnableDisableButtonsForReadonly(c, isEnabled);
                }
                else
                    if (c is Button)
                    {
                        Button lll = (Button)c;
                        lll.Enabled = isEnabled;
                    }
            }
        }
        #endregion

        #region SetLabelStyles
        private void SetLabelStyles(Control f)
        {
            Label lblSample = new Label();
            lblSample.Font = new Font("Verdana", 7, FontStyle.Regular);
            LinkLabel lnklblSample = new LinkLabel();
            lnklblSample.Font = new Font("Verdana", 11, FontStyle.Regular);
            Label lblEngineSample = new Label();
            lblEngineSample.Font = new Font("Verdana", 13, FontStyle.Bold);
            Label lblSubHeading = new Label();
            lblSubHeading.Font = new Font("Verdana", 11, FontStyle.Regular);
            Label lblMarineProd = new Label();
            lblMarineProd.Font = new Font("Verdana", 15, FontStyle.Regular);

            foreach (Control c in f.Controls)
            {

                // MessageBox.Show(c.GetType().ToString());
                if (c.HasChildren)
                {
                    SetLabelStyles(c);
                }
                else
                {
                    if (c is LinkLabel)
                    {
                        LinkLabel ll = (LinkLabel)c;
                        ll.Font = new Font(lnklblSample.Font, FontStyle.Regular);
                    }

                    else if (c is Label)
                    {
                        Label lll = (Label)c;
                        lll.Font = new Font(lblSample.Font, FontStyle.Regular);
                    }
                }
            }
            lblEngineNoFirstEng.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblEngineNoHistory.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblEngineNoSup.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblEngineNoLogBook.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblSecondEngine.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblEngNoGraph.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblSupportHistEngNo.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblRunningData.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblMarineConnect.Font = new Font(lblMarineProd.Font, FontStyle.Bold);
            lblContactUs2.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblContactUs1.Font = new Font(lblSubHeading.Font, FontStyle.Regular);            

            lblSupportBunker.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblSupportLinWear.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblSupportRngHour.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblCylInfoSupport.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblGenXML1.Font = new Font(lblSubHeading.Font, FontStyle.Bold);
            lblGenXML2.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblGenXML3.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblGenXML4.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblGenXML5.Font = new Font(lblSubHeading.Font, FontStyle.Regular);
            lblGenXML6.Font = new Font(lblSubHeading.Font, FontStyle.Regular);

            lblPgmOverview.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblCylinderDrain.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblProducts.Font = new Font(lblEngineSample.Font, FontStyle.Bold);
            lblAlexia.Font = new Font(lblEngineSample.Font, FontStyle.Bold);

        }
        #endregion

        #region ValidateNumberFormat
        private bool ValidateNumberFormat(TextBox txtBox)
        {
            Regex expression;
            string strToBeValidated = txtBox.Text;
            if (strToBeValidated != string.Empty)
            {
                if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                {
                    expression = new Regex("^[0-9]{1,11}(?:\\,[0-9]{1,3})?$");
                }
                else
                {
                    expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                }
                if (!expression.IsMatch(strToBeValidated))
                {
                    MessageBox.Show("The Value must be a number with maximum 3 decimals", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtBox.Text = string.Empty;
                    return false;
                }
            }

            return true;
        }
        #endregion

        #region ValidateLogBookDate
        private bool ValidateLogBookDate()
        {
            bool isValid = true;

            DateTime dtReading = dtDateOfReading.Value;
            DateTime dtStartDate = DateTime.Now;
            DateTime dtEndDate = DateTime.Now;

            var query = from a in lstVesselData
                        where (a.VesselNo == inVesselNo && a.EngineNo == inEngineNo)
                        select a;

            if (query.Count() > 0)
            {
                foreach (var a in query)
                {
                    dtStartDate = Convert.ToDateTime(a.StartDateOfProj, CultureInfo.CurrentCulture);
                    dtEndDate = Convert.ToDateTime(a.TargetCompletionDate, CultureInfo.CurrentCulture);
                }

                if (dtReading > dtEndDate || dtReading < dtStartDate)
                {

                    //dtDateOfReading.Value = dtEndDate;
                    isValid = false;
                }
            }

            return isValid;

        }
        #endregion

        #region ValidateSupportDate
        private bool ValidateSupportDate()
        {
            bool isValid = true;
            DateTime dtReading = dtpSupportInfo.Value;
            DateTime dtStartDate = DateTime.Now;
            DateTime dtEndDate = DateTime.Now;

            var query = from a in lstVesselData
                        where (a.VesselNo == inVesselNo && a.EngineNo == inEngineNo)
                        select a;

            foreach (var a in query)
            {
                dtStartDate = Convert.ToDateTime(a.StartDateOfProj, CultureInfo.CurrentCulture);
                dtEndDate = Convert.ToDateTime(a.TargetCompletionDate, CultureInfo.CurrentCulture);
            }

            if (dtReading > dtEndDate || dtReading < dtStartDate)
            {


                isValid = false;
            }
            return isValid;
        }
        #endregion

        private bool IsNumber(string p)
        {
            bool isNumber;
            try
            {
                Convert.ToDouble(p);
                isNumber = true;
            }
            catch
            {
                isNumber = false;
            }
            return isNumber;
        }

        private bool ValidateLogBookEntries()
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
                 
            if (txtPercentS.Text != string.Empty && !regexForNumber.IsMatch(txtPercentS.Text))
            {
                MessageBox.Show("Sulphur,% should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtPercentS.Text) && Convert.ToDouble(txtPercentS.Text) > 6.0)
            {
                MessageBox.Show("Sulphur,% should be less than 6.0", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtPower.Text != string.Empty && !regexForNumber.IsMatch(txtPower.Text))
            {
                MessageBox.Show("Power should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtPower.Text) && Convert.ToDouble(txtPower.Text) >= 100000)
            {
                MessageBox.Show("Power should be less than 100,000", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtRelHumidity.Text != string.Empty && !regexForNumber.IsMatch(txtRelHumidity.Text))
            {
                MessageBox.Show("Relative Humidity should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtRelHumidity.Text) && Convert.ToDouble(txtRelHumidity.Text) >= 100)
            {
                MessageBox.Show("Relative Humidity should be less than 100", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtAmpTemp.Text != string.Empty && !regexForNumber.IsMatch(txtAmpTemp.Text))
            {
                MessageBox.Show("Ambient Temperature should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtAmpTemp.Text) && Convert.ToDouble(txtAmpTemp.Text) >= 60)
            {
                MessageBox.Show("Ambient Temperature should be less than 60", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtScavAirTemp.Text != string.Empty && !regexForNumber.IsMatch(txtScavAirTemp.Text))
            {
                MessageBox.Show("Scav Air Temperature should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtScavAirTemp.Text) && Convert.ToDouble(txtScavAirTemp.Text) >= 80)
            {
                MessageBox.Show("Scav Air Temperature should be less than 80", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtEngRoomTemp.Text != string.Empty && !regexForNumber.IsMatch(txtEngRoomTemp.Text))
            {
                MessageBox.Show("Eng Room Temperature should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtEngRoomTemp.Text) && Convert.ToDouble(txtEngRoomTemp.Text) >= 80)
            {
                MessageBox.Show("Eng Room Temperature should be less than 80", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtCylinderOilCons.Text != string.Empty && !regexForNumber.IsMatch(txtCylinderOilCons.Text))
            {
                MessageBox.Show("Cylinder Oil Consumption should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtCylinderOilCons.Text) && Convert.ToDouble(txtCylinderOilCons.Text) >= 1000)
            {
                MessageBox.Show("Cylinder Oil Consumption should be less than 1,000", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else if (txtNoOfTCInUse.Text != string.Empty && !regexForNumber.IsMatch(txtNoOfTCInUse.Text))
            {
                MessageBox.Show("No. of turbo engines should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (IsNumber(txtNoOfTCInUse.Text) && Convert.ToDouble(txtNoOfTCInUse.Text) >= 5)
            {
                MessageBox.Show("No. of turbo engines should be less than 5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            else
            {
                return true;
            }
        }

        #endregion

        private void lnkEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var vessel = (from v in lstVesselData
                                 where v.VesselNo == inVesselNo
                                 select v).FirstOrDefault();

            string vesselName = vessel.VesselName;

            System.Diagnostics.Process.Start("mailto:SMPL-LubeMonitor@shell.com?subject=Vessel Data for " + vesselName + "&body=Please find attached the vessel data" +
                 " information for the vessel " + vesselName);

        }

        private void btnExportLogBookToExcel_Click(object sender, EventArgs e)
        {
            if (dgvReadOnlyHistory.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                XcelApp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dgvReadOnlyHistory.Columns.Count + 1; i++)
                {
                    XcelApp.Cells[1, i] = dgvReadOnlyHistory.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i < dgvReadOnlyHistory.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvReadOnlyHistory.Columns.Count; j++)
                    {
                        XcelApp.Cells[i + 2, j + 1] = dgvReadOnlyHistory.Rows[i].Cells[j].Value.ToString();

                    }
                }
                XcelApp.Columns.AutoFit();
                XcelApp.Visible = true;

            }

        }

        private void btnExportSupportToExcel_Click(object sender, EventArgs e)
        {

            if (dgvSupportHistReadOnly.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application XcelApp = new Microsoft.Office.Interop.Excel.Application();
                XcelApp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dgvSupportHistReadOnly.Columns.Count + 1; i++)
                {
                    XcelApp.Cells[1, i] = dgvSupportHistReadOnly.Columns[i - 1].HeaderText;
                }

                for (int i = 0; i < dgvSupportHistReadOnly.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvSupportHistReadOnly.Columns.Count; j++)
                    {
                        XcelApp.Cells[i + 2, j + 1] = dgvSupportHistReadOnly.Rows[i].Cells[j].Value.ToString();

                    }
                }
                XcelApp.Columns.AutoFit();
                XcelApp.Visible = true;

            }
        }

        private void txtMCR_Validating(object sender, CancelEventArgs e)
        {
            Regex expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
            if (txtMCR.Text!= string .Empty && !expression.IsMatch(txtMCR.Text))
            {
                MessageBox.Show("MCR should be a decimal with max 3 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMCR.Text = string.Empty;
            }
        }

        private void txtCurrentFeedRate_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtCurrentFeedRate.Text != string.Empty && !regexForNumber.IsMatch(txtCurrentFeedRate.Text))
            {
                MessageBox.Show("Current Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCurrentFeedRate.Text = string.Empty;
            }
            else if (IsNumber(txtCurrentFeedRate.Text) && Convert.ToDouble(txtCurrentFeedRate.Text) > 2.5)
            {
                MessageBox.Show("Current Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCurrentFeedRate.Text = string.Empty;
            }
        }

        private void txtTargetFeedRate_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtTargetFeedRate.Text != string.Empty && !regexForNumber.IsMatch(txtTargetFeedRate.Text))
            {
                MessageBox.Show("Target Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTargetFeedRate.Text = string.Empty;
            }
            else if (IsNumber(txtTargetFeedRate.Text) && Convert.ToDouble(txtTargetFeedRate.Text) > 2.5)
            {
                MessageBox.Show("Target Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTargetFeedRate.Text = string.Empty;

            }
        }

        private void txtMinFeedRate_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtMinFeedRate.Text != string.Empty && !regexForNumber.IsMatch(txtMinFeedRate.Text))
            {
                MessageBox.Show("Minimum Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMinFeedRate.Text = string.Empty;
            }
            else if (IsNumber(txtMinFeedRate.Text) && Convert.ToDouble(txtMinFeedRate.Text) > 2.5)
            {
                MessageBox.Show("Minimum Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMinFeedRate.Text = string.Empty;
            }
        }

        private void txtRPM_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtRPM.Text != string.Empty && !regexForNumber.IsMatch(txtRPM.Text))
            {
                MessageBox.Show("RPM should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRPM.Text = string.Empty;
            }
            else if (IsNumber(txtRPM.Text) && Convert.ToDouble(txtRPM.Text) >= 150)
            {
                MessageBox.Show("RPM should be less than 150", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRPM.Text = string.Empty;

            }
        }

        private void txtRPM2_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtRPM2.Text != string.Empty && !regexForNumber.IsMatch(txtRPM2.Text))
            {
                MessageBox.Show("RPM should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRPM2.Text = string.Empty;
            }
            else if (IsNumber(txtRPM2.Text) && Convert.ToDouble(txtRPM2.Text) >= 150)
            {
                MessageBox.Show("RPM should be less than 150", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRPM2.Text = string.Empty;

            }
        }

        private void txtMinFeedRate2_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtMinFeedRate2.Text != string.Empty && !regexForNumber.IsMatch(txtMinFeedRate2.Text))
            {
                MessageBox.Show("Minimum Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMinFeedRate2.Text = string.Empty;
            }
            else if (IsNumber(txtMinFeedRate2.Text) && Convert.ToDouble(txtMinFeedRate2.Text) > 2.5)
            {
                MessageBox.Show("Minimum Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMinFeedRate2.Text = string.Empty;
            }
        }

        private void txtCurrentFeedRate2_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtCurrentFeedRate2.Text != string.Empty && !regexForNumber.IsMatch(txtCurrentFeedRate2.Text))
            {
                MessageBox.Show("Current Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCurrentFeedRate2.Text = string.Empty;
            }
            else if (IsNumber(txtCurrentFeedRate2.Text) && Convert.ToDouble(txtCurrentFeedRate2.Text) > 2.5)
            {
                MessageBox.Show("Current Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCurrentFeedRate2.Text = string.Empty;
            }
        }

        private void txtTargetFeedRate2_Validating(object sender, CancelEventArgs e)
        {
            Regex regexForNumber = new Regex(@"^-*[0-9,\.]+$");
            if (txtTargetFeedRate2.Text != string.Empty && !regexForNumber.IsMatch(txtTargetFeedRate2.Text))
            {
                MessageBox.Show("Current Feed Rate should be numeric", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTargetFeedRate2.Text = string.Empty;
            }
            else if (IsNumber(txtTargetFeedRate2.Text) && Convert.ToDouble(txtTargetFeedRate2.Text) > 2.5)
            {
                MessageBox.Show("Current Feed Rate should be less than 2.5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTargetFeedRate2.Text = string.Empty;
            }
        }

        private void txtMCR2_Validating(object sender, CancelEventArgs e)
        {
            Regex expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
            if (txtMCR2.Text != string.Empty && !expression.IsMatch(txtMCR2.Text))
            {
                MessageBox.Show("MCR should be a decimal with max 3 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMCR2.Text = string.Empty;
            }
        }

        private void txtNoOfTC2_Validating(object sender, CancelEventArgs e)
        {
            Regex expression;
            string strToBeValidated = txtNoOfTC2.Text;
            if (strToBeValidated != string.Empty)
            {
                //if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                //{
                    expression = new Regex("^\\d+$");
                //}
                //else
                //{
                //    expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                //}
                if (!expression.IsMatch(strToBeValidated))
                {
                    MessageBox.Show("The Value must be a number with no decimals", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNoOfTC2.Text = string.Empty;

                }
                else
                {
                    if (Convert.ToDouble(txtNoOfTC2.Text) >= 5)
                    {
                        MessageBox.Show("No. of turbo chargers should be less than 5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtNoOfTC2.Text = string.Empty;
                    }
                }
            }
        }

        private void txtNoOfTC_Validating(object sender, CancelEventArgs e)
        {
            Regex expression;
            string strToBeValidated = txtNoOfTC.Text;
            if (strToBeValidated != string.Empty)
            {
                //if (arrCommaCultures.Contains(CultureInfo.CurrentCulture.ToString()))
                //{
                    expression = new Regex("^\\d+$");
                //}
                //else
                //{
                //    expression = new Regex("^[0-9]{1,11}(?:\\.[0-9]{1,3})?$");
                //}
                if (!expression.IsMatch(strToBeValidated))
                {
                    MessageBox.Show("The Value must be a number with no decimals", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtNoOfTC.Text = string.Empty;

                }
                else
                {
                    if (Convert.ToDouble(txtNoOfTC.Text) >= 5)
                    {
                        MessageBox.Show("No. of turbo chargers should be less than 5", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtNoOfTC.Text = string.Empty;
                    }
                }
            }
        }

        private void txtSettingIMONumber_Validating(object sender, CancelEventArgs e)
        {
            if (txtSettingIMONumber.Text != string.Empty && txtSettingIMONumber.Text.Length > 9)
            {
                MessageBox.Show("IMO number cannot have more than 9 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSettingIMONumber.Text = string.Empty;
            }
        }

        private void txtIMONo2_Validating(object sender, CancelEventArgs e)
        {
            if (txtIMONo2.Text != string.Empty && txtIMONo2.Text.Length > 9)
            {
                MessageBox.Show("IMO number cannot have more than 9 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIMONo2.Text = string.Empty;
            }
        }

        private void txtIMONo_Validating(object sender, CancelEventArgs e)
        {
            if (txtIMONo.Text != string.Empty && txtIMONo.Text.Length > 9)
            {
                MessageBox.Show("IMO number cannot have more than 9 digits", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtIMONo.Text = string.Empty;
            }
        }

        private void tsProgramInfo_Click(object sender, System.EventArgs e)
        {
            HideUnhidePanels(pnlProgramInfo.Name);
            SetResetBackGroundColor(tsProgramInfo);
            HideUnhideBrochurePanels("");
        }

        private void lnkTemplate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SetResetBackGroundColorForLinks("");
            //HideUnhidePanels(pnlSetting.Name);
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/Template Logbook.pdf");
            process.Start();
        }

        private void CustomerVesselData_Shown(object sender, EventArgs e)
        {
            //Check if this is the first time the application is being run, if yes display the below message:
            string isFirstRun = Shell.MLBCaptureVesselData.Properties.Settings.Default.IsFirstRun;
            if (isFirstRun.ToLower() == string.Empty)
            {
                MessageBox.Show("By Installing and running this application, you agree to the terms of condition which will bind you. Please uninstall the application if you do not agree to the terms of condition.", "Terms And Conditions", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                Shell.MLBCaptureVesselData.Properties.Settings.Default.IsFirstRun = "False";
                Shell.MLBCaptureVesselData.Properties.Settings.Default.Save();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SetResetBackGroundColorForLinks("");
            //HideUnhidePanels(pnlSetting.Name);
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userFilePath = Path.Combine(localAppData, "SHELL\\Brochures_Marine Connect");

            string destFilePath = Path.Combine(userFilePath, "condition_monitoring_programme.pdf");

            startInfo.FileName = Path.GetFullPath(destFilePath);
            process.Start();
        }


        void dgvCylinderData_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {
            e.Column.SortMode = DataGridViewColumnSortMode.NotSortable;
        }

        private void dtDateOfReading_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidateLogBookDate())
            {
                MessageBox.Show("Date of reading should be between the start and end date of the project", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void dtpSupportInfo_Validating(object sender, CancelEventArgs e)
        {

            if (!ValidateSupportDate())
            {
                MessageBox.Show("Date of reading should be between the start and end date of the project", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void imgLubeMonitorPgm_Click(object sender, EventArgs e)
        {
            HideUnhideBrochurePanels("pnlLubeMonitorBroch");
        }

        private void imbLubeMonitorBroch_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_lubeMonitor.pdf");
            process.Start();
        }

        private void imgLubricantsLeaflet_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_rapid_lubricants_analysis.pdf");
            process.Start();
        }

        private void HideUnhideBrochurePanels(string strVisiblePanel)
        {
            pnlCylinderDrainOil.Visible = false;
            pnlLubeMonitorBroch.Visible = false;
            pnlAlexia.Visible = false;
            pnlOtherProducts.Visible = false;
            
            switch (strVisiblePanel)
            {
                case "pnlCylinderDrainOil":
                    {
                        pnlCylinderDrainOil.Visible = true;
                        break;
                    }
                case "pnlLubeMonitorBroch":
                    {
                        pnlLubeMonitorBroch.Visible = true;
                        break;
                    }
                case "pnlAlexia":
                    {
                        pnlAlexia.Visible = true;
                        break;
                    }
                case "pnlOtherProducts":
                        {
                            pnlOtherProducts.Visible = true ;
                            break;
                        }
                default :
                    break ;
            }
        }

        private void imgOilAnalysis_Click(object sender, EventArgs e)
        {
            HideUnhideBrochurePanels("pnlCylinderDrainOil");
        }

        private void imgAlexia_Click(object sender, EventArgs e)
        {
            HideUnhideBrochurePanels("pnlAlexia");
        }

        private void imgOtherProducts_Click(object sender, EventArgs e)
        {
            HideUnhideBrochurePanels("pnlOtherProducts");
        }

        private void cmbIronAxis_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateGraph(cmbXAxis.SelectedItem.ToString(), true, cmbIronAxis.SelectedItem.ToString());
        }

        private void imgLubMonUserGuide_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_lube_monitor_user_guide.pdf");
            process.Start();
        }

        private void imgBrochure_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/getting_results_fast.pdf");
            process.Start();
        }

        private void imgOnboardBroch_Click(object sender, EventArgs e)
        {
            
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_rapid_lubricants_onboard_alert.pdf");
            process.Start();
        }

        private void imgUserGuide_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_rapid_lubricants_onboard_alert_user_guide.pdf");
            process.Start();
        }

        private void imgOnBoardUserGuide_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_rapid_lubricants_onboard_plus.pdf");
            process.Start();
        }

        private void imgAlexiaBroch_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_brochure.pdf");
            process.Start();
        }

        private void imgS6MSDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s6_msds.pdf");
            process.Start();
        }

        private void imgS6TDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s6_tds.pdf");
            process.Start();
        }

        private void imgS4MSDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s4_msds.pdf");
            process.Start();
        }

        private void imgS4TDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s4_tds.pdf");
            process.Start();
        }

        private void img50MSDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s50_msds.pdf");
            process.Start();
        }

        private void img50TDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s50_tds.pdf");
            process.Start();
        }

        private void imgS3Brochure_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s3_brochure.pdf");
            process.Start();
        }

        private void imgS3MSDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s3_msds.pdf");
            process.Start();
        }

        private void imgS3TDS_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/shell_alexia_s3_tds.pdf");
            process.Start();
        }

        private void imgProducts_Click(object sender, EventArgs e)
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            process.StartInfo = startInfo;

            startInfo.FileName = Path.GetFullPath("Files/products_table.pdf");
            process.Start();
        }
    }

        
}
