﻿using Shell.MLBCaptureVesselData;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;

namespace Shell.MLBCaptureVesselData
{
    public static class Common
    {
        public static XmlDocument doc = new XmlDocument();
        public static string strUser = System.Windows.Forms.SystemInformation.UserName;
        public static IEnumerable<string> EnumeratePropertyDifferences<T>(this T obj1, T obj2)
        {
            PropertyInfo[] properties = typeof(T).GetProperties();
            List<string> changes = new List<string>();

            foreach (PropertyInfo pi in properties)
            {
                object value1 = typeof(T).GetProperty(pi.Name).GetValue(obj1, null);
                object value2 = typeof(T).GetProperty(pi.Name).GetValue(obj2, null);

                if (value1 is DateTime && value2 is DateTime)
                {
                    DateTime from = (DateTime)value1; DateTime to = (DateTime)value2;
                    if (!DateTime.Equals(from, to)) { changes.Add(string.Format("Property {0} changed from {1} to {2}", pi.Name, value1, value2)); }
                }
                else
                {
                    if (value1 != value2 && (value1 == null || !value1.Equals(value2)))
                    {
                        changes.Add(string.Format("Property {0} changed from {1} to {2}", pi.Name, value1, value2));
                    }
                }
            }
            return changes;
        }

        public static T ReplaceEmptyStringWithDash<T>(T obj1)
        {
            PropertyInfo[] properties = typeof(T).GetProperties();
            

            foreach (PropertyInfo pi in properties)
            {
                if (pi.PropertyType.Name.ToLower() == "string")
                {
                    object value1 = typeof(T).GetProperty(pi.Name).GetValue(obj1, null);
                    if (value1.ToString() == string.Empty)
                    {
                        typeof(T).GetProperty(pi.Name).SetValue(obj1, "-",null);
                    }
                }


            }
            return obj1;
        }

        #region Method:ConvertToXML
        ///<summary> Method name		:ConvertToXML
        ///<newpara> Date of Creation	:17/06/2005
        ///<newpara> Description		:To convert entity object or entity object array to xml string.
        ///								 It will also convert any primitive type array to xml string.
        ///<newpara> Author				:IBM     
        ///</summary>
        ///<param name="errorCode">Error code as parameter</param> 
        ///<returns>string</returns >
        ///<exception></exception >
        ///<remarks>It will gives error if entity object contains any Arraylist property and property contains some
        ///	some values. So don't use arraylist as property. If object parameter is arralist of the entity object then it want work so in that case we need
        /// to convert that arraylist of entity into array of entity using ToArray() Method.
        ///</remarks>		
        public static string ConvertToXML(object inputObj)
        {
            string strOutputXML;
            // pattern for removing xml namespace declaration
            string strPatternXsd = "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"";
            string strReplaceXsd = "";
            // pattern for removing xmi namespace declaration
            string strPatternXsi = "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"";
            string strReplaceXsi = "";

            // patterns for removing minvalue of the different datatypes like doulbe,int,long,datetime,decimal...
            string strPatternDouble = @"<[a-z-A-Z-0-9]+>-1\.7976931348623157E\+308\b</[a-z-A-Z-0-9]+>";
            string strPatternInt = @"<[a-z-A-Z-0-9]+>-2147483648\b</[a-z-A-Z-0-9]+>";
            string strPatternLong = @"<[a-z-A-Z-0-9]+>-9223372036854775808\b</[a-z-A-Z-0-9]+>";
            string strPatternDateTime = @"<[a-z-A-Z-0-9]+>0001-01-01T00:00:00\.0000000\+05:30\b</[a-z-A-Z-0-9]+>";
            string strPatternDecimal = @"<[a-z-A-Z-0-9]+>-79228162514264337593543950335\b</[a-z-A-Z-0-9]+>";

            // get xml serializer object
            XmlSerializer objXS = new XmlSerializer(inputObj.GetType());
            StringWriter objSW = new StringWriter();
            // serialize object into string writer
            objXS.Serialize(objSW, inputObj);
            strOutputXML = objSW.ToString();
            // replace \r\n with blank
            strOutputXML = strOutputXML.Replace("\r\n", "");

            // remove initial xml declaration statement
            int intXMLStartTagPos = strOutputXML.IndexOf("?>", 0);
            if (intXMLStartTagPos != -1)
            {
                strOutputXML = strOutputXML.Substring(intXMLStartTagPos + 2, strOutputXML.Length - intXMLStartTagPos - 2);
            }

            // replace all pattern with blank values.
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternDouble, "");
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternInt, "");
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternLong, "");
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternDateTime, "");
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternDecimal, "");
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternXsd, strReplaceXsd);
            strOutputXML = System.Text.RegularExpressions.Regex.Replace(strOutputXML, strPatternXsi, strReplaceXsi);

            //return strOutputXML;

            doc = new XmlDocument();
            doc.LoadXml(strOutputXML);

            XmlNode root = doc.DocumentElement;

            ////Create a new title element.
            //XmlElement elem = doc.CreateElement("title");
            //elem.InnerText = "The Handmaid's Tale";

            ////Replace the title element.
            //root.ReplaceChild(elem, root.FirstChild);

            ReplaceXMLElements(root);

            strOutputXML = doc.InnerXml.ToString();
            return strOutputXML;
        }
        #endregion

        
        private static void ReplaceXMLElements(XmlNode root)
        {
            List<Test> tstIDs = new List<Test>();
            tstIDs = PopulateTestIDs();
            if (root is XmlElement) 
             {
                 if (root.HasChildNodes)
                     ReplaceXMLElements(root.FirstChild);
                 if (root.NextSibling != null)
                     ReplaceXMLElements(root.NextSibling);
             }
            else if (root is XmlText)
            {
                XmlNode parentNode = root.ParentNode;
                XmlNode replace = parentNode.ParentNode;
                XmlNode nextNode = parentNode.NextSibling;
                Test tstID = (from a in tstIDs
                              where (a.NodeName == parentNode.Name)
                              select a).FirstOrDefault();
                if (tstID != null)
                {
                    XmlElement elem = doc.CreateElement("Test");
                    elem.SetAttribute("Name", tstID.TestName);
                    elem.SetAttribute("ID", tstID.TestId.ToString());
                    XmlElement result = doc.CreateElement("Result");
                    result.InnerText = root.InnerText;
                    elem.AppendChild(result);
                    replace.ReplaceChild(elem, parentNode);

                    if (nextNode != null)
                    {
                        ReplaceXMLElements(nextNode);
                    }
                }
            }

        }

        private static List<Test> PopulateTestIDs()
        {
            List<Test> lstTestIds = new List<Test>();

            Test tstID = new Test();

            #region Changes for Including Magnetic and Corrosive Iron
            tstID.TestId = 501;
            tstID.TestName = "Magnetic Iron, ppm";
            tstID.NodeName = "MagneticIron";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 529;
            tstID.TestName = "Corrosive Iron, ppm";
            tstID.NodeName = "CorrosiveIron";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 530;
            tstID.TestName = "On-board Total Iron, ppm";
            tstID.NodeName = "AAReading";
            lstTestIds.Add(tstID);
            #endregion

            tstID = new Test();
            tstID.TestId = 502;
            tstID.TestName = "Pmax, bar";
            tstID.NodeName = "PMax";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 503;
            tstID.TestName = "Fuel Index";
            tstID.NodeName = "FuelIndex";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 504;
            tstID.TestName = "Cooling Water Temp °C out";
            tstID.NodeName = "CoolingWaterTemp";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 505;
            tstID.TestName = "Liner Wall Temp °C min";
            tstID.NodeName = "LinearWallTempMin";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 506;
            tstID.TestName = "Liner Wall Temp °C max";
            tstID.NodeName = "LinearWallTempMax";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 507;
            tstID.TestName = "Feedrate setpoint";
            tstID.NodeName = "FederateSetPoint";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 508;
            tstID.TestName = "BN measured onboard, mg KOH/g";
            tstID.NodeName = "BNMeasuredOnboard";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 509;
            tstID.TestName = "Tot Engine Hrs";
            tstID.NodeName = "TotEngineHours";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 510;
            tstID.TestName = "RPM";
            tstID.NodeName = "CylinderRPM";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 511;
            tstID.TestName = "Power, kW";
            tstID.NodeName = "Power";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 512;
            tstID.TestName = "% MCR";
            tstID.NodeName = "PercentMCR";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 513;
            tstID.TestName = "Fuel in use % S";
            tstID.NodeName = "PercentS";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 514;
            tstID.TestName = "Fuel in use Catfines (Al + Si), ppm";
            tstID.NodeName = "Catfines";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 515;
            tstID.TestName = "Fuel in use Vanadium content, ppm";
            tstID.NodeName = "Vanadium";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 516;
            tstID.TestName = "Fuel in use Consumption,kg/hr";
            tstID.NodeName = "Consumption";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 517;
            tstID.TestName = "Rel Hum %";
            tstID.NodeName = "RelativeHumidity";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 518;
            tstID.TestName = "Amb Temp °C";
            tstID.NodeName = "AmbTemp";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 519;
            tstID.TestName = "Scav air temp°C";
            tstID.NodeName = "ScavAirTemp";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 520;
            tstID.TestName = "Eng Room T°C";
            tstID.NodeName = "EngRoomTemp";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 521;
            tstID.TestName = "Cylinder oil cons ltrs/day (measured)";
            tstID.NodeName = "CylinderOilConsump";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 522;
            tstID.TestName = "Feed rate (measured/calculated), g/kWh";
            tstID.NodeName = "Federate";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 523;
            tstID.TestName = "Sample sent for RLA Cylinder Check";
            tstID.NodeName = "SampleSentRCC";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 524;
            tstID.TestName = "No of Turbochargers in use";
            tstID.NodeName = "NoOfTCInUse";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 525;
            tstID.TestName = "Bunker Deliv Note S content%";
            tstID.NodeName = "BDNSContent";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 526;
            tstID.TestName = "Liner";
            tstID.NodeName = "Liner";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 526;
            tstID.TestName = "Prings";
            tstID.NodeName = "Prings";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 526;
            tstID.TestName = "PCrown";
            tstID.NodeName = "PCrown";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 527;
            tstID.TestName = "Liner Calib (Max Reading) Forward/Aft, mm";
            tstID.NodeName = "Forward";
            lstTestIds.Add(tstID);

            tstID = new Test();
            tstID.TestId = 528;
            tstID.TestName = "Liner Calib (Max Reading) Port/Starboard, mm";
            tstID.NodeName = "PortStarBoard";
            lstTestIds.Add(tstID);

            return lstTestIds;
        }


        public static void WriteTextFile(Exception ex, string user)
        {
            // Create StringBuilder to maintain publishing information.
            StringBuilder strbldInfo = new StringBuilder();

            string strErrorLogFileName = null;
            string strFileName = null;
            string conTextSeparator = "************************************************************************";

            if (ex == null)
            {
                strbldInfo.AppendFormat("{0}{0}No Exception object has been provided.{0}", Environment.NewLine);
            }
            else
            {
                #region Loop through each exception class in the chain of exception objects
                // Loop through each exception class in the chain of exception objects.
                Exception objCurrentException = ex;// Temp variable to hold InnerException object during the loop.
                int intExceptionCount = 1;				// Count variable to track the number of exceptions in the chain.
                do
                {
                    // Write title information for the exception object.
                    strbldInfo.AppendFormat("{0}{0}{1}) Exception Information{0}{2}", Environment.NewLine, intExceptionCount.ToString(), conTextSeparator);
                    strbldInfo.AppendFormat("{0}Exception Type: {1}", Environment.NewLine, objCurrentException.GetType().FullName);

                    #region Loop through the public properties of the exception object and record their value
                    // Loop through the public properties of the exception object and record their value.
                    PropertyInfo[] arrPublicProperties = objCurrentException.GetType().GetProperties();
                    NameValueCollection currentAdditionalInfo;
                    foreach (PropertyInfo p in arrPublicProperties)
                    {
                        // Do not log information for the InnerException or StackTrace. This information is 
                        // captured later in the process.
                        if (p.Name != "OriginalException")
                        {
                            if (p.GetValue(objCurrentException, null) == null)
                            {
                                strbldInfo.AppendFormat("{0}{1}: NULL", Environment.NewLine, p.Name);
                            }
                            else
                            {
                                // Loop through the collection of AdditionalInformation if the exception type is a BaseApplicationException.
                                if (p.Name == "AdditionalInformation" && objCurrentException is ApplicationException)
                                {
                                    // Verify the collection is not null.
                                    if (p.GetValue(objCurrentException, null) != null)
                                    {
                                        // Cast the collection into a local variable.
                                        currentAdditionalInfo = (NameValueCollection)p.GetValue(objCurrentException, null);

                                        // Check if the collection contains values.
                                        if (currentAdditionalInfo.Count > 0)
                                        {
                                            strbldInfo.AppendFormat("{0}AdditionalInformation:", Environment.NewLine);

                                            // Loop through the collection adding the information to the string builder.
                                            for (int i = 0; i < currentAdditionalInfo.Count; i++)
                                            {
                                                strbldInfo.AppendFormat("{0}{1}: {2}", Environment.NewLine, currentAdditionalInfo.GetKey(i), currentAdditionalInfo[i]);
                                            }
                                        }
                                    }
                                }
                                // Otherwise just write the ToString() value of the property.
                                else
                                {
                                    strbldInfo.AppendFormat("{0}{1}: {2}", Environment.NewLine, p.Name, p.GetValue(objCurrentException, null));
                                }
                            }
                        }
                    }
                    #endregion

                    // Reset the temp exception object and iterate the counter.
                    objCurrentException = objCurrentException.InnerException;
                    intExceptionCount++;
                } while (objCurrentException != null);
                #endregion
            }

            //get error log folder path
            strErrorLogFileName = System.Windows.Forms.Application.StartupPath.ToString(); 
            // create file name for current date 
            strFileName = "ErrorLog_" + DateTime.Now.Day.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Year.ToString() + ".txt";
            strErrorLogFileName = Path.GetFullPath(strErrorLogFileName + strFileName);
            FileInfo objLogFileInfo = new FileInfo(strErrorLogFileName);
            // if file is already exists then append the message
            if (objLogFileInfo.Exists)
            {
                using (FileStream objFS = new FileStream(objLogFileInfo.FullName, FileMode.Append, FileAccess.Write))
                {
                    StreamWriter objFileWriter = new StreamWriter(objFS);
                    objFileWriter.BaseStream.Seek(0, SeekOrigin.End);

                    objFileWriter.WriteLine("Log Entry : ");
                    objFileWriter.WriteLine("{0} {1} ", DateTime.Now.ToLongTimeString(),
                        DateTime.Now.ToLongDateString());

                    objFileWriter.WriteLine("User: {0}",user);

                    objFileWriter.WriteLine(strbldInfo.ToString() + "\r\n");
                    objFileWriter.WriteLine("------------------------------------\r\n");

                    objFileWriter.Flush();

                    objFileWriter.Close();
                }
            }
            // if file is not exists then create new file and append the message
            else
            {
                using (FileStream objFS = new FileStream(objLogFileInfo.FullName, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    StreamWriter objFileWriter = new StreamWriter(objFS);
                    objFileWriter.BaseStream.Seek(0, SeekOrigin.End);

                    objFileWriter.WriteLine("Log Entry : ");
                    objFileWriter.WriteLine("{0} {1} \r\n", DateTime.Now.ToLongTimeString(),
                        DateTime.Now.ToLongDateString());

                    objFileWriter.WriteLine("User: {0} \r\n", user);

                    objFileWriter.WriteLine(strbldInfo.ToString() + "\r\n");
                    objFileWriter.WriteLine("------------------------------------\r\n");

                    objFileWriter.Flush();

                    objFileWriter.Close();
                }
            }

        }

    }
}
