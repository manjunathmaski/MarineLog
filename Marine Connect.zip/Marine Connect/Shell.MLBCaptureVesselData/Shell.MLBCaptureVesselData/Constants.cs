﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MLBCaptureVesselData
{
    public class Constants
    {
        #region Vessel Constants
        public const string VESSEL_NO = "Vessel_No";
        public const string COMPANY_NAME = "Company_Name";
        public const string NO_OF_VESSELS = "No_Of_Vessels";
        public const string CUSTOMER_CONTACT = "Customer_Contact";
        public const string ADDRESS = "Address";
        public const string EMAIL = "Email";
        public const string TELEPHONE = "Telephone";
        public const string SMP_ADDRESS = "SMP_Address";
        public const string SMP_EMAIL = "SMP_Email";
        public const string SMP_TELEPHONE = "SMP_Telephone";
        public const string SMP_CONTACT = "SMP_Contact";
        public const string START_DATE_OF_PROJECT = "Start_Date_Of_Proj";
        public const string TGT_COMPLETION_DATE = "Target_Completion_Date";
        public const string VESSEL_NAME = "Vessel_Name";
        public const string IMO_NO = "IMO_No";
        public const string VESSEL_ID = "Vessel_ID";
        public const string DATE_DELIVERED = "Date_Delivered";
        public const string MAIN_ENG_MANUFACTURER = "Main_Eng_Manufacturer";
        public const string MAIN_ENGINE_TYPE = "Main_Engine_Type";
        public const string MAIN_ENGINE_SERIAL_NO = "Main_Engine_Serial_No";
        public const string MAIN_ENGINE_LOCATION = "Main_Engine_Location";
        public const string MAIN_ENGINE_NO = "Main_Engine_no";
        public const string MCR = "MCR";
        public const string RPM = "RPM";
        public const string LUBRICATOR_TYPE = "Lubricator_Type";
        public const string MIN_FEED_RATE = "Min_Feed_Rate";
        public const string CURRENT_FEED_RATE = "Current_Feed_Rate";
        public const string TARGET_FEED_RATE = "Target_Feed_Rate";
        public const string OIL_GRADE = "Oil_Grade";
        public const string DENSITY = "Density";
        public const string NO_OF_TURBOS = "No_Of_Turbos";
        public const string TURBO_CUTOUT_AVAILABLE = "Turbo_Cutout_Available";
        public const string PISTON_CLEANING_RING = "Piston_Cleaning_Ring";
        public const string NO_OF_ENGINES = "No_Of_Engines";
        public const string ENGINE_NO = "Engine_No";
        public const string PROJECT_STATUS = "Project_Status";

        #endregion

        #region Running Data
        public const string UNIQUE_ID = "Unique_Id";
        public const string DATE_OF_READING = "Date_Of_Reading";
        public const string PORTSEA = "PortSea";
        public const string NO_OF_CYLINDERS = "No_Of_Cylinders";
        public const string TOT_ENGINE_HOURS = "Tot_Engine_Hours";
        public const string CYLINDER_RPM = "Cylinder_RPM";
        public const string POWER = "Power";
        public const string PERCENT_MCR = "Percent_MCR";
        public const string PERCENT_S = "Percent_S";
        public const string CATFINES = "Catfines";
        public const string VANADIUM = "Vanadium";
        public const string CONSUMPTION = "Consumption";
        public const string REL_HUMIDITY = "Rel_Humidity";
        public const string AMB_TEMP = "Amb_Temp";
        public const string SCAV_AIR_TEMP = "Scav_Air_Temp";
        public const string ENG_ROOM_TEMP = "Eng_Room_Temp";
        public const string CYLINDER_OIL_CONSUMP = "Cylinder_Oil_Consump";
        public const string FEDERATE = "Federate";
        public const string SAMPLE_SENT_RCC = "Sample_Sent_RCC";
        public const string NO_OF_TC_IN_USE = "No_Of_TC_In_Use";
        public const string COMMENTS = "Comments";
        #endregion

        #region Cylinder Data
        public const string CYLINDER_UNIQUE_ID = "Unique_Id";
        public const string CYLINDER_NUMBER = "Cylinder_Number";
        public const string AA_READING = "AA_Reading";
        public const string PMAX = "PMax";
        public const string FUEL_INDEX = "Fuel_Index";
        public const string COOLING_WATER_TEMP = "Cooling_Water_Temp";
        public const string LINEAR_WALL_TEMP_MIN = "Linear_Wall_Temp_Min";
        public const string LINEAR_WALL_TEMP_MAX = "Linear_Wall_Temp_Max";
        public const string FEDERATE_SETPOINT = "Federate_SetPoint";
        public const string BN_MEASURED_ONBOARD = "BN_Measured_Onboard";
        public const string MAGNETIC_IRON = "Magnetic_Iron";
        public const string CORROSIVE_IRON = "Corrosive_Iron";
        #endregion

        #region Cylinder Data Column Names for GRID
        public const string CYLINDER_NUMBER_GRID = "Cylinder Number";
        public const string AA_READING_GRID = "On-board Total Iron, ppm";
        public const string PMAX_GRID = "PMax, bar";
        public const string FUEL_INDEX_GRID = "Fuel Index";
        public const string COOLING_WATER_TEMP_GRID = "Cooling Water Temp °C out";
        public const string LINEAR_WALL_TEMP_MIN_GRID = "Liner Wall Temp °C min";
        public const string LINEAR_WALL_TEMP_MAX_GRID = "Liner Wall Temp °C max";
        public const string FEDERATE_SETPOINT_GRID = "Feedrate setpoint, g/kWh ";
        public const string BN_MEASURED_ONBOARD_GRID = "BN measured onboard, mg KOH/g";
        public const string MAGNETIC_IRON_GRID = "Magnetic Iron, ppm";
        public const string CORROSIVE_IRON_GRID = "Corrosive Iron, ppm";
        #endregion

        #region Bunker Information
        public const string DATE_BUNKERED = "Date_Bunkered";
        public const string QUANTITY_BUNKERED = "Quantity_Bunkered";
        public const string BDNS_CONTENT = "BDNS_Content";
        public const string QUANTITY_BUNKERED_COL = "Quantity Bunkered";
        public const string BDNS_CONTENT_COL = "Sulphur, %";
        #endregion

        #region Cylinder Inspection
        public const string DATE_OF_INSPECTION = "Date_Of_Inspection";
        public const string DATE_OF_INSPECTION_GRID = "Date last Engine / Cylinder inspection";
        #endregion

        #region Linear Wear
        public const string DATE_MEASURED = "Date_Measured";
        public const string FORWARD = "Forward";
        public const string PORT_STARBOARD = "Port_StarBoard";
        #endregion
        
        #region Running Hour
        public const string CYLINDER_NO = "Cylinder_No";
        public const string READING_DATE = "Reading_Date";
        public const string LINEAR = "Liner";
        public const string PRINGS = "Piston Ring";
        public const string PCROWN = "Piston Crown";

        public const string LINEAR_DB = "Linear";
        public const string PRINGS_DB = "PRings";
        public const string PCROWN_DB = "PCrown";
        
        #endregion

        #region Running Hour Grid
        public const string READING_DATE_GRID = "Reading Date";
        #endregion

        #region Linear Wear Grid
        public const string DATE_MEASURED_GRID = "Date Measured";
        public const string FORWARD_GRID = "Forward/Aft, mm";
        public const string PORT_STARBOARD_GRID = "Port/Starboard, mm";
        #endregion

        #region Color constants
        public const int SHELL_RED_RED = 212;
        public const int SHELL_RED_GREEN = 46;
        public const int SHELL_RED_BLUE = 18;
        #endregion

        #region Message Constants
        public const string SAVE_SUCCESS = "Data saved successfully";
        public const string SAVE_FAILURE = "There was an issue!Please contact admin!";
        public const string FILE_SAVE_SUCCESS = "File has been saved successfully";
        public const string DELETE_SUCCESS = "Project data deleted successfully";
        #endregion

        #region Density Constants
        public const string ALEXIA_50 = "Alexia 50 (70 BN)";
        public const string ALEXIA_S3 = "Alexia S3 (25 BN)";
        public const string ALEXIA_S4 = "Alexia S4 (60 BN)";
        public const string ALEXIA_S5 = "Alexia S5 (80 BN)";
        public const string ALEXIA_S6 = "Alexia S6 (100 BN)";
        #endregion

        

    }
}
