﻿namespace MLBCaptureVesselData
{
    partial class CustomerVesselData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea35 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend35 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea36 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend36 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.tsMLBToolStrip = new System.Windows.Forms.ToolStrip();
            this.tstxtEngInfo = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtLogBookDetail = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtHistory = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtSupport = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtSupportHistory = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtGraph = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsTxtDataSubmission = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsProgramInfo = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlProgramInfo = new System.Windows.Forms.Panel();
            this.imgOtherProducts = new System.Windows.Forms.PictureBox();
            this.imgAlexia = new System.Windows.Forms.PictureBox();
            this.imgOilAnalysis = new System.Windows.Forms.PictureBox();
            this.imgLubeMonitorPgm = new System.Windows.Forms.PictureBox();
            this.pnlCylinderDrainOil = new System.Windows.Forms.Panel();
            this.lblCylinderDrain = new System.Windows.Forms.Label();
            this.imgOnBoardUserGuide = new System.Windows.Forms.PictureBox();
            this.imgUserGuide = new System.Windows.Forms.PictureBox();
            this.imgOnboardBroch = new System.Windows.Forms.PictureBox();
            this.imgBrochure = new System.Windows.Forms.PictureBox();
            this.imgLubricantsLeaflet = new System.Windows.Forms.PictureBox();
            this.imgLubMonUserGuide = new System.Windows.Forms.PictureBox();
            this.pnlOtherProducts = new System.Windows.Forms.Panel();
            this.lblProducts = new System.Windows.Forms.Label();
            this.imgProducts = new System.Windows.Forms.PictureBox();
            this.pnlAlexia = new System.Windows.Forms.Panel();
            this.lblAlexia = new System.Windows.Forms.Label();
            this.imgS3TDS = new System.Windows.Forms.PictureBox();
            this.imgS3MSDS = new System.Windows.Forms.PictureBox();
            this.imgS3Brochure = new System.Windows.Forms.PictureBox();
            this.img50TDS = new System.Windows.Forms.PictureBox();
            this.img50MSDS = new System.Windows.Forms.PictureBox();
            this.imgS4TDS = new System.Windows.Forms.PictureBox();
            this.imgS4MSDS = new System.Windows.Forms.PictureBox();
            this.imgS6TDS = new System.Windows.Forms.PictureBox();
            this.imgS6MSDS = new System.Windows.Forms.PictureBox();
            this.imgAlexiaBroch = new System.Windows.Forms.PictureBox();
            this.pnlLubeMonitorBroch = new System.Windows.Forms.Panel();
            this.lblPgmOverview = new System.Windows.Forms.Label();
            this.imbLubeMonitorBroch = new System.Windows.Forms.PictureBox();
            this.pnlTermsAndConditions = new System.Windows.Forms.Panel();
            this.lblTandC = new System.Windows.Forms.Label();
            this.pnlHome = new System.Windows.Forms.Panel();
            this.imgHome = new System.Windows.Forms.PictureBox();
            this.pnlEngine2 = new System.Windows.Forms.Panel();
            this.cmbEngManuf2 = new System.Windows.Forms.ComboBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblSecondEngine = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.btnFirstEngine = new System.Windows.Forms.Button();
            this.btnSaveEngine2 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.cmbPistonCleaningRing2 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.cmbTCCutOutAvail2 = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtNoOfTC2 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtTargetFeedRate2 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtMinFeedRate2 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtCurrentFeedRate2 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtLubType2 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtMCR2 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.txtRPM2 = new System.Windows.Forms.TextBox();
            this.txtMainEngNo2 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtMainEngSerialNo2 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txtMainEngLoc2 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.txtMainEngType2 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.dtpDateDelivered2 = new System.Windows.Forms.DateTimePicker();
            this.label63 = new System.Windows.Forms.Label();
            this.txtVesselId2 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtIMONo2 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtVesselName2 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.pnlEngineInfo = new System.Windows.Forms.Panel();
            this.cmbEngManuf = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.lblEngineNoFirstEng = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.btnSecondEngine = new System.Windows.Forms.Button();
            this.btnSaveEngineInfo = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbPistonCleaning = new System.Windows.Forms.ComboBox();
            this.lblPistonCleaning = new System.Windows.Forms.Label();
            this.cmbTCCutavail = new System.Windows.Forms.ComboBox();
            this.lblTCCut = new System.Windows.Forms.Label();
            this.txtNoOfTC = new System.Windows.Forms.TextBox();
            this.lblNoOfTC = new System.Windows.Forms.Label();
            this.txtTargetFeedRate = new System.Windows.Forms.TextBox();
            this.lblTgtFeedRate = new System.Windows.Forms.Label();
            this.txtMinFeedRate = new System.Windows.Forms.TextBox();
            this.lblMinFeedRate = new System.Windows.Forms.Label();
            this.txtCurrentFeedRate = new System.Windows.Forms.TextBox();
            this.lblCurrentFeedRate = new System.Windows.Forms.Label();
            this.txtLubType = new System.Windows.Forms.TextBox();
            this.lblLubType = new System.Windows.Forms.Label();
            this.txtMCR = new System.Windows.Forms.TextBox();
            this.lblMCR = new System.Windows.Forms.Label();
            this.lblRPM = new System.Windows.Forms.Label();
            this.txtRPM = new System.Windows.Forms.TextBox();
            this.txtMainEngNo = new System.Windows.Forms.TextBox();
            this.lblEngNo = new System.Windows.Forms.Label();
            this.txtMainEngSerialNo = new System.Windows.Forms.TextBox();
            this.lblEngSerialNo = new System.Windows.Forms.Label();
            this.txtMainEngLoc = new System.Windows.Forms.TextBox();
            this.lblEngLoc = new System.Windows.Forms.Label();
            this.lblEngManuf = new System.Windows.Forms.Label();
            this.txtMainEngType = new System.Windows.Forms.TextBox();
            this.lblEngType = new System.Windows.Forms.Label();
            this.dtDateDelivered = new System.Windows.Forms.DateTimePicker();
            this.lblDateDelivered = new System.Windows.Forms.Label();
            this.txtVesselId = new System.Windows.Forms.TextBox();
            this.lblVesselId = new System.Windows.Forms.Label();
            this.txtIMONo = new System.Windows.Forms.TextBox();
            this.lblIMONo = new System.Windows.Forms.Label();
            this.txtVesselName = new System.Windows.Forms.TextBox();
            this.lblVesselName = new System.Windows.Forms.Label();
            this.pnlDataSubmission = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblGenXML1 = new System.Windows.Forms.Label();
            this.lblGenXML6 = new System.Windows.Forms.Label();
            this.lblGenXML5 = new System.Windows.Forms.Label();
            this.lblGenXML3 = new System.Windows.Forms.Label();
            this.lblGenXML2 = new System.Windows.Forms.Label();
            this.lblGenXML4 = new System.Windows.Forms.Label();
            this.lnkEmail = new System.Windows.Forms.LinkLabel();
            this.dtpDateTo = new System.Windows.Forms.DateTimePicker();
            this.lblDateTo = new System.Windows.Forms.Label();
            this.dtpDateFrom = new System.Windows.Forms.DateTimePicker();
            this.lblDateFrom = new System.Windows.Forms.Label();
            this.lblFileLocation = new System.Windows.Forms.Label();
            this.lblFileSavedMessage = new System.Windows.Forms.Label();
            this.btnSubmitData = new System.Windows.Forms.Button();
            this.pnlSetting = new System.Windows.Forms.Panel();
            this.lblHidden = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbNoOfEngines = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.cmbNoOfCyl = new System.Windows.Forms.ComboBox();
            this.cmbProjectStatus = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lblNoOfEngines = new System.Windows.Forms.Label();
            this.lblNoOfCyl = new System.Windows.Forms.Label();
            this.btnSaveSetting = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.txtSettingVslId = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtSettingIMONumber = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtSettingVesselName = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtSMPPhone = new System.Windows.Forms.TextBox();
            this.lblSMPPhone = new System.Windows.Forms.Label();
            this.txtCustTelephone = new System.Windows.Forms.TextBox();
            this.lblCustPhone = new System.Windows.Forms.Label();
            this.txtSMPEMail = new System.Windows.Forms.TextBox();
            this.lblSMPEmail = new System.Windows.Forms.Label();
            this.txtCustEmail = new System.Windows.Forms.TextBox();
            this.lblCustEmail = new System.Windows.Forms.Label();
            this.txtSMPAddress = new System.Windows.Forms.TextBox();
            this.lblSMPAddress = new System.Windows.Forms.Label();
            this.txtCustAddress = new System.Windows.Forms.TextBox();
            this.lblCustAddress = new System.Windows.Forms.Label();
            this.txtSMPContact = new System.Windows.Forms.TextBox();
            this.lblSMPContact = new System.Windows.Forms.Label();
            this.txtCustomerContact = new System.Windows.Forms.TextBox();
            this.lblCustomerContact = new System.Windows.Forms.Label();
            this.dtpTargetEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblTgtCompdate = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.txtNoOfVessels = new System.Windows.Forms.TextBox();
            this.lblNoOfVessels = new System.Windows.Forms.Label();
            this.txtCompName = new System.Windows.Forms.TextBox();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.txtProjectID = new System.Windows.Forms.TextBox();
            this.lblProjectId = new System.Windows.Forms.Label();
            this.btnNew = new System.Windows.Forms.Button();
            this.dgvProjectData = new System.Windows.Forms.DataGridView();
            this.pnlConUs = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lnkHere = new System.Windows.Forms.LinkLabel();
            this.lblContactUs2 = new System.Windows.Forms.Label();
            this.lblContactUs1 = new System.Windows.Forms.Label();
            this.pnlGraph = new System.Windows.Forms.Panel();
            this.txtRefBN = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtReferenceIron = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbIronAxis = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpGraphEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpGraphStartDate = new System.Windows.Forms.DateTimePicker();
            this.chkCylinderNumber = new System.Windows.Forms.CheckedListBox();
            this.lblEngNoGraph = new System.Windows.Forms.Label();
            this.btnSubmitGraph = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbXAxis = new System.Windows.Forms.ComboBox();
            this.chBNData = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chCylinderData = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pnlSupportInfo = new System.Windows.Forms.Panel();
            this.lblNewSupport = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.chkLstCylInspection = new System.Windows.Forms.CheckedListBox();
            this.btnAddNewSupport = new System.Windows.Forms.Button();
            this.dtpSupportInfo = new System.Windows.Forms.DateTimePicker();
            this.lblEngineNoSup = new System.Windows.Forms.Label();
            this.lblCylInfoSupport = new System.Windows.Forms.Label();
            this.dgvLinearWear = new System.Windows.Forms.DataGridView();
            this.label39 = new System.Windows.Forms.Label();
            this.lblSupportLinWear = new System.Windows.Forms.Label();
            this.dgvRunningHour = new System.Windows.Forms.DataGridView();
            this.lblSupportRngHour = new System.Windows.Forms.Label();
            this.btnSaveSupportInfo = new System.Windows.Forms.Button();
            this.lblSupportBunker = new System.Windows.Forms.Label();
            this.dgvBunkerInfo = new System.Windows.Forms.DataGridView();
            this.dgvCylInpsection = new System.Windows.Forms.DataGridView();
            this.pnlSupportHistory = new System.Windows.Forms.Panel();
            this.btnExportSupportToExcel = new System.Windows.Forms.Button();
            this.lblSupportHistEngNo = new System.Windows.Forms.Label();
            this.dgvSupportHistReadOnly = new System.Windows.Forms.DataGridView();
            this.pnlHistory = new System.Windows.Forms.Panel();
            this.btnExportLogBookToExcel = new System.Windows.Forms.Button();
            this.lblEngineNoHistory = new System.Windows.Forms.Label();
            this.dgvReadOnlyHistory = new System.Windows.Forms.DataGridView();
            this.pnlLogBookInfo = new System.Windows.Forms.Panel();
            this.lnkTemplate = new System.Windows.Forms.LinkLabel();
            this.lblIsNew = new System.Windows.Forms.Label();
            this.pnlRunningData = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.txtDensity2 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.cmbOilGrade2 = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtConsump = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblConsump = new System.Windows.Forms.Label();
            this.lblRunningData = new System.Windows.Forms.Label();
            this.txtNoOfTCInUse = new System.Windows.Forms.TextBox();
            this.txtCatfines = new System.Windows.Forms.TextBox();
            this.txtVanadium = new System.Windows.Forms.TextBox();
            this.lblCatFines = new System.Windows.Forms.Label();
            this.lblVanadium = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.txtPercentS = new System.Windows.Forms.TextBox();
            this.lblPercentS = new System.Windows.Forms.Label();
            this.lblComments = new System.Windows.Forms.Label();
            this.lblEngRoomTemp = new System.Windows.Forms.Label();
            this.txtEngRoomTemp = new System.Windows.Forms.TextBox();
            this.lblScavAirTemp = new System.Windows.Forms.Label();
            this.txtScavAirTemp = new System.Windows.Forms.TextBox();
            this.lblPower = new System.Windows.Forms.Label();
            this.txtPower = new System.Windows.Forms.TextBox();
            this.lblSampleForRCC = new System.Windows.Forms.Label();
            this.cmbSampleForRCC = new System.Windows.Forms.ComboBox();
            this.lblAmpTemp = new System.Windows.Forms.Label();
            this.txtAmpTemp = new System.Windows.Forms.TextBox();
            this.lblCylinderRPM = new System.Windows.Forms.Label();
            this.txtCylinderRPM = new System.Windows.Forms.TextBox();
            this.lblCylinderOilCons = new System.Windows.Forms.Label();
            this.txtCylinderOilCons = new System.Windows.Forms.TextBox();
            this.lblRelHumidity = new System.Windows.Forms.Label();
            this.txtRelHumidity = new System.Windows.Forms.TextBox();
            this.lblTotalEngineHours = new System.Windows.Forms.Label();
            this.txtTotalEngineHours = new System.Windows.Forms.TextBox();
            this.lblEngineNoLogBook = new System.Windows.Forms.Label();
            this.txtNoOfCyl = new System.Windows.Forms.TextBox();
            this.btnAddNewDate = new System.Windows.Forms.Button();
            this.btnSaveData = new System.Windows.Forms.Button();
            this.dgvCylinderData = new System.Windows.Forms.DataGridView();
            this.lblNoOfCylinders = new System.Windows.Forms.Label();
            this.lblPortSea = new System.Windows.Forms.Label();
            this.cmbPortSea = new System.Windows.Forms.ComboBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.dtDateOfReading = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLinkSetting = new System.Windows.Forms.LinkLabel();
            this.pnlSettingLabel = new System.Windows.Forms.Panel();
            this.pnlLubeMonInfo = new System.Windows.Forms.Panel();
            this.lblLubeMonInfo = new System.Windows.Forms.LinkLabel();
            this.label20 = new System.Windows.Forms.Label();
            this.pnlContactUs = new System.Windows.Forms.Panel();
            this.lnkContactUs = new System.Windows.Forms.LinkLabel();
            this.imgHeader = new System.Windows.Forms.PictureBox();
            this.pnlTandC = new System.Windows.Forms.Panel();
            this.lnkTandC = new System.Windows.Forms.LinkLabel();
            this.lblMarineConnect = new System.Windows.Forms.Label();
            this.imgShellMarine = new System.Windows.Forms.PictureBox();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.tsMLBToolStrip.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlProgramInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgOtherProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgAlexia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgOilAnalysis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubeMonitorPgm)).BeginInit();
            this.pnlCylinderDrainOil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgOnBoardUserGuide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgUserGuide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgOnboardBroch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBrochure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubricantsLeaflet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubMonUserGuide)).BeginInit();
            this.pnlOtherProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgProducts)).BeginInit();
            this.pnlAlexia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3TDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3MSDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3Brochure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img50TDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img50MSDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS4TDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS4MSDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS6TDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS6MSDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgAlexiaBroch)).BeginInit();
            this.pnlLubeMonitorBroch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imbLubeMonitorBroch)).BeginInit();
            this.pnlTermsAndConditions.SuspendLayout();
            this.pnlHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgHome)).BeginInit();
            this.pnlEngine2.SuspendLayout();
            this.pnlEngineInfo.SuspendLayout();
            this.pnlDataSubmission.SuspendLayout();
            this.pnlSetting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjectData)).BeginInit();
            this.pnlConUs.SuspendLayout();
            this.pnlGraph.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chBNData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chCylinderData)).BeginInit();
            this.pnlSupportInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLinearWear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRunningHour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBunkerInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCylInpsection)).BeginInit();
            this.pnlSupportHistory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupportHistReadOnly)).BeginInit();
            this.pnlHistory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReadOnlyHistory)).BeginInit();
            this.pnlLogBookInfo.SuspendLayout();
            this.pnlRunningData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCylinderData)).BeginInit();
            this.pnlSettingLabel.SuspendLayout();
            this.pnlLubeMonInfo.SuspendLayout();
            this.pnlContactUs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgShellMarine)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.tsMLBToolStrip);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(148, 255);
            this.toolStripContainer1.Location = new System.Drawing.Point(12, 102);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(148, 280);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // tsMLBToolStrip
            // 
            this.tsMLBToolStrip.AutoSize = false;
            this.tsMLBToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.tsMLBToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tstxtEngInfo,
            this.toolStripSeparator1,
            this.tsTxtLogBookDetail,
            this.toolStripSeparator2,
            this.tsTxtHistory,
            this.toolStripSeparator5,
            this.tsTxtSupport,
            this.toolStripSeparator6,
            this.tsTxtSupportHistory,
            this.toolStripSeparator3,
            this.tsTxtGraph,
            this.toolStripSeparator4,
            this.tsTxtDataSubmission,
            this.toolStripSeparator7,
            this.tsProgramInfo,
            this.toolStripSeparator8});
            this.tsMLBToolStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.tsMLBToolStrip.Location = new System.Drawing.Point(0, 0);
            this.tsMLBToolStrip.Name = "tsMLBToolStrip";
            this.tsMLBToolStrip.Size = new System.Drawing.Size(150, 243);
            this.tsMLBToolStrip.TabIndex = 0;
            this.tsMLBToolStrip.Text = "toolStrip1";
            // 
            // tstxtEngInfo
            // 
            this.tstxtEngInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tstxtEngInfo.Name = "tstxtEngInfo";
            this.tstxtEngInfo.ReadOnly = true;
            this.tstxtEngInfo.Size = new System.Drawing.Size(146, 23);
            this.tstxtEngInfo.Text = "Engine Information";
            this.tstxtEngInfo.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tstxtEngInfo.Click += new System.EventHandler(this.tstxtEngInfo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtLogBookDetail
            // 
            this.tsTxtLogBookDetail.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsTxtLogBookDetail.Name = "tsTxtLogBookDetail";
            this.tsTxtLogBookDetail.ReadOnly = true;
            this.tsTxtLogBookDetail.Size = new System.Drawing.Size(146, 23);
            this.tsTxtLogBookDetail.Text = "Logbook";
            this.tsTxtLogBookDetail.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tsTxtLogBookDetail.Click += new System.EventHandler(this.tsTxtLogBookDetail_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtHistory
            // 
            this.tsTxtHistory.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsTxtHistory.Name = "tsTxtHistory";
            this.tsTxtHistory.ReadOnly = true;
            this.tsTxtHistory.Size = new System.Drawing.Size(146, 23);
            this.tsTxtHistory.Text = "Logbook Summary";
            this.tsTxtHistory.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtSupport
            // 
            this.tsTxtSupport.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsTxtSupport.Name = "tsTxtSupport";
            this.tsTxtSupport.ReadOnly = true;
            this.tsTxtSupport.Size = new System.Drawing.Size(146, 23);
            this.tsTxtSupport.Text = "Support Information";
            this.tsTxtSupport.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tsTxtSupport.Click += new System.EventHandler(this.tsTxtSupport_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtSupportHistory
            // 
            this.tsTxtSupportHistory.Name = "tsTxtSupportHistory";
            this.tsTxtSupportHistory.Size = new System.Drawing.Size(146, 23);
            this.tsTxtSupportHistory.Text = "Support Info Summary";
            this.tsTxtSupportHistory.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtGraph
            // 
            this.tsTxtGraph.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsTxtGraph.Name = "tsTxtGraph";
            this.tsTxtGraph.ReadOnly = true;
            this.tsTxtGraph.Size = new System.Drawing.Size(146, 23);
            this.tsTxtGraph.Text = "Graph";
            this.tsTxtGraph.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tsTxtGraph.Click += new System.EventHandler(this.tsTxtGraph_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(148, 6);
            // 
            // tsTxtDataSubmission
            // 
            this.tsTxtDataSubmission.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsTxtDataSubmission.Name = "tsTxtDataSubmission";
            this.tsTxtDataSubmission.ReadOnly = true;
            this.tsTxtDataSubmission.Size = new System.Drawing.Size(146, 23);
            this.tsTxtDataSubmission.Text = "Data Submission";
            this.tsTxtDataSubmission.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tsTxtDataSubmission.Click += new System.EventHandler(this.tsTxtDataSubmission_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(148, 6);
            // 
            // tsProgramInfo
            // 
            this.tsProgramInfo.Name = "tsProgramInfo";
            this.tsProgramInfo.Size = new System.Drawing.Size(146, 23);
            this.tsProgramInfo.Text = "Program Info";
            this.tsProgramInfo.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tsProgramInfo.Click += new System.EventHandler(this.tsProgramInfo_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(148, 6);
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.pnlProgramInfo);
            this.pnlMain.Controls.Add(this.pnlTermsAndConditions);
            this.pnlMain.Controls.Add(this.pnlHome);
            this.pnlMain.Controls.Add(this.pnlEngine2);
            this.pnlMain.Controls.Add(this.pnlEngineInfo);
            this.pnlMain.Controls.Add(this.pnlDataSubmission);
            this.pnlMain.Controls.Add(this.pnlSetting);
            this.pnlMain.Controls.Add(this.pnlConUs);
            this.pnlMain.Controls.Add(this.pnlGraph);
            this.pnlMain.Controls.Add(this.pnlSupportInfo);
            this.pnlMain.Controls.Add(this.pnlSupportHistory);
            this.pnlMain.Controls.Add(this.pnlHistory);
            this.pnlMain.Controls.Add(this.pnlLogBookInfo);
            this.pnlMain.Location = new System.Drawing.Point(166, 102);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(956, 455);
            this.pnlMain.TabIndex = 1;
            this.pnlMain.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMain_Paint);
            // 
            // pnlProgramInfo
            // 
            this.pnlProgramInfo.Controls.Add(this.imgOtherProducts);
            this.pnlProgramInfo.Controls.Add(this.imgAlexia);
            this.pnlProgramInfo.Controls.Add(this.imgOilAnalysis);
            this.pnlProgramInfo.Controls.Add(this.imgLubeMonitorPgm);
            this.pnlProgramInfo.Controls.Add(this.pnlOtherProducts);
            this.pnlProgramInfo.Controls.Add(this.pnlAlexia);
            this.pnlProgramInfo.Controls.Add(this.pnlLubeMonitorBroch);
            this.pnlProgramInfo.Controls.Add(this.pnlCylinderDrainOil);
            this.pnlProgramInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlProgramInfo.Name = "pnlProgramInfo";
            this.pnlProgramInfo.Size = new System.Drawing.Size(950, 445);
            this.pnlProgramInfo.TabIndex = 1;
            // 
            // imgOtherProducts
            // 
            this.imgOtherProducts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgOtherProducts.Location = new System.Drawing.Point(35, 336);
            this.imgOtherProducts.Name = "imgOtherProducts";
            this.imgOtherProducts.Size = new System.Drawing.Size(260, 104);
            this.imgOtherProducts.TabIndex = 3;
            this.imgOtherProducts.TabStop = false;
            this.imgOtherProducts.Click += new System.EventHandler(this.imgOtherProducts_Click);
            // 
            // imgAlexia
            // 
            this.imgAlexia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgAlexia.Location = new System.Drawing.Point(35, 226);
            this.imgAlexia.Name = "imgAlexia";
            this.imgAlexia.Size = new System.Drawing.Size(260, 104);
            this.imgAlexia.TabIndex = 2;
            this.imgAlexia.TabStop = false;
            this.imgAlexia.Click += new System.EventHandler(this.imgAlexia_Click);
            // 
            // imgOilAnalysis
            // 
            this.imgOilAnalysis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgOilAnalysis.Location = new System.Drawing.Point(35, 117);
            this.imgOilAnalysis.Name = "imgOilAnalysis";
            this.imgOilAnalysis.Size = new System.Drawing.Size(260, 104);
            this.imgOilAnalysis.TabIndex = 1;
            this.imgOilAnalysis.TabStop = false;
            this.imgOilAnalysis.Click += new System.EventHandler(this.imgOilAnalysis_Click);
            // 
            // imgLubeMonitorPgm
            // 
            this.imgLubeMonitorPgm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgLubeMonitorPgm.Location = new System.Drawing.Point(35, 9);
            this.imgLubeMonitorPgm.Name = "imgLubeMonitorPgm";
            this.imgLubeMonitorPgm.Size = new System.Drawing.Size(260, 104);
            this.imgLubeMonitorPgm.TabIndex = 0;
            this.imgLubeMonitorPgm.TabStop = false;
            this.imgLubeMonitorPgm.Click += new System.EventHandler(this.imgLubeMonitorPgm_Click);
            // 
            // pnlCylinderDrainOil
            // 
            this.pnlCylinderDrainOil.Controls.Add(this.lblCylinderDrain);
            this.pnlCylinderDrainOil.Controls.Add(this.imgOnBoardUserGuide);
            this.pnlCylinderDrainOil.Controls.Add(this.imgUserGuide);
            this.pnlCylinderDrainOil.Controls.Add(this.imgOnboardBroch);
            this.pnlCylinderDrainOil.Controls.Add(this.imgBrochure);
            this.pnlCylinderDrainOil.Controls.Add(this.imgLubricantsLeaflet);
            this.pnlCylinderDrainOil.Controls.Add(this.imgLubMonUserGuide);
            this.pnlCylinderDrainOil.Location = new System.Drawing.Point(299, 5);
            this.pnlCylinderDrainOil.Name = "pnlCylinderDrainOil";
            this.pnlCylinderDrainOil.Size = new System.Drawing.Size(640, 437);
            this.pnlCylinderDrainOil.TabIndex = 5;
            // 
            // lblCylinderDrain
            // 
            this.lblCylinderDrain.AutoSize = true;
            this.lblCylinderDrain.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblCylinderDrain.Location = new System.Drawing.Point(4, 8);
            this.lblCylinderDrain.Name = "lblCylinderDrain";
            this.lblCylinderDrain.Size = new System.Drawing.Size(128, 13);
            this.lblCylinderDrain.TabIndex = 7;
            this.lblCylinderDrain.Text = "Cylinder Drain Oil Analysis";
            // 
            // imgOnBoardUserGuide
            // 
            this.imgOnBoardUserGuide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgOnBoardUserGuide.Location = new System.Drawing.Point(322, 255);
            this.imgOnBoardUserGuide.Name = "imgOnBoardUserGuide";
            this.imgOnBoardUserGuide.Size = new System.Drawing.Size(305, 114);
            this.imgOnBoardUserGuide.TabIndex = 6;
            this.imgOnBoardUserGuide.TabStop = false;
            this.imgOnBoardUserGuide.Click += new System.EventHandler(this.imgOnBoardUserGuide_Click);
            // 
            // imgUserGuide
            // 
            this.imgUserGuide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgUserGuide.Location = new System.Drawing.Point(323, 209);
            this.imgUserGuide.Name = "imgUserGuide";
            this.imgUserGuide.Size = new System.Drawing.Size(306, 41);
            this.imgUserGuide.TabIndex = 5;
            this.imgUserGuide.TabStop = false;
            this.imgUserGuide.Click += new System.EventHandler(this.imgUserGuide_Click);
            // 
            // imgOnboardBroch
            // 
            this.imgOnboardBroch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgOnboardBroch.Location = new System.Drawing.Point(322, 91);
            this.imgOnboardBroch.Name = "imgOnboardBroch";
            this.imgOnboardBroch.Size = new System.Drawing.Size(305, 114);
            this.imgOnboardBroch.TabIndex = 4;
            this.imgOnboardBroch.TabStop = false;
            this.imgOnboardBroch.Click += new System.EventHandler(this.imgOnboardBroch_Click);
            // 
            // imgBrochure
            // 
            this.imgBrochure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgBrochure.Location = new System.Drawing.Point(5, 311);
            this.imgBrochure.Name = "imgBrochure";
            this.imgBrochure.Size = new System.Drawing.Size(305, 41);
            this.imgBrochure.TabIndex = 3;
            this.imgBrochure.TabStop = false;
            this.imgBrochure.Click += new System.EventHandler(this.imgBrochure_Click);
            // 
            // imgLubricantsLeaflet
            // 
            this.imgLubricantsLeaflet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgLubricantsLeaflet.Location = new System.Drawing.Point(5, 191);
            this.imgLubricantsLeaflet.Name = "imgLubricantsLeaflet";
            this.imgLubricantsLeaflet.Size = new System.Drawing.Size(305, 115);
            this.imgLubricantsLeaflet.TabIndex = 1;
            this.imgLubricantsLeaflet.TabStop = false;
            this.imgLubricantsLeaflet.Click += new System.EventHandler(this.imgLubricantsLeaflet_Click);
            // 
            // imgLubMonUserGuide
            // 
            this.imgLubMonUserGuide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgLubMonUserGuide.Location = new System.Drawing.Point(5, 103);
            this.imgLubMonUserGuide.Name = "imgLubMonUserGuide";
            this.imgLubMonUserGuide.Size = new System.Drawing.Size(305, 82);
            this.imgLubMonUserGuide.TabIndex = 0;
            this.imgLubMonUserGuide.TabStop = false;
            this.imgLubMonUserGuide.Click += new System.EventHandler(this.imgLubMonUserGuide_Click);
            // 
            // pnlOtherProducts
            // 
            this.pnlOtherProducts.Controls.Add(this.lblProducts);
            this.pnlOtherProducts.Controls.Add(this.imgProducts);
            this.pnlOtherProducts.Location = new System.Drawing.Point(301, 9);
            this.pnlOtherProducts.Name = "pnlOtherProducts";
            this.pnlOtherProducts.Size = new System.Drawing.Size(523, 289);
            this.pnlOtherProducts.TabIndex = 10;
            // 
            // lblProducts
            // 
            this.lblProducts.AutoSize = true;
            this.lblProducts.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblProducts.Location = new System.Drawing.Point(8, 6);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(143, 13);
            this.lblProducts.TabIndex = 12;
            this.lblProducts.Text = "Other Products and Services";
            // 
            // imgProducts
            // 
            this.imgProducts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgProducts.Location = new System.Drawing.Point(336, 170);
            this.imgProducts.Name = "imgProducts";
            this.imgProducts.Size = new System.Drawing.Size(187, 80);
            this.imgProducts.TabIndex = 11;
            this.imgProducts.TabStop = false;
            this.imgProducts.Click += new System.EventHandler(this.imgProducts_Click);
            // 
            // pnlAlexia
            // 
            this.pnlAlexia.Controls.Add(this.lblAlexia);
            this.pnlAlexia.Controls.Add(this.imgS3TDS);
            this.pnlAlexia.Controls.Add(this.imgS3MSDS);
            this.pnlAlexia.Controls.Add(this.imgS3Brochure);
            this.pnlAlexia.Controls.Add(this.img50TDS);
            this.pnlAlexia.Controls.Add(this.img50MSDS);
            this.pnlAlexia.Controls.Add(this.imgS4TDS);
            this.pnlAlexia.Controls.Add(this.imgS4MSDS);
            this.pnlAlexia.Controls.Add(this.imgS6TDS);
            this.pnlAlexia.Controls.Add(this.imgS6MSDS);
            this.pnlAlexia.Controls.Add(this.imgAlexiaBroch);
            this.pnlAlexia.Location = new System.Drawing.Point(299, 8);
            this.pnlAlexia.Name = "pnlAlexia";
            this.pnlAlexia.Size = new System.Drawing.Size(630, 423);
            this.pnlAlexia.TabIndex = 1;
            // 
            // lblAlexia
            // 
            this.lblAlexia.AutoSize = true;
            this.lblAlexia.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblAlexia.Location = new System.Drawing.Point(10, 8);
            this.lblAlexia.Name = "lblAlexia";
            this.lblAlexia.Size = new System.Drawing.Size(132, 13);
            this.lblAlexia.TabIndex = 10;
            this.lblAlexia.Text = "SHELL Alexia Cylinder Oils";
            // 
            // imgS3TDS
            // 
            this.imgS3TDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS3TDS.Location = new System.Drawing.Point(330, 380);
            this.imgS3TDS.Name = "imgS3TDS";
            this.imgS3TDS.Size = new System.Drawing.Size(187, 40);
            this.imgS3TDS.TabIndex = 9;
            this.imgS3TDS.TabStop = false;
            this.imgS3TDS.Click += new System.EventHandler(this.imgS3TDS_Click);
            // 
            // imgS3MSDS
            // 
            this.imgS3MSDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS3MSDS.Location = new System.Drawing.Point(330, 336);
            this.imgS3MSDS.Name = "imgS3MSDS";
            this.imgS3MSDS.Size = new System.Drawing.Size(187, 40);
            this.imgS3MSDS.TabIndex = 8;
            this.imgS3MSDS.TabStop = false;
            this.imgS3MSDS.Click += new System.EventHandler(this.imgS3MSDS_Click);
            // 
            // imgS3Brochure
            // 
            this.imgS3Brochure.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS3Brochure.Location = new System.Drawing.Point(330, 251);
            this.imgS3Brochure.Name = "imgS3Brochure";
            this.imgS3Brochure.Size = new System.Drawing.Size(187, 80);
            this.imgS3Brochure.TabIndex = 7;
            this.imgS3Brochure.TabStop = false;
            this.imgS3Brochure.Click += new System.EventHandler(this.imgS3Brochure_Click);
            // 
            // img50TDS
            // 
            this.img50TDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.img50TDS.Location = new System.Drawing.Point(331, 205);
            this.img50TDS.Name = "img50TDS";
            this.img50TDS.Size = new System.Drawing.Size(187, 40);
            this.img50TDS.TabIndex = 6;
            this.img50TDS.TabStop = false;
            this.img50TDS.Click += new System.EventHandler(this.img50TDS_Click);
            // 
            // img50MSDS
            // 
            this.img50MSDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.img50MSDS.Location = new System.Drawing.Point(331, 121);
            this.img50MSDS.Name = "img50MSDS";
            this.img50MSDS.Size = new System.Drawing.Size(187, 80);
            this.img50MSDS.TabIndex = 5;
            this.img50MSDS.TabStop = false;
            this.img50MSDS.Click += new System.EventHandler(this.img50MSDS_Click);
            // 
            // imgS4TDS
            // 
            this.imgS4TDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS4TDS.Location = new System.Drawing.Point(100, 336);
            this.imgS4TDS.Name = "imgS4TDS";
            this.imgS4TDS.Size = new System.Drawing.Size(187, 40);
            this.imgS4TDS.TabIndex = 4;
            this.imgS4TDS.TabStop = false;
            this.imgS4TDS.Click += new System.EventHandler(this.imgS4TDS_Click);
            // 
            // imgS4MSDS
            // 
            this.imgS4MSDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS4MSDS.Location = new System.Drawing.Point(100, 251);
            this.imgS4MSDS.Name = "imgS4MSDS";
            this.imgS4MSDS.Size = new System.Drawing.Size(187, 80);
            this.imgS4MSDS.TabIndex = 3;
            this.imgS4MSDS.TabStop = false;
            this.imgS4MSDS.Click += new System.EventHandler(this.imgS4MSDS_Click);
            // 
            // imgS6TDS
            // 
            this.imgS6TDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS6TDS.Location = new System.Drawing.Point(100, 205);
            this.imgS6TDS.Name = "imgS6TDS";
            this.imgS6TDS.Size = new System.Drawing.Size(187, 40);
            this.imgS6TDS.TabIndex = 2;
            this.imgS6TDS.TabStop = false;
            this.imgS6TDS.Click += new System.EventHandler(this.imgS6TDS_Click);
            // 
            // imgS6MSDS
            // 
            this.imgS6MSDS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgS6MSDS.Location = new System.Drawing.Point(100, 120);
            this.imgS6MSDS.Name = "imgS6MSDS";
            this.imgS6MSDS.Size = new System.Drawing.Size(187, 80);
            this.imgS6MSDS.TabIndex = 1;
            this.imgS6MSDS.TabStop = false;
            this.imgS6MSDS.Click += new System.EventHandler(this.imgS6MSDS_Click);
            // 
            // imgAlexiaBroch
            // 
            this.imgAlexiaBroch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgAlexiaBroch.Location = new System.Drawing.Point(213, 39);
            this.imgAlexiaBroch.Name = "imgAlexiaBroch";
            this.imgAlexiaBroch.Size = new System.Drawing.Size(305, 73);
            this.imgAlexiaBroch.TabIndex = 0;
            this.imgAlexiaBroch.TabStop = false;
            this.imgAlexiaBroch.Click += new System.EventHandler(this.imgAlexiaBroch_Click);
            // 
            // pnlLubeMonitorBroch
            // 
            this.pnlLubeMonitorBroch.Controls.Add(this.lblPgmOverview);
            this.pnlLubeMonitorBroch.Controls.Add(this.imbLubeMonitorBroch);
            this.pnlLubeMonitorBroch.Location = new System.Drawing.Point(299, 6);
            this.pnlLubeMonitorBroch.Name = "pnlLubeMonitorBroch";
            this.pnlLubeMonitorBroch.Size = new System.Drawing.Size(564, 271);
            this.pnlLubeMonitorBroch.TabIndex = 4;
            // 
            // lblPgmOverview
            // 
            this.lblPgmOverview.AutoSize = true;
            this.lblPgmOverview.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblPgmOverview.Location = new System.Drawing.Point(5, 7);
            this.lblPgmOverview.Name = "lblPgmOverview";
            this.lblPgmOverview.Size = new System.Drawing.Size(94, 13);
            this.lblPgmOverview.TabIndex = 1;
            this.lblPgmOverview.Text = "Program Overview";
            // 
            // imbLubeMonitorBroch
            // 
            this.imbLubeMonitorBroch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imbLubeMonitorBroch.Location = new System.Drawing.Point(288, 137);
            this.imbLubeMonitorBroch.Name = "imbLubeMonitorBroch";
            this.imbLubeMonitorBroch.Size = new System.Drawing.Size(276, 110);
            this.imbLubeMonitorBroch.TabIndex = 0;
            this.imbLubeMonitorBroch.TabStop = false;
            this.imbLubeMonitorBroch.Click += new System.EventHandler(this.imbLubeMonitorBroch_Click);
            // 
            // pnlTermsAndConditions
            // 
            this.pnlTermsAndConditions.Controls.Add(this.lblTandC);
            this.pnlTermsAndConditions.Location = new System.Drawing.Point(4, 4);
            this.pnlTermsAndConditions.Name = "pnlTermsAndConditions";
            this.pnlTermsAndConditions.Size = new System.Drawing.Size(950, 445);
            this.pnlTermsAndConditions.TabIndex = 101;
            // 
            // lblTandC
            // 
            this.lblTandC.AutoSize = true;
            this.lblTandC.Location = new System.Drawing.Point(26, 18);
            this.lblTandC.Name = "lblTandC";
            this.lblTandC.Size = new System.Drawing.Size(109, 13);
            this.lblTandC.TabIndex = 0;
            this.lblTandC.Text = "Terms and Conditions";
            // 
            // pnlHome
            // 
            this.pnlHome.Controls.Add(this.imgHome);
            this.pnlHome.Location = new System.Drawing.Point(3, 3);
            this.pnlHome.Name = "pnlHome";
            this.pnlHome.Size = new System.Drawing.Size(950, 445);
            this.pnlHome.TabIndex = 100;
            // 
            // imgHome
            // 
            this.imgHome.Location = new System.Drawing.Point(30, 5);
            this.imgHome.Name = "imgHome";
            this.imgHome.Size = new System.Drawing.Size(945, 445);
            this.imgHome.TabIndex = 0;
            this.imgHome.TabStop = false;
            // 
            // pnlEngine2
            // 
            this.pnlEngine2.Controls.Add(this.cmbEngManuf2);
            this.pnlEngine2.Controls.Add(this.label77);
            this.pnlEngine2.Controls.Add(this.label75);
            this.pnlEngine2.Controls.Add(this.label73);
            this.pnlEngine2.Controls.Add(this.label71);
            this.pnlEngine2.Controls.Add(this.label17);
            this.pnlEngine2.Controls.Add(this.lblSecondEngine);
            this.pnlEngine2.Controls.Add(this.label67);
            this.pnlEngine2.Controls.Add(this.btnFirstEngine);
            this.pnlEngine2.Controls.Add(this.btnSaveEngine2);
            this.pnlEngine2.Controls.Add(this.label42);
            this.pnlEngine2.Controls.Add(this.label43);
            this.pnlEngine2.Controls.Add(this.label44);
            this.pnlEngine2.Controls.Add(this.label45);
            this.pnlEngine2.Controls.Add(this.label46);
            this.pnlEngine2.Controls.Add(this.cmbPistonCleaningRing2);
            this.pnlEngine2.Controls.Add(this.label47);
            this.pnlEngine2.Controls.Add(this.cmbTCCutOutAvail2);
            this.pnlEngine2.Controls.Add(this.label48);
            this.pnlEngine2.Controls.Add(this.txtNoOfTC2);
            this.pnlEngine2.Controls.Add(this.label51);
            this.pnlEngine2.Controls.Add(this.txtTargetFeedRate2);
            this.pnlEngine2.Controls.Add(this.label52);
            this.pnlEngine2.Controls.Add(this.txtMinFeedRate2);
            this.pnlEngine2.Controls.Add(this.label53);
            this.pnlEngine2.Controls.Add(this.txtCurrentFeedRate2);
            this.pnlEngine2.Controls.Add(this.label54);
            this.pnlEngine2.Controls.Add(this.txtLubType2);
            this.pnlEngine2.Controls.Add(this.label55);
            this.pnlEngine2.Controls.Add(this.txtMCR2);
            this.pnlEngine2.Controls.Add(this.label56);
            this.pnlEngine2.Controls.Add(this.label57);
            this.pnlEngine2.Controls.Add(this.txtRPM2);
            this.pnlEngine2.Controls.Add(this.txtMainEngNo2);
            this.pnlEngine2.Controls.Add(this.label58);
            this.pnlEngine2.Controls.Add(this.txtMainEngSerialNo2);
            this.pnlEngine2.Controls.Add(this.label59);
            this.pnlEngine2.Controls.Add(this.txtMainEngLoc2);
            this.pnlEngine2.Controls.Add(this.label60);
            this.pnlEngine2.Controls.Add(this.label61);
            this.pnlEngine2.Controls.Add(this.txtMainEngType2);
            this.pnlEngine2.Controls.Add(this.label62);
            this.pnlEngine2.Controls.Add(this.dtpDateDelivered2);
            this.pnlEngine2.Controls.Add(this.label63);
            this.pnlEngine2.Controls.Add(this.txtVesselId2);
            this.pnlEngine2.Controls.Add(this.label64);
            this.pnlEngine2.Controls.Add(this.txtIMONo2);
            this.pnlEngine2.Controls.Add(this.label65);
            this.pnlEngine2.Controls.Add(this.txtVesselName2);
            this.pnlEngine2.Controls.Add(this.label66);
            this.pnlEngine2.Location = new System.Drawing.Point(3, 3);
            this.pnlEngine2.Name = "pnlEngine2";
            this.pnlEngine2.Size = new System.Drawing.Size(950, 445);
            this.pnlEngine2.TabIndex = 100;
            // 
            // cmbEngManuf2
            // 
            this.cmbEngManuf2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEngManuf2.FormattingEnabled = true;
            this.cmbEngManuf2.Items.AddRange(new object[] {
            "--Select--",
            "Wartsila",
            "MAN B&W",
            "Mitsubishi Diesel"});
            this.cmbEngManuf2.Location = new System.Drawing.Point(127, 90);
            this.cmbEngManuf2.Name = "cmbEngManuf2";
            this.cmbEngManuf2.Size = new System.Drawing.Size(300, 21);
            this.cmbEngManuf2.TabIndex = 258;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.ForeColor = System.Drawing.Color.Red;
            this.label77.Location = new System.Drawing.Point(433, 32);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(11, 13);
            this.label77.TabIndex = 257;
            this.label77.Text = "*";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.ForeColor = System.Drawing.Color.Red;
            this.label75.Location = new System.Drawing.Point(923, 331);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(11, 13);
            this.label75.TabIndex = 256;
            this.label75.Text = "*";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.ForeColor = System.Drawing.Color.Red;
            this.label73.Location = new System.Drawing.Point(923, 246);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(11, 13);
            this.label73.TabIndex = 254;
            this.label73.Text = "*";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.ForeColor = System.Drawing.Color.Red;
            this.label71.Location = new System.Drawing.Point(923, 134);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(11, 13);
            this.label71.TabIndex = 252;
            this.label71.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(923, 174);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(11, 13);
            this.label17.TabIndex = 251;
            this.label17.Text = "*";
            // 
            // lblSecondEngine
            // 
            this.lblSecondEngine.AutoSize = true;
            this.lblSecondEngine.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondEngine.Location = new System.Drawing.Point(13, 1);
            this.lblSecondEngine.Name = "lblSecondEngine";
            this.lblSecondEngine.Size = new System.Drawing.Size(68, 18);
            this.lblSecondEngine.TabIndex = 149;
            this.lblSecondEngine.Text = "label71";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.ForeColor = System.Drawing.Color.Red;
            this.label67.Location = new System.Drawing.Point(745, 2);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(171, 13);
            this.label67.TabIndex = 148;
            this.label67.Text = "Fields marked with * are mandatory";
            // 
            // btnFirstEngine
            // 
            this.btnFirstEngine.BackColor = System.Drawing.Color.Red;
            this.btnFirstEngine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFirstEngine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirstEngine.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFirstEngine.Location = new System.Drawing.Point(712, 396);
            this.btnFirstEngine.Name = "btnFirstEngine";
            this.btnFirstEngine.Size = new System.Drawing.Size(122, 23);
            this.btnFirstEngine.TabIndex = 221;
            this.btnFirstEngine.Text = "First Engine";
            this.btnFirstEngine.UseVisualStyleBackColor = false;
            this.btnFirstEngine.Click += new System.EventHandler(this.btnFirstEngine_Click);
            // 
            // btnSaveEngine2
            // 
            this.btnSaveEngine2.BackColor = System.Drawing.Color.Red;
            this.btnSaveEngine2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveEngine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEngine2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveEngine2.Location = new System.Drawing.Point(620, 396);
            this.btnSaveEngine2.Name = "btnSaveEngine2";
            this.btnSaveEngine2.Size = new System.Drawing.Size(75, 23);
            this.btnSaveEngine2.TabIndex = 220;
            this.btnSaveEngine2.Text = "Save";
            this.btnSaveEngine2.UseVisualStyleBackColor = false;
            this.btnSaveEngine2.Click += new System.EventHandler(this.btnSaveEngine2_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(433, 330);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(11, 13);
            this.label42.TabIndex = 144;
            this.label42.Text = "*";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(433, 292);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(11, 13);
            this.label43.TabIndex = 143;
            this.label43.Text = "*";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(433, 173);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(11, 13);
            this.label44.TabIndex = 142;
            this.label44.Text = "*";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.ForeColor = System.Drawing.Color.Red;
            this.label45.Location = new System.Drawing.Point(433, 208);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(11, 13);
            this.label45.TabIndex = 141;
            this.label45.Text = "*";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.ForeColor = System.Drawing.Color.Red;
            this.label46.Location = new System.Drawing.Point(433, 63);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(11, 13);
            this.label46.TabIndex = 140;
            this.label46.Text = "*";
            // 
            // cmbPistonCleaningRing2
            // 
            this.cmbPistonCleaningRing2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPistonCleaningRing2.FormattingEnabled = true;
            this.cmbPistonCleaningRing2.Items.AddRange(new object[] {
            "--Select--",
            "Yes",
            "No"});
            this.cmbPistonCleaningRing2.Location = new System.Drawing.Point(620, 322);
            this.cmbPistonCleaningRing2.Name = "cmbPistonCleaningRing2";
            this.cmbPistonCleaningRing2.Size = new System.Drawing.Size(300, 21);
            this.cmbPistonCleaningRing2.TabIndex = 219;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(499, 327);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(105, 13);
            this.label47.TabIndex = 138;
            this.label47.Text = "Piston Cleaning Ring";
            // 
            // cmbTCCutOutAvail2
            // 
            this.cmbTCCutOutAvail2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTCCutOutAvail2.FormattingEnabled = true;
            this.cmbTCCutOutAvail2.Items.AddRange(new object[] {
            "--Select--",
            "Yes",
            "No"});
            this.cmbTCCutOutAvail2.Location = new System.Drawing.Point(129, 322);
            this.cmbTCCutOutAvail2.Name = "cmbTCCutOutAvail2";
            this.cmbTCCutOutAvail2.Size = new System.Drawing.Size(298, 21);
            this.cmbTCCutOutAvail2.TabIndex = 218;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(19, 319);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(87, 26);
            this.label48.TabIndex = 136;
            this.label48.Text = "     Turbocharger\r\nCut-out Available";
            // 
            // txtNoOfTC2
            // 
            this.txtNoOfTC2.Location = new System.Drawing.Point(127, 285);
            this.txtNoOfTC2.Name = "txtNoOfTC2";
            this.txtNoOfTC2.Size = new System.Drawing.Size(300, 20);
            this.txtNoOfTC2.TabIndex = 215;
            this.txtNoOfTC2.Validating += new System.ComponentModel.CancelEventHandler(this.txtNoOfTC2_Validating);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(31, 283);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(76, 26);
            this.label51.TabIndex = 130;
            this.label51.Text = "          No. Of \r\nTurbochargers";
            // 
            // txtTargetFeedRate2
            // 
            this.txtTargetFeedRate2.Location = new System.Drawing.Point(620, 285);
            this.txtTargetFeedRate2.Name = "txtTargetFeedRate2";
            this.txtTargetFeedRate2.Size = new System.Drawing.Size(300, 20);
            this.txtTargetFeedRate2.TabIndex = 216;
            this.txtTargetFeedRate2.Validating += new System.ComponentModel.CancelEventHandler(this.txtTargetFeedRate2_Validating);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(538, 281);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(70, 39);
            this.label52.TabIndex = 128;
            this.label52.Text = " Target Feed\r\nRate, g/kWh\t\t\r\n\t\t\r\n";
            // 
            // txtMinFeedRate2
            // 
            this.txtMinFeedRate2.Location = new System.Drawing.Point(127, 242);
            this.txtMinFeedRate2.Name = "txtMinFeedRate2";
            this.txtMinFeedRate2.Size = new System.Drawing.Size(300, 20);
            this.txtMinFeedRate2.TabIndex = 213;
            this.txtMinFeedRate2.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinFeedRate2_Validating);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(1, 236);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(110, 26);
            this.label53.TabIndex = 126;
            this.label53.Text = "    Min Feed Rate by \r\nManufacturer, g/kWh";
            // 
            // txtCurrentFeedRate2
            // 
            this.txtCurrentFeedRate2.Location = new System.Drawing.Point(620, 240);
            this.txtCurrentFeedRate2.Name = "txtCurrentFeedRate2";
            this.txtCurrentFeedRate2.Size = new System.Drawing.Size(300, 20);
            this.txtCurrentFeedRate2.TabIndex = 214;
            this.txtCurrentFeedRate2.Validating += new System.ComponentModel.CancelEventHandler(this.txtCurrentFeedRate2_Validating);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(533, 239);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(73, 26);
            this.label54.TabIndex = 124;
            this.label54.Text = "Current Feed\r\nRate,  g/kWh";
            // 
            // txtLubType2
            // 
            this.txtLubType2.Location = new System.Drawing.Point(620, 202);
            this.txtLubType2.Name = "txtLubType2";
            this.txtLubType2.Size = new System.Drawing.Size(300, 20);
            this.txtLubType2.TabIndex = 212;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(520, 204);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(81, 13);
            this.label55.TabIndex = 122;
            this.label55.Text = "Lubricator Type";
            // 
            // txtMCR2
            // 
            this.txtMCR2.Location = new System.Drawing.Point(620, 165);
            this.txtMCR2.Name = "txtMCR2";
            this.txtMCR2.Size = new System.Drawing.Size(300, 20);
            this.txtMCR2.TabIndex = 210;
            this.txtMCR2.Validating += new System.ComponentModel.CancelEventHandler(this.txtMCR2_Validating);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(547, 174);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(54, 13);
            this.label56.TabIndex = 120;
            this.label56.Text = "MCR, kW";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(71, 201);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(34, 13);
            this.label57.TabIndex = 119;
            this.label57.Text = " RPM";
            // 
            // txtRPM2
            // 
            this.txtRPM2.Location = new System.Drawing.Point(127, 201);
            this.txtRPM2.Name = "txtRPM2";
            this.txtRPM2.Size = new System.Drawing.Size(300, 20);
            this.txtRPM2.TabIndex = 211;
            this.txtRPM2.Validating += new System.ComponentModel.CancelEventHandler(this.txtRPM2_Validating);
            // 
            // txtMainEngNo2
            // 
            this.txtMainEngNo2.Location = new System.Drawing.Point(127, 166);
            this.txtMainEngNo2.Name = "txtMainEngNo2";
            this.txtMainEngNo2.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngNo2.TabIndex = 209;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Verdana", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(22, 175);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(83, 12);
            this.label58.TabIndex = 116;
            this.label58.Text = "Main Engine No";
            // 
            // txtMainEngSerialNo2
            // 
            this.txtMainEngSerialNo2.Location = new System.Drawing.Point(127, 127);
            this.txtMainEngSerialNo2.Name = "txtMainEngSerialNo2";
            this.txtMainEngSerialNo2.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngSerialNo2.TabIndex = 207;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(57, 128);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(52, 26);
            this.label59.TabIndex = 114;
            this.label59.Text = "Main Eng\r\nSerial No";
            // 
            // txtMainEngLoc2
            // 
            this.txtMainEngLoc2.Location = new System.Drawing.Point(620, 127);
            this.txtMainEngLoc2.Name = "txtMainEngLoc2";
            this.txtMainEngLoc2.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngLoc2.TabIndex = 208;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(507, 130);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(96, 13);
            this.label60.TabIndex = 112;
            this.label60.Text = "Main Eng Location";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(37, 88);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(70, 26);
            this.label61.TabIndex = 110;
            this.label61.Text = "Main Engine\r\nManufacturer";
            // 
            // txtMainEngType2
            // 
            this.txtMainEngType2.Location = new System.Drawing.Point(620, 94);
            this.txtMainEngType2.Name = "txtMainEngType2";
            this.txtMainEngType2.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngType2.TabIndex = 206;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(511, 97);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(93, 13);
            this.label62.TabIndex = 108;
            this.label62.Text = "Main Engine Type";
            // 
            // dtpDateDelivered2
            // 
            this.dtpDateDelivered2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateDelivered2.Location = new System.Drawing.Point(620, 58);
            this.dtpDateDelivered2.Name = "dtpDateDelivered2";
            this.dtpDateDelivered2.Size = new System.Drawing.Size(99, 20);
            this.dtpDateDelivered2.TabIndex = 204;
            this.dtpDateDelivered2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpDateDelivered2_KeyDown);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(525, 59);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(78, 13);
            this.label63.TabIndex = 106;
            this.label63.Text = "Date Delivered";
            // 
            // txtVesselId2
            // 
            this.txtVesselId2.Location = new System.Drawing.Point(127, 56);
            this.txtVesselId2.Name = "txtVesselId2";
            this.txtVesselId2.Size = new System.Drawing.Size(300, 20);
            this.txtVesselId2.TabIndex = 203;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(38, 53);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(67, 26);
            this.label64.TabIndex = 104;
            this.label64.Text = "Vessel Id As\r\n         In RLA";
            // 
            // txtIMONo2
            // 
            this.txtIMONo2.Location = new System.Drawing.Point(620, 25);
            this.txtIMONo2.Name = "txtIMONo2";
            this.txtIMONo2.Size = new System.Drawing.Size(300, 20);
            this.txtIMONo2.TabIndex = 202;
            this.txtIMONo2.Validating += new System.ComponentModel.CancelEventHandler(this.txtIMONo2_Validating);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(536, 30);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(67, 13);
            this.label65.TabIndex = 102;
            this.label65.Text = "IMO Number";
            // 
            // txtVesselName2
            // 
            this.txtVesselName2.Location = new System.Drawing.Point(127, 25);
            this.txtVesselName2.Name = "txtVesselName2";
            this.txtVesselName2.Size = new System.Drawing.Size(300, 20);
            this.txtVesselName2.TabIndex = 201;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(42, 29);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(69, 13);
            this.label66.TabIndex = 100;
            this.label66.Text = "Vessel Name";
            // 
            // pnlEngineInfo
            // 
            this.pnlEngineInfo.Controls.Add(this.cmbEngManuf);
            this.pnlEngineInfo.Controls.Add(this.label78);
            this.pnlEngineInfo.Controls.Add(this.lblEngineNoFirstEng);
            this.pnlEngineInfo.Controls.Add(this.label68);
            this.pnlEngineInfo.Controls.Add(this.btnSecondEngine);
            this.pnlEngineInfo.Controls.Add(this.btnSaveEngineInfo);
            this.pnlEngineInfo.Controls.Add(this.label12);
            this.pnlEngineInfo.Controls.Add(this.label11);
            this.pnlEngineInfo.Controls.Add(this.label10);
            this.pnlEngineInfo.Controls.Add(this.label9);
            this.pnlEngineInfo.Controls.Add(this.label8);
            this.pnlEngineInfo.Controls.Add(this.label7);
            this.pnlEngineInfo.Controls.Add(this.label6);
            this.pnlEngineInfo.Controls.Add(this.label4);
            this.pnlEngineInfo.Controls.Add(this.label3);
            this.pnlEngineInfo.Controls.Add(this.cmbPistonCleaning);
            this.pnlEngineInfo.Controls.Add(this.lblPistonCleaning);
            this.pnlEngineInfo.Controls.Add(this.cmbTCCutavail);
            this.pnlEngineInfo.Controls.Add(this.lblTCCut);
            this.pnlEngineInfo.Controls.Add(this.txtNoOfTC);
            this.pnlEngineInfo.Controls.Add(this.lblNoOfTC);
            this.pnlEngineInfo.Controls.Add(this.txtTargetFeedRate);
            this.pnlEngineInfo.Controls.Add(this.lblTgtFeedRate);
            this.pnlEngineInfo.Controls.Add(this.txtMinFeedRate);
            this.pnlEngineInfo.Controls.Add(this.lblMinFeedRate);
            this.pnlEngineInfo.Controls.Add(this.txtCurrentFeedRate);
            this.pnlEngineInfo.Controls.Add(this.lblCurrentFeedRate);
            this.pnlEngineInfo.Controls.Add(this.txtLubType);
            this.pnlEngineInfo.Controls.Add(this.lblLubType);
            this.pnlEngineInfo.Controls.Add(this.txtMCR);
            this.pnlEngineInfo.Controls.Add(this.lblMCR);
            this.pnlEngineInfo.Controls.Add(this.lblRPM);
            this.pnlEngineInfo.Controls.Add(this.txtRPM);
            this.pnlEngineInfo.Controls.Add(this.txtMainEngNo);
            this.pnlEngineInfo.Controls.Add(this.lblEngNo);
            this.pnlEngineInfo.Controls.Add(this.txtMainEngSerialNo);
            this.pnlEngineInfo.Controls.Add(this.lblEngSerialNo);
            this.pnlEngineInfo.Controls.Add(this.txtMainEngLoc);
            this.pnlEngineInfo.Controls.Add(this.lblEngLoc);
            this.pnlEngineInfo.Controls.Add(this.lblEngManuf);
            this.pnlEngineInfo.Controls.Add(this.txtMainEngType);
            this.pnlEngineInfo.Controls.Add(this.lblEngType);
            this.pnlEngineInfo.Controls.Add(this.dtDateDelivered);
            this.pnlEngineInfo.Controls.Add(this.lblDateDelivered);
            this.pnlEngineInfo.Controls.Add(this.txtVesselId);
            this.pnlEngineInfo.Controls.Add(this.lblVesselId);
            this.pnlEngineInfo.Controls.Add(this.txtIMONo);
            this.pnlEngineInfo.Controls.Add(this.lblIMONo);
            this.pnlEngineInfo.Controls.Add(this.txtVesselName);
            this.pnlEngineInfo.Controls.Add(this.lblVesselName);
            this.pnlEngineInfo.Location = new System.Drawing.Point(3, 3);
            this.pnlEngineInfo.Name = "pnlEngineInfo";
            this.pnlEngineInfo.Size = new System.Drawing.Size(950, 445);
            this.pnlEngineInfo.TabIndex = 0;
            this.pnlEngineInfo.Visible = false;
            // 
            // cmbEngManuf
            // 
            this.cmbEngManuf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEngManuf.FormattingEnabled = true;
            this.cmbEngManuf.Items.AddRange(new object[] {
            "--Select--",
            "Wartsila",
            "MAN B&W",
            "Mitsubishi Diesel"});
            this.cmbEngManuf.Location = new System.Drawing.Point(129, 98);
            this.cmbEngManuf.Name = "cmbEngManuf";
            this.cmbEngManuf.Size = new System.Drawing.Size(300, 21);
            this.cmbEngManuf.TabIndex = 152;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.ForeColor = System.Drawing.Color.Red;
            this.label78.Location = new System.Drawing.Point(435, 42);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(11, 13);
            this.label78.TabIndex = 151;
            this.label78.Text = "*";
            // 
            // lblEngineNoFirstEng
            // 
            this.lblEngineNoFirstEng.AutoSize = true;
            this.lblEngineNoFirstEng.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineNoFirstEng.Location = new System.Drawing.Point(13, 1);
            this.lblEngineNoFirstEng.Name = "lblEngineNoFirstEng";
            this.lblEngineNoFirstEng.Size = new System.Drawing.Size(68, 18);
            this.lblEngineNoFirstEng.TabIndex = 150;
            this.lblEngineNoFirstEng.Text = "label71";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.ForeColor = System.Drawing.Color.Red;
            this.label68.Location = new System.Drawing.Point(745, 2);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(171, 13);
            this.label68.TabIndex = 149;
            this.label68.Text = "Fields marked with * are mandatory";
            // 
            // btnSecondEngine
            // 
            this.btnSecondEngine.BackColor = System.Drawing.Color.Red;
            this.btnSecondEngine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecondEngine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSecondEngine.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSecondEngine.Location = new System.Drawing.Point(710, 402);
            this.btnSecondEngine.Name = "btnSecondEngine";
            this.btnSecondEngine.Size = new System.Drawing.Size(107, 23);
            this.btnSecondEngine.TabIndex = 50;
            this.btnSecondEngine.Text = "Second Engine";
            this.btnSecondEngine.UseVisualStyleBackColor = false;
            this.btnSecondEngine.Click += new System.EventHandler(this.btnSecondEngine_Click);
            // 
            // btnSaveEngineInfo
            // 
            this.btnSaveEngineInfo.BackColor = System.Drawing.Color.Red;
            this.btnSaveEngineInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveEngineInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveEngineInfo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveEngineInfo.Location = new System.Drawing.Point(610, 403);
            this.btnSaveEngineInfo.Name = "btnSaveEngineInfo";
            this.btnSaveEngineInfo.Size = new System.Drawing.Size(75, 23);
            this.btnSaveEngineInfo.TabIndex = 49;
            this.btnSaveEngineInfo.Text = "Save";
            this.btnSaveEngineInfo.UseVisualStyleBackColor = false;
            this.btnSaveEngineInfo.Click += new System.EventHandler(this.btnSaveEngineInfo_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(435, 336);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 13);
            this.label12.TabIndex = 96;
            this.label12.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(916, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(11, 13);
            this.label11.TabIndex = 95;
            this.label11.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(435, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 13);
            this.label10.TabIndex = 94;
            this.label10.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(916, 252);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 13);
            this.label9.TabIndex = 93;
            this.label9.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(916, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 13);
            this.label8.TabIndex = 92;
            this.label8.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(435, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 13);
            this.label7.TabIndex = 91;
            this.label7.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(916, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 13);
            this.label6.TabIndex = 90;
            this.label6.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(435, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 13);
            this.label4.TabIndex = 88;
            this.label4.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(435, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 13);
            this.label3.TabIndex = 87;
            this.label3.Text = "*";
            // 
            // cmbPistonCleaning
            // 
            this.cmbPistonCleaning.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPistonCleaning.FormattingEnabled = true;
            this.cmbPistonCleaning.Items.AddRange(new object[] {
            "--Select--",
            "Yes",
            "No"});
            this.cmbPistonCleaning.Location = new System.Drawing.Point(610, 326);
            this.cmbPistonCleaning.Name = "cmbPistonCleaning";
            this.cmbPistonCleaning.Size = new System.Drawing.Size(300, 21);
            this.cmbPistonCleaning.TabIndex = 48;
            // 
            // lblPistonCleaning
            // 
            this.lblPistonCleaning.AutoSize = true;
            this.lblPistonCleaning.Location = new System.Drawing.Point(490, 329);
            this.lblPistonCleaning.Name = "lblPistonCleaning";
            this.lblPistonCleaning.Size = new System.Drawing.Size(105, 13);
            this.lblPistonCleaning.TabIndex = 85;
            this.lblPistonCleaning.Text = "Piston Cleaning Ring";
            // 
            // cmbTCCutavail
            // 
            this.cmbTCCutavail.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTCCutavail.FormattingEnabled = true;
            this.cmbTCCutavail.Items.AddRange(new object[] {
            "--Select--",
            "Yes",
            "No"});
            this.cmbTCCutavail.Location = new System.Drawing.Point(131, 328);
            this.cmbTCCutavail.Name = "cmbTCCutavail";
            this.cmbTCCutavail.Size = new System.Drawing.Size(298, 21);
            this.cmbTCCutavail.TabIndex = 47;
            // 
            // lblTCCut
            // 
            this.lblTCCut.AutoSize = true;
            this.lblTCCut.Location = new System.Drawing.Point(21, 324);
            this.lblTCCut.Name = "lblTCCut";
            this.lblTCCut.Size = new System.Drawing.Size(92, 26);
            this.lblTCCut.TabIndex = 83;
            this.lblTCCut.Text = "      Turbocharger \r\nCut-out Available";
            // 
            // txtNoOfTC
            // 
            this.txtNoOfTC.Location = new System.Drawing.Point(129, 292);
            this.txtNoOfTC.Name = "txtNoOfTC";
            this.txtNoOfTC.Size = new System.Drawing.Size(300, 20);
            this.txtNoOfTC.TabIndex = 44;
            this.txtNoOfTC.Validating += new System.ComponentModel.CancelEventHandler(this.txtNoOfTC_Validating);
            // 
            // lblNoOfTC
            // 
            this.lblNoOfTC.AutoSize = true;
            this.lblNoOfTC.Location = new System.Drawing.Point(32, 290);
            this.lblNoOfTC.Name = "lblNoOfTC";
            this.lblNoOfTC.Size = new System.Drawing.Size(77, 26);
            this.lblNoOfTC.TabIndex = 77;
            this.lblNoOfTC.Text = "            No. Of \r\nTurbochargers";
            // 
            // txtTargetFeedRate
            // 
            this.txtTargetFeedRate.Location = new System.Drawing.Point(610, 292);
            this.txtTargetFeedRate.Name = "txtTargetFeedRate";
            this.txtTargetFeedRate.Size = new System.Drawing.Size(300, 20);
            this.txtTargetFeedRate.TabIndex = 45;
            this.txtTargetFeedRate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTargetFeedRate_Validating);
            // 
            // lblTgtFeedRate
            // 
            this.lblTgtFeedRate.AutoSize = true;
            this.lblTgtFeedRate.Location = new System.Drawing.Point(496, 292);
            this.lblTgtFeedRate.Name = "lblTgtFeedRate";
            this.lblTgtFeedRate.Size = new System.Drawing.Size(94, 39);
            this.lblTgtFeedRate.TabIndex = 75;
            this.lblTgtFeedRate.Text = "Target Feed Rate,\r\n                 g/kWh\t\t\r\n\t\t\r\n";
            // 
            // txtMinFeedRate
            // 
            this.txtMinFeedRate.Location = new System.Drawing.Point(129, 249);
            this.txtMinFeedRate.Name = "txtMinFeedRate";
            this.txtMinFeedRate.Size = new System.Drawing.Size(300, 20);
            this.txtMinFeedRate.TabIndex = 42;
            this.txtMinFeedRate.Validating += new System.ComponentModel.CancelEventHandler(this.txtMinFeedRate_Validating);
            // 
            // lblMinFeedRate
            // 
            this.lblMinFeedRate.AutoSize = true;
            this.lblMinFeedRate.Location = new System.Drawing.Point(4, 246);
            this.lblMinFeedRate.Name = "lblMinFeedRate";
            this.lblMinFeedRate.Size = new System.Drawing.Size(110, 26);
            this.lblMinFeedRate.TabIndex = 73;
            this.lblMinFeedRate.Text = "  Min Feed Rate by \r\nManufacturer, g/kWh";
            // 
            // txtCurrentFeedRate
            // 
            this.txtCurrentFeedRate.Location = new System.Drawing.Point(610, 249);
            this.txtCurrentFeedRate.Name = "txtCurrentFeedRate";
            this.txtCurrentFeedRate.Size = new System.Drawing.Size(300, 20);
            this.txtCurrentFeedRate.TabIndex = 43;
            this.txtCurrentFeedRate.Validating += new System.ComponentModel.CancelEventHandler(this.txtCurrentFeedRate_Validating);
            // 
            // lblCurrentFeedRate
            // 
            this.lblCurrentFeedRate.AutoSize = true;
            this.lblCurrentFeedRate.Location = new System.Drawing.Point(490, 246);
            this.lblCurrentFeedRate.Name = "lblCurrentFeedRate";
            this.lblCurrentFeedRate.Size = new System.Drawing.Size(98, 26);
            this.lblCurrentFeedRate.TabIndex = 71;
            this.lblCurrentFeedRate.Text = "Current Feed Rate,\r\n                   g/kWh";
            // 
            // txtLubType
            // 
            this.txtLubType.Location = new System.Drawing.Point(610, 209);
            this.txtLubType.Name = "txtLubType";
            this.txtLubType.Size = new System.Drawing.Size(300, 20);
            this.txtLubType.TabIndex = 41;
            // 
            // lblLubType
            // 
            this.lblLubType.AutoSize = true;
            this.lblLubType.Location = new System.Drawing.Point(508, 212);
            this.lblLubType.Name = "lblLubType";
            this.lblLubType.Size = new System.Drawing.Size(81, 13);
            this.lblLubType.TabIndex = 69;
            this.lblLubType.Text = "Lubricator Type";
            // 
            // txtMCR
            // 
            this.txtMCR.Location = new System.Drawing.Point(610, 174);
            this.txtMCR.Name = "txtMCR";
            this.txtMCR.Size = new System.Drawing.Size(300, 20);
            this.txtMCR.TabIndex = 39;
            this.txtMCR.Validating += new System.ComponentModel.CancelEventHandler(this.txtMCR_Validating);
            // 
            // lblMCR
            // 
            this.lblMCR.AutoSize = true;
            this.lblMCR.Location = new System.Drawing.Point(533, 173);
            this.lblMCR.Name = "lblMCR";
            this.lblMCR.Size = new System.Drawing.Size(54, 13);
            this.lblMCR.TabIndex = 67;
            this.lblMCR.Text = "MCR, kW";
            // 
            // lblRPM
            // 
            this.lblRPM.AutoSize = true;
            this.lblRPM.Location = new System.Drawing.Point(70, 211);
            this.lblRPM.Name = "lblRPM";
            this.lblRPM.Size = new System.Drawing.Size(37, 13);
            this.lblRPM.TabIndex = 66;
            this.lblRPM.Text = "  RPM";
            // 
            // txtRPM
            // 
            this.txtRPM.Location = new System.Drawing.Point(129, 208);
            this.txtRPM.Name = "txtRPM";
            this.txtRPM.Size = new System.Drawing.Size(300, 20);
            this.txtRPM.TabIndex = 40;
            this.txtRPM.Validating += new System.ComponentModel.CancelEventHandler(this.txtRPM_Validating);
            // 
            // txtMainEngNo
            // 
            this.txtMainEngNo.Location = new System.Drawing.Point(129, 173);
            this.txtMainEngNo.Name = "txtMainEngNo";
            this.txtMainEngNo.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngNo.TabIndex = 38;
            // 
            // lblEngNo
            // 
            this.lblEngNo.AutoSize = true;
            this.lblEngNo.Location = new System.Drawing.Point(27, 176);
            this.lblEngNo.Name = "lblEngNo";
            this.lblEngNo.Size = new System.Drawing.Size(83, 13);
            this.lblEngNo.TabIndex = 63;
            this.lblEngNo.Text = "Main Engine No";
            // 
            // txtMainEngSerialNo
            // 
            this.txtMainEngSerialNo.Location = new System.Drawing.Point(129, 134);
            this.txtMainEngSerialNo.Name = "txtMainEngSerialNo";
            this.txtMainEngSerialNo.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngSerialNo.TabIndex = 36;
            // 
            // lblEngSerialNo
            // 
            this.lblEngSerialNo.AutoSize = true;
            this.lblEngSerialNo.Location = new System.Drawing.Point(12, 139);
            this.lblEngSerialNo.Name = "lblEngSerialNo";
            this.lblEngSerialNo.Size = new System.Drawing.Size(98, 13);
            this.lblEngSerialNo.TabIndex = 61;
            this.lblEngSerialNo.Text = "Main Eng Serial No";
            // 
            // txtMainEngLoc
            // 
            this.txtMainEngLoc.Location = new System.Drawing.Point(610, 136);
            this.txtMainEngLoc.Name = "txtMainEngLoc";
            this.txtMainEngLoc.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngLoc.TabIndex = 37;
            // 
            // lblEngLoc
            // 
            this.lblEngLoc.AutoSize = true;
            this.lblEngLoc.Location = new System.Drawing.Point(493, 137);
            this.lblEngLoc.Name = "lblEngLoc";
            this.lblEngLoc.Size = new System.Drawing.Size(96, 13);
            this.lblEngLoc.TabIndex = 59;
            this.lblEngLoc.Text = "Main Eng Location";
            // 
            // lblEngManuf
            // 
            this.lblEngManuf.AutoSize = true;
            this.lblEngManuf.Location = new System.Drawing.Point(39, 96);
            this.lblEngManuf.Name = "lblEngManuf";
            this.lblEngManuf.Size = new System.Drawing.Size(70, 26);
            this.lblEngManuf.TabIndex = 57;
            this.lblEngManuf.Text = "Main Engine\r\nManufacturer";
            // 
            // txtMainEngType
            // 
            this.txtMainEngType.Location = new System.Drawing.Point(610, 98);
            this.txtMainEngType.Name = "txtMainEngType";
            this.txtMainEngType.Size = new System.Drawing.Size(300, 20);
            this.txtMainEngType.TabIndex = 35;
            // 
            // lblEngType
            // 
            this.lblEngType.AutoSize = true;
            this.lblEngType.Location = new System.Drawing.Point(496, 105);
            this.lblEngType.Name = "lblEngType";
            this.lblEngType.Size = new System.Drawing.Size(93, 13);
            this.lblEngType.TabIndex = 55;
            this.lblEngType.Text = "Main Engine Type";
            // 
            // dtDateDelivered
            // 
            this.dtDateDelivered.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDateDelivered.Location = new System.Drawing.Point(610, 63);
            this.dtDateDelivered.Name = "dtDateDelivered";
            this.dtDateDelivered.Size = new System.Drawing.Size(99, 20);
            this.dtDateDelivered.TabIndex = 33;
            this.dtDateDelivered.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtDateDelivered_KeyDown);
            // 
            // lblDateDelivered
            // 
            this.lblDateDelivered.AutoSize = true;
            this.lblDateDelivered.Location = new System.Drawing.Point(511, 66);
            this.lblDateDelivered.Name = "lblDateDelivered";
            this.lblDateDelivered.Size = new System.Drawing.Size(78, 13);
            this.lblDateDelivered.TabIndex = 53;
            this.lblDateDelivered.Text = "Date Delivered";
            // 
            // txtVesselId
            // 
            this.txtVesselId.Location = new System.Drawing.Point(129, 63);
            this.txtVesselId.Name = "txtVesselId";
            this.txtVesselId.Size = new System.Drawing.Size(300, 20);
            this.txtVesselId.TabIndex = 32;
            // 
            // lblVesselId
            // 
            this.lblVesselId.AutoSize = true;
            this.lblVesselId.Location = new System.Drawing.Point(42, 59);
            this.lblVesselId.Name = "lblVesselId";
            this.lblVesselId.Size = new System.Drawing.Size(65, 26);
            this.lblVesselId.TabIndex = 51;
            this.lblVesselId.Text = "Vessel Id As\r\n        In RLA";
            // 
            // txtIMONo
            // 
            this.txtIMONo.Location = new System.Drawing.Point(610, 32);
            this.txtIMONo.Name = "txtIMONo";
            this.txtIMONo.Size = new System.Drawing.Size(300, 20);
            this.txtIMONo.TabIndex = 31;
            this.txtIMONo.Validating += new System.ComponentModel.CancelEventHandler(this.txtIMONo_Validating);
            // 
            // lblIMONo
            // 
            this.lblIMONo.AutoSize = true;
            this.lblIMONo.Location = new System.Drawing.Point(522, 35);
            this.lblIMONo.Name = "lblIMONo";
            this.lblIMONo.Size = new System.Drawing.Size(67, 13);
            this.lblIMONo.TabIndex = 27;
            this.lblIMONo.Text = "IMO Number";
            // 
            // txtVesselName
            // 
            this.txtVesselName.Location = new System.Drawing.Point(129, 32);
            this.txtVesselName.Name = "txtVesselName";
            this.txtVesselName.Size = new System.Drawing.Size(300, 20);
            this.txtVesselName.TabIndex = 30;
            // 
            // lblVesselName
            // 
            this.lblVesselName.AutoSize = true;
            this.lblVesselName.Location = new System.Drawing.Point(40, 35);
            this.lblVesselName.Name = "lblVesselName";
            this.lblVesselName.Size = new System.Drawing.Size(69, 13);
            this.lblVesselName.TabIndex = 25;
            this.lblVesselName.Text = "Vessel Name";
            // 
            // pnlDataSubmission
            // 
            this.pnlDataSubmission.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDataSubmission.Controls.Add(this.textBox1);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML1);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML6);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML5);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML3);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML2);
            this.pnlDataSubmission.Controls.Add(this.lblGenXML4);
            this.pnlDataSubmission.Controls.Add(this.lnkEmail);
            this.pnlDataSubmission.Controls.Add(this.dtpDateTo);
            this.pnlDataSubmission.Controls.Add(this.lblDateTo);
            this.pnlDataSubmission.Controls.Add(this.dtpDateFrom);
            this.pnlDataSubmission.Controls.Add(this.lblDateFrom);
            this.pnlDataSubmission.Controls.Add(this.lblFileLocation);
            this.pnlDataSubmission.Controls.Add(this.lblFileSavedMessage);
            this.pnlDataSubmission.Controls.Add(this.btnSubmitData);
            this.pnlDataSubmission.Location = new System.Drawing.Point(3, 3);
            this.pnlDataSubmission.Name = "pnlDataSubmission";
            this.pnlDataSubmission.Size = new System.Drawing.Size(950, 445);
            this.pnlDataSubmission.TabIndex = 154;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(327, 246);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(251, 18);
            this.textBox1.TabIndex = 15;
            this.textBox1.Text = "SMPL-LubeMonitor@shell.com";
            // 
            // lblGenXML1
            // 
            this.lblGenXML1.AutoSize = true;
            this.lblGenXML1.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML1.Location = new System.Drawing.Point(32, 143);
            this.lblGenXML1.Name = "lblGenXML1";
            this.lblGenXML1.Size = new System.Drawing.Size(35, 13);
            this.lblGenXML1.TabIndex = 14;
            this.lblGenXML1.Text = "Notes";
            // 
            // lblGenXML6
            // 
            this.lblGenXML6.AutoSize = true;
            this.lblGenXML6.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML6.Location = new System.Drawing.Point(32, 247);
            this.lblGenXML6.Name = "lblGenXML6";
            this.lblGenXML6.Size = new System.Drawing.Size(191, 13);
            this.lblGenXML6.TabIndex = 12;
            this.lblGenXML6.Text = "4. Send the XML File as attachment to ";
            // 
            // lblGenXML5
            // 
            this.lblGenXML5.AutoSize = true;
            this.lblGenXML5.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML5.Location = new System.Drawing.Point(422, 219);
            this.lblGenXML5.Name = "lblGenXML5";
            this.lblGenXML5.Size = new System.Drawing.Size(263, 13);
            this.lblGenXML5.TabIndex = 11;
            this.lblGenXML5.Text = " (Please select the xml file as attachment, and send) or";
            // 
            // lblGenXML3
            // 
            this.lblGenXML3.AutoSize = true;
            this.lblGenXML3.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML3.Location = new System.Drawing.Point(32, 192);
            this.lblGenXML3.Name = "lblGenXML3";
            this.lblGenXML3.Size = new System.Drawing.Size(200, 13);
            this.lblGenXML3.TabIndex = 10;
            this.lblGenXML3.Text = "2. Save the XML on your local hard drive";
            // 
            // lblGenXML2
            // 
            this.lblGenXML2.AutoSize = true;
            this.lblGenXML2.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML2.Location = new System.Drawing.Point(32, 166);
            this.lblGenXML2.Name = "lblGenXML2";
            this.lblGenXML2.Size = new System.Drawing.Size(443, 13);
            this.lblGenXML2.TabIndex = 9;
            this.lblGenXML2.Text = "1. Select the range of date to generate the XML File and click on the Generate th" +
    "e XML File ";
            // 
            // lblGenXML4
            // 
            this.lblGenXML4.AutoSize = true;
            this.lblGenXML4.ForeColor = System.Drawing.Color.Black;
            this.lblGenXML4.Location = new System.Drawing.Point(32, 219);
            this.lblGenXML4.Name = "lblGenXML4";
            this.lblGenXML4.Size = new System.Drawing.Size(202, 13);
            this.lblGenXML4.TabIndex = 8;
            this.lblGenXML4.Text = "3. If you are using MS Outlook, you could";
            // 
            // lnkEmail
            // 
            this.lnkEmail.AutoSize = true;
            this.lnkEmail.Location = new System.Drawing.Point(349, 219);
            this.lnkEmail.Name = "lnkEmail";
            this.lnkEmail.Size = new System.Drawing.Size(53, 13);
            this.lnkEmail.TabIndex = 7;
            this.lnkEmail.TabStop = true;
            this.lnkEmail.Text = "click here";
            this.lnkEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkEmail_LinkClicked);
            // 
            // dtpDateTo
            // 
            this.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateTo.Location = new System.Drawing.Point(514, 66);
            this.dtpDateTo.Name = "dtpDateTo";
            this.dtpDateTo.Size = new System.Drawing.Size(98, 20);
            this.dtpDateTo.TabIndex = 6;
            this.dtpDateTo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpDateTo_KeyDown);
            // 
            // lblDateTo
            // 
            this.lblDateTo.AutoSize = true;
            this.lblDateTo.Location = new System.Drawing.Point(462, 71);
            this.lblDateTo.Name = "lblDateTo";
            this.lblDateTo.Size = new System.Drawing.Size(46, 13);
            this.lblDateTo.TabIndex = 5;
            this.lblDateTo.Text = "Date To";
            // 
            // dtpDateFrom
            // 
            this.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateFrom.Location = new System.Drawing.Point(291, 66);
            this.dtpDateFrom.Name = "dtpDateFrom";
            this.dtpDateFrom.Size = new System.Drawing.Size(98, 20);
            this.dtpDateFrom.TabIndex = 4;
            this.dtpDateFrom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpDateFrom_KeyDown);
            // 
            // lblDateFrom
            // 
            this.lblDateFrom.AutoSize = true;
            this.lblDateFrom.Location = new System.Drawing.Point(229, 71);
            this.lblDateFrom.Name = "lblDateFrom";
            this.lblDateFrom.Size = new System.Drawing.Size(56, 13);
            this.lblDateFrom.TabIndex = 3;
            this.lblDateFrom.Text = "Date From";
            // 
            // lblFileLocation
            // 
            this.lblFileLocation.AutoSize = true;
            this.lblFileLocation.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileLocation.Location = new System.Drawing.Point(85, 145);
            this.lblFileLocation.Name = "lblFileLocation";
            this.lblFileLocation.Size = new System.Drawing.Size(0, 18);
            this.lblFileLocation.TabIndex = 2;
            // 
            // lblFileSavedMessage
            // 
            this.lblFileSavedMessage.AutoSize = true;
            this.lblFileSavedMessage.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileSavedMessage.Location = new System.Drawing.Point(50, 93);
            this.lblFileSavedMessage.Name = "lblFileSavedMessage";
            this.lblFileSavedMessage.Size = new System.Drawing.Size(0, 18);
            this.lblFileSavedMessage.TabIndex = 1;
            // 
            // btnSubmitData
            // 
            this.btnSubmitData.BackColor = System.Drawing.Color.Red;
            this.btnSubmitData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmitData.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitData.ForeColor = System.Drawing.Color.White;
            this.btnSubmitData.Location = new System.Drawing.Point(371, 113);
            this.btnSubmitData.Name = "btnSubmitData";
            this.btnSubmitData.Size = new System.Drawing.Size(142, 23);
            this.btnSubmitData.TabIndex = 0;
            this.btnSubmitData.Text = "Generate XML File";
            this.btnSubmitData.UseVisualStyleBackColor = false;
            this.btnSubmitData.Click += new System.EventHandler(this.btnSubmitData_Click);
            // 
            // pnlSetting
            // 
            this.pnlSetting.Controls.Add(this.lblHidden);
            this.pnlSetting.Controls.Add(this.label18);
            this.pnlSetting.Controls.Add(this.cmbNoOfEngines);
            this.pnlSetting.Controls.Add(this.label76);
            this.pnlSetting.Controls.Add(this.cmbNoOfCyl);
            this.pnlSetting.Controls.Add(this.cmbProjectStatus);
            this.pnlSetting.Controls.Add(this.label70);
            this.pnlSetting.Controls.Add(this.label69);
            this.pnlSetting.Controls.Add(this.label35);
            this.pnlSetting.Controls.Add(this.lblNoOfEngines);
            this.pnlSetting.Controls.Add(this.lblNoOfCyl);
            this.pnlSetting.Controls.Add(this.btnSaveSetting);
            this.pnlSetting.Controls.Add(this.label24);
            this.pnlSetting.Controls.Add(this.txtSettingVslId);
            this.pnlSetting.Controls.Add(this.label21);
            this.pnlSetting.Controls.Add(this.txtSettingIMONumber);
            this.pnlSetting.Controls.Add(this.label22);
            this.pnlSetting.Controls.Add(this.txtSettingVesselName);
            this.pnlSetting.Controls.Add(this.label23);
            this.pnlSetting.Controls.Add(this.txtSMPPhone);
            this.pnlSetting.Controls.Add(this.lblSMPPhone);
            this.pnlSetting.Controls.Add(this.txtCustTelephone);
            this.pnlSetting.Controls.Add(this.lblCustPhone);
            this.pnlSetting.Controls.Add(this.txtSMPEMail);
            this.pnlSetting.Controls.Add(this.lblSMPEmail);
            this.pnlSetting.Controls.Add(this.txtCustEmail);
            this.pnlSetting.Controls.Add(this.lblCustEmail);
            this.pnlSetting.Controls.Add(this.txtSMPAddress);
            this.pnlSetting.Controls.Add(this.lblSMPAddress);
            this.pnlSetting.Controls.Add(this.txtCustAddress);
            this.pnlSetting.Controls.Add(this.lblCustAddress);
            this.pnlSetting.Controls.Add(this.txtSMPContact);
            this.pnlSetting.Controls.Add(this.lblSMPContact);
            this.pnlSetting.Controls.Add(this.txtCustomerContact);
            this.pnlSetting.Controls.Add(this.lblCustomerContact);
            this.pnlSetting.Controls.Add(this.dtpTargetEndDate);
            this.pnlSetting.Controls.Add(this.lblTgtCompdate);
            this.pnlSetting.Controls.Add(this.dtpStartDate);
            this.pnlSetting.Controls.Add(this.lblStartDate);
            this.pnlSetting.Controls.Add(this.txtNoOfVessels);
            this.pnlSetting.Controls.Add(this.lblNoOfVessels);
            this.pnlSetting.Controls.Add(this.txtCompName);
            this.pnlSetting.Controls.Add(this.lblCompanyName);
            this.pnlSetting.Controls.Add(this.txtProjectID);
            this.pnlSetting.Controls.Add(this.lblProjectId);
            this.pnlSetting.Controls.Add(this.btnNew);
            this.pnlSetting.Controls.Add(this.dgvProjectData);
            this.pnlSetting.Location = new System.Drawing.Point(3, 3);
            this.pnlSetting.Name = "pnlSetting";
            this.pnlSetting.Size = new System.Drawing.Size(950, 445);
            this.pnlSetting.TabIndex = 93;
            // 
            // lblHidden
            // 
            this.lblHidden.AutoSize = true;
            this.lblHidden.Location = new System.Drawing.Point(60, 43);
            this.lblHidden.Name = "lblHidden";
            this.lblHidden.Size = new System.Drawing.Size(41, 13);
            this.lblHidden.TabIndex = 156;
            this.lblHidden.Text = "label38";
            this.lblHidden.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(378, 404);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 13);
            this.label18.TabIndex = 155;
            this.label18.Text = "*";
            // 
            // cmbNoOfEngines
            // 
            this.cmbNoOfEngines.FormattingEnabled = true;
            this.cmbNoOfEngines.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cmbNoOfEngines.Location = new System.Drawing.Point(124, 395);
            this.cmbNoOfEngines.Name = "cmbNoOfEngines";
            this.cmbNoOfEngines.Size = new System.Drawing.Size(248, 21);
            this.cmbNoOfEngines.TabIndex = 19;
            this.cmbNoOfEngines.SelectedIndexChanged += new System.EventHandler(this.cmbNoOfEngines_SelectedIndexChanged);
            this.cmbNoOfEngines.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbNoOfEngines_KeyDown);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.ForeColor = System.Drawing.Color.Red;
            this.label76.Location = new System.Drawing.Point(379, 350);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(11, 13);
            this.label76.TabIndex = 154;
            this.label76.Text = "*";
            // 
            // cmbNoOfCyl
            // 
            this.cmbNoOfCyl.FormattingEnabled = true;
            this.cmbNoOfCyl.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbNoOfCyl.Location = new System.Drawing.Point(586, 337);
            this.cmbNoOfCyl.Name = "cmbNoOfCyl";
            this.cmbNoOfCyl.Size = new System.Drawing.Size(248, 21);
            this.cmbNoOfCyl.TabIndex = 16;
            this.cmbNoOfCyl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbNoOfCyl_KeyDown);
            // 
            // cmbProjectStatus
            // 
            this.cmbProjectStatus.FormattingEnabled = true;
            this.cmbProjectStatus.Items.AddRange(new object[] {
            "--Select--",
            "Open",
            "In-progress",
            "Closed"});
            this.cmbProjectStatus.Location = new System.Drawing.Point(587, 126);
            this.cmbProjectStatus.Name = "cmbProjectStatus";
            this.cmbProjectStatus.Size = new System.Drawing.Size(121, 21);
            this.cmbProjectStatus.TabIndex = 4;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(492, 130);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(87, 13);
            this.label70.TabIndex = 152;
            this.label70.Text = "Project Status";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.ForeColor = System.Drawing.Color.Red;
            this.label69.Location = new System.Drawing.Point(745, 2);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(171, 13);
            this.label69.TabIndex = 150;
            this.label69.Text = "Fields marked with * are mandatory";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(839, 345);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(11, 13);
            this.label35.TabIndex = 68;
            this.label35.Text = "*";
            // 
            // lblNoOfEngines
            // 
            this.lblNoOfEngines.AutoSize = true;
            this.lblNoOfEngines.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfEngines.Location = new System.Drawing.Point(29, 402);
            this.lblNoOfEngines.Name = "lblNoOfEngines";
            this.lblNoOfEngines.Size = new System.Drawing.Size(91, 13);
            this.lblNoOfEngines.TabIndex = 64;
            this.lblNoOfEngines.Text = "No. Of Engines";
            // 
            // lblNoOfCyl
            // 
            this.lblNoOfCyl.AutoSize = true;
            this.lblNoOfCyl.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfCyl.Location = new System.Drawing.Point(480, 342);
            this.lblNoOfCyl.Name = "lblNoOfCyl";
            this.lblNoOfCyl.Size = new System.Drawing.Size(101, 13);
            this.lblNoOfCyl.TabIndex = 61;
            this.lblNoOfCyl.Text = "No. Of Cylinders";
            // 
            // btnSaveSetting
            // 
            this.btnSaveSetting.BackColor = System.Drawing.Color.Red;
            this.btnSaveSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSetting.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveSetting.Location = new System.Drawing.Point(626, 420);
            this.btnSaveSetting.Name = "btnSaveSetting";
            this.btnSaveSetting.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSetting.TabIndex = 22;
            this.btnSaveSetting.Text = "Save";
            this.btnSaveSetting.UseVisualStyleBackColor = false;
            this.btnSaveSetting.Click += new System.EventHandler(this.btnSaveSetting_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(379, 376);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(11, 13);
            this.label24.TabIndex = 59;
            this.label24.Text = "*";
            // 
            // txtSettingVslId
            // 
            this.txtSettingVslId.Location = new System.Drawing.Point(126, 364);
            this.txtSettingVslId.Name = "txtSettingVslId";
            this.txtSettingVslId.Size = new System.Drawing.Size(246, 20);
            this.txtSettingVslId.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(39, 362);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(78, 26);
            this.label21.TabIndex = 57;
            this.label21.Text = "Vessel Id As\r\nIn RLA";
            // 
            // txtSettingIMONumber
            // 
            this.txtSettingIMONumber.Location = new System.Drawing.Point(586, 364);
            this.txtSettingIMONumber.Name = "txtSettingIMONumber";
            this.txtSettingIMONumber.Size = new System.Drawing.Size(246, 20);
            this.txtSettingIMONumber.TabIndex = 18;
            this.txtSettingIMONumber.Validating += new System.ComponentModel.CancelEventHandler(this.txtSettingIMONumber_Validating);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(501, 368);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 13);
            this.label22.TabIndex = 55;
            this.label22.Text = "IMO Number";
            // 
            // txtSettingVesselName
            // 
            this.txtSettingVesselName.Location = new System.Drawing.Point(125, 334);
            this.txtSettingVesselName.Name = "txtSettingVesselName";
            this.txtSettingVesselName.Size = new System.Drawing.Size(246, 20);
            this.txtSettingVesselName.TabIndex = 15;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(39, 337);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 13);
            this.label23.TabIndex = 53;
            this.label23.Text = "Vessel Name";
            // 
            // txtSMPPhone
            // 
            this.txtSMPPhone.Location = new System.Drawing.Point(587, 311);
            this.txtSMPPhone.Name = "txtSMPPhone";
            this.txtSMPPhone.Size = new System.Drawing.Size(247, 20);
            this.txtSMPPhone.TabIndex = 14;
            // 
            // lblSMPPhone
            // 
            this.lblSMPPhone.AutoSize = true;
            this.lblSMPPhone.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMPPhone.Location = new System.Drawing.Point(438, 316);
            this.lblSMPPhone.Name = "lblSMPPhone";
            this.lblSMPPhone.Size = new System.Drawing.Size(140, 13);
            this.lblSMPPhone.TabIndex = 26;
            this.lblSMPPhone.Text = "Shell Marine Telephone";
            // 
            // txtCustTelephone
            // 
            this.txtCustTelephone.Location = new System.Drawing.Point(587, 230);
            this.txtCustTelephone.Name = "txtCustTelephone";
            this.txtCustTelephone.Size = new System.Drawing.Size(247, 20);
            this.txtCustTelephone.TabIndex = 9;
            // 
            // lblCustPhone
            // 
            this.lblCustPhone.AutoSize = true;
            this.lblCustPhone.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustPhone.Location = new System.Drawing.Point(512, 232);
            this.lblCustPhone.Name = "lblCustPhone";
            this.lblCustPhone.Size = new System.Drawing.Size(66, 13);
            this.lblCustPhone.TabIndex = 24;
            this.lblCustPhone.Text = "Telephone";
            // 
            // txtSMPEMail
            // 
            this.txtSMPEMail.Location = new System.Drawing.Point(586, 285);
            this.txtSMPEMail.Name = "txtSMPEMail";
            this.txtSMPEMail.Size = new System.Drawing.Size(247, 20);
            this.txtSMPEMail.TabIndex = 13;
            // 
            // lblSMPEmail
            // 
            this.lblSMPEmail.AutoSize = true;
            this.lblSMPEmail.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMPEmail.Location = new System.Drawing.Point(466, 290);
            this.lblSMPEmail.Name = "lblSMPEmail";
            this.lblSMPEmail.Size = new System.Drawing.Size(112, 13);
            this.lblSMPEmail.TabIndex = 22;
            this.lblSMPEmail.Text = "Shell Marine Email";
            // 
            // txtCustEmail
            // 
            this.txtCustEmail.Location = new System.Drawing.Point(587, 205);
            this.txtCustEmail.Name = "txtCustEmail";
            this.txtCustEmail.Size = new System.Drawing.Size(247, 20);
            this.txtCustEmail.TabIndex = 8;
            // 
            // lblCustEmail
            // 
            this.lblCustEmail.AutoSize = true;
            this.lblCustEmail.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustEmail.Location = new System.Drawing.Point(483, 208);
            this.lblCustEmail.Name = "lblCustEmail";
            this.lblCustEmail.Size = new System.Drawing.Size(98, 13);
            this.lblCustEmail.TabIndex = 20;
            this.lblCustEmail.Text = "Customer Email";
            // 
            // txtSMPAddress
            // 
            this.txtSMPAddress.Location = new System.Drawing.Point(125, 285);
            this.txtSMPAddress.Multiline = true;
            this.txtSMPAddress.Name = "txtSMPAddress";
            this.txtSMPAddress.Size = new System.Drawing.Size(247, 45);
            this.txtSMPAddress.TabIndex = 12;
            // 
            // lblSMPAddress
            // 
            this.lblSMPAddress.AutoSize = true;
            this.lblSMPAddress.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMPAddress.Location = new System.Drawing.Point(37, 286);
            this.lblSMPAddress.Name = "lblSMPAddress";
            this.lblSMPAddress.Size = new System.Drawing.Size(81, 13);
            this.lblSMPAddress.TabIndex = 18;
            this.lblSMPAddress.Text = "SMP Address";
            // 
            // txtCustAddress
            // 
            this.txtCustAddress.Location = new System.Drawing.Point(125, 206);
            this.txtCustAddress.Multiline = true;
            this.txtCustAddress.Name = "txtCustAddress";
            this.txtCustAddress.Size = new System.Drawing.Size(247, 45);
            this.txtCustAddress.TabIndex = 7;
            // 
            // lblCustAddress
            // 
            this.lblCustAddress.AutoSize = true;
            this.lblCustAddress.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustAddress.Location = new System.Drawing.Point(63, 209);
            this.lblCustAddress.Name = "lblCustAddress";
            this.lblCustAddress.Size = new System.Drawing.Size(53, 13);
            this.lblCustAddress.TabIndex = 16;
            this.lblCustAddress.Text = "Address";
            // 
            // txtSMPContact
            // 
            this.txtSMPContact.Location = new System.Drawing.Point(586, 261);
            this.txtSMPContact.Name = "txtSMPContact";
            this.txtSMPContact.Size = new System.Drawing.Size(247, 20);
            this.txtSMPContact.TabIndex = 11;
            // 
            // lblSMPContact
            // 
            this.lblSMPContact.AutoSize = true;
            this.lblSMPContact.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMPContact.Location = new System.Drawing.Point(454, 268);
            this.lblSMPContact.Name = "lblSMPContact";
            this.lblSMPContact.Size = new System.Drawing.Size(125, 13);
            this.lblSMPContact.TabIndex = 14;
            this.lblSMPContact.Text = "Shell Marine Contact";
            // 
            // txtCustomerContact
            // 
            this.txtCustomerContact.Location = new System.Drawing.Point(587, 180);
            this.txtCustomerContact.Name = "txtCustomerContact";
            this.txtCustomerContact.Size = new System.Drawing.Size(247, 20);
            this.txtCustomerContact.TabIndex = 6;
            // 
            // lblCustomerContact
            // 
            this.lblCustomerContact.AutoSize = true;
            this.lblCustomerContact.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerContact.Location = new System.Drawing.Point(467, 183);
            this.lblCustomerContact.Name = "lblCustomerContact";
            this.lblCustomerContact.Size = new System.Drawing.Size(111, 13);
            this.lblCustomerContact.TabIndex = 12;
            this.lblCustomerContact.Text = "Customer Contact";
            // 
            // dtpTargetEndDate
            // 
            this.dtpTargetEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTargetEndDate.Location = new System.Drawing.Point(586, 153);
            this.dtpTargetEndDate.Name = "dtpTargetEndDate";
            this.dtpTargetEndDate.Size = new System.Drawing.Size(113, 20);
            this.dtpTargetEndDate.TabIndex = 3;
            this.dtpTargetEndDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpTargetEndDate_KeyDown);
            // 
            // lblTgtCompdate
            // 
            this.lblTgtCompdate.AutoSize = true;
            this.lblTgtCompdate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTgtCompdate.Location = new System.Drawing.Point(467, 153);
            this.lblTgtCompdate.Name = "lblTgtCompdate";
            this.lblTgtCompdate.Size = new System.Drawing.Size(114, 26);
            this.lblTgtCompdate.TabIndex = 10;
            this.lblTgtCompdate.Text = "Target Completion\r\n                    Date";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(125, 156);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(113, 20);
            this.dtpStartDate.TabIndex = 2;
            this.dtpStartDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpStartDate_KeyDown);
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(50, 159);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(70, 13);
            this.lblStartDate.TabIndex = 8;
            this.lblStartDate.Text = "Start Date ";
            // 
            // txtNoOfVessels
            // 
            this.txtNoOfVessels.Location = new System.Drawing.Point(125, 257);
            this.txtNoOfVessels.Name = "txtNoOfVessels";
            this.txtNoOfVessels.Size = new System.Drawing.Size(247, 20);
            this.txtNoOfVessels.TabIndex = 10;
            // 
            // lblNoOfVessels
            // 
            this.lblNoOfVessels.AutoSize = true;
            this.lblNoOfVessels.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfVessels.Location = new System.Drawing.Point(25, 261);
            this.lblNoOfVessels.Name = "lblNoOfVessels";
            this.lblNoOfVessels.Size = new System.Drawing.Size(94, 13);
            this.lblNoOfVessels.TabIndex = 6;
            this.lblNoOfVessels.Text = "No. Of Vessels ";
            this.lblNoOfVessels.Click += new System.EventHandler(this.lblNoOfVessels_Click);
            // 
            // txtCompName
            // 
            this.txtCompName.Location = new System.Drawing.Point(125, 180);
            this.txtCompName.Name = "txtCompName";
            this.txtCompName.Size = new System.Drawing.Size(247, 20);
            this.txtCompName.TabIndex = 5;
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Location = new System.Drawing.Point(22, 183);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(99, 13);
            this.lblCompanyName.TabIndex = 4;
            this.lblCompanyName.Text = "Company Name";
            // 
            // txtProjectID
            // 
            this.txtProjectID.Location = new System.Drawing.Point(125, 127);
            this.txtProjectID.Name = "txtProjectID";
            this.txtProjectID.ReadOnly = true;
            this.txtProjectID.Size = new System.Drawing.Size(247, 20);
            this.txtProjectID.TabIndex = 100;
            // 
            // lblProjectId
            // 
            this.lblProjectId.AutoSize = true;
            this.lblProjectId.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectId.Location = new System.Drawing.Point(51, 130);
            this.lblProjectId.Name = "lblProjectId";
            this.lblProjectId.Size = new System.Drawing.Size(65, 13);
            this.lblProjectId.TabIndex = 2;
            this.lblProjectId.Text = "Project ID";
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.Red;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNew.Location = new System.Drawing.Point(742, 421);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 23;
            this.btnNew.Text = "New + ";
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // dgvProjectData
            // 
            this.dgvProjectData.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvProjectData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjectData.Location = new System.Drawing.Point(146, 6);
            this.dgvProjectData.Name = "dgvProjectData";
            this.dgvProjectData.Size = new System.Drawing.Size(573, 112);
            this.dgvProjectData.TabIndex = 101;
            // 
            // pnlConUs
            // 
            this.pnlConUs.Controls.Add(this.textBox3);
            this.pnlConUs.Controls.Add(this.textBox2);
            this.pnlConUs.Controls.Add(this.label33);
            this.pnlConUs.Controls.Add(this.label34);
            this.pnlConUs.Controls.Add(this.label30);
            this.pnlConUs.Controls.Add(this.label29);
            this.pnlConUs.Controls.Add(this.label28);
            this.pnlConUs.Controls.Add(this.label27);
            this.pnlConUs.Controls.Add(this.lnkHere);
            this.pnlConUs.Controls.Add(this.lblContactUs2);
            this.pnlConUs.Controls.Add(this.lblContactUs1);
            this.pnlConUs.Location = new System.Drawing.Point(3, 3);
            this.pnlConUs.Name = "pnlConUs";
            this.pnlConUs.Size = new System.Drawing.Size(950, 445);
            this.pnlConUs.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(271, 238);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(262, 12);
            this.textBox3.TabIndex = 12;
            this.textBox3.Text = "SMPL-Global-Technical-Support-Team@shell.com";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Verdana", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(372, 190);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(161, 12);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "SMPL-RLA-Support@shell.com";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(54, 239);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(149, 13);
            this.label33.TabIndex = 9;
            this.label33.Text = "Technical Support E-mail";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(53, 215);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(191, 13);
            this.label34.TabIndex = 8;
            this.label34.Text = "Technical Support(Non-RLA)";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(53, 189);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(69, 13);
            this.label30.TabIndex = 6;
            this.label30.Text = "RLA E-mail";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(52, 165);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(86, 13);
            this.label29.TabIndex = 5;
            this.label29.Text = "RLA Support";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Gold;
            this.label28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(51, 122);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(482, 28);
            this.label28.TabIndex = 4;
            this.label28.Text = "Global Helpdesk:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(48, 84);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(440, 18);
            this.label27.TabIndex = 3;
            this.label27.Text = "If unknown, please contact the Global Technical Helpdesk:";
            // 
            // lnkHere
            // 
            this.lnkHere.AutoSize = true;
            this.lnkHere.Font = new System.Drawing.Font("Verdana", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkHere.ForeColor = System.Drawing.Color.Red;
            this.lnkHere.LinkColor = System.Drawing.Color.Red;
            this.lnkHere.Location = new System.Drawing.Point(432, 43);
            this.lnkHere.Name = "lnkHere";
            this.lnkHere.Size = new System.Drawing.Size(51, 22);
            this.lnkHere.TabIndex = 2;
            this.lnkHere.TabStop = true;
            this.lnkHere.Text = "here";
            this.lnkHere.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkHere_LinkClicked);
            // 
            // lblContactUs2
            // 
            this.lblContactUs2.AutoSize = true;
            this.lblContactUs2.Font = new System.Drawing.Font("Verdana", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactUs2.ForeColor = System.Drawing.Color.Red;
            this.lblContactUs2.Location = new System.Drawing.Point(472, 43);
            this.lblContactUs2.Name = "lblContactUs2";
            this.lblContactUs2.Size = new System.Drawing.Size(199, 22);
            this.lblContactUs2.TabIndex = 1;
            this.lblContactUs2.Text = "for more information";
            // 
            // lblContactUs1
            // 
            this.lblContactUs1.AutoSize = true;
            this.lblContactUs1.Font = new System.Drawing.Font("Verdana", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactUs1.ForeColor = System.Drawing.Color.Red;
            this.lblContactUs1.Location = new System.Drawing.Point(47, 43);
            this.lblContactUs1.Name = "lblContactUs1";
            this.lblContactUs1.Size = new System.Drawing.Size(478, 22);
            this.lblContactUs1.TabIndex = 0;
            this.lblContactUs1.Text = "Please contact your local SMP Representative, click ";
            // 
            // pnlGraph
            // 
            this.pnlGraph.Controls.Add(this.txtRefBN);
            this.pnlGraph.Controls.Add(this.label32);
            this.pnlGraph.Controls.Add(this.txtReferenceIron);
            this.pnlGraph.Controls.Add(this.label31);
            this.pnlGraph.Controls.Add(this.label26);
            this.pnlGraph.Controls.Add(this.cmbIronAxis);
            this.pnlGraph.Controls.Add(this.label25);
            this.pnlGraph.Controls.Add(this.label5);
            this.pnlGraph.Controls.Add(this.dtpGraphEndDate);
            this.pnlGraph.Controls.Add(this.dtpGraphStartDate);
            this.pnlGraph.Controls.Add(this.chkCylinderNumber);
            this.pnlGraph.Controls.Add(this.lblEngNoGraph);
            this.pnlGraph.Controls.Add(this.btnSubmitGraph);
            this.pnlGraph.Controls.Add(this.label19);
            this.pnlGraph.Controls.Add(this.cmbXAxis);
            this.pnlGraph.Controls.Add(this.chBNData);
            this.pnlGraph.Controls.Add(this.chCylinderData);
            this.pnlGraph.Location = new System.Drawing.Point(3, 3);
            this.pnlGraph.Name = "pnlGraph";
            this.pnlGraph.Size = new System.Drawing.Size(950, 445);
            this.pnlGraph.TabIndex = 93;
            // 
            // txtRefBN
            // 
            this.txtRefBN.Location = new System.Drawing.Point(9, 344);
            this.txtRefBN.Name = "txtRefBN";
            this.txtRefBN.Size = new System.Drawing.Size(100, 20);
            this.txtRefBN.TabIndex = 111;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 322);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(46, 13);
            this.label32.TabIndex = 110;
            this.label32.Text = "BN Limit";
            // 
            // txtReferenceIron
            // 
            this.txtReferenceIron.Location = new System.Drawing.Point(14, 136);
            this.txtReferenceIron.Name = "txtReferenceIron";
            this.txtReferenceIron.Size = new System.Drawing.Size(100, 20);
            this.txtReferenceIron.TabIndex = 109;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(11, 114);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 13);
            this.label31.TabIndex = 108;
            this.label31.Text = "Iron Limit";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(12, 53);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 13);
            this.label26.TabIndex = 107;
            this.label26.Text = "Iron Type";
            // 
            // cmbIronAxis
            // 
            this.cmbIronAxis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIronAxis.FormattingEnabled = true;
            this.cmbIronAxis.Items.AddRange(new object[] {
            "On-board Total Fe",
            "Magnetic Fe"});
            this.cmbIronAxis.Location = new System.Drawing.Point(11, 70);
            this.cmbIronAxis.Name = "cmbIronAxis";
            this.cmbIronAxis.Size = new System.Drawing.Size(110, 21);
            this.cmbIronAxis.TabIndex = 106;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(435, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 13);
            this.label25.TabIndex = 105;
            this.label25.Text = "Date To";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(227, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 104;
            this.label5.Text = "Date From";
            // 
            // dtpGraphEndDate
            // 
            this.dtpGraphEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpGraphEndDate.Location = new System.Drawing.Point(486, 2);
            this.dtpGraphEndDate.Name = "dtpGraphEndDate";
            this.dtpGraphEndDate.Size = new System.Drawing.Size(81, 20);
            this.dtpGraphEndDate.TabIndex = 103;
            // 
            // dtpGraphStartDate
            // 
            this.dtpGraphStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpGraphStartDate.Location = new System.Drawing.Point(290, 3);
            this.dtpGraphStartDate.Name = "dtpGraphStartDate";
            this.dtpGraphStartDate.Size = new System.Drawing.Size(81, 20);
            this.dtpGraphStartDate.TabIndex = 102;
            // 
            // chkCylinderNumber
            // 
            this.chkCylinderNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chkCylinderNumber.FormattingEnabled = true;
            this.chkCylinderNumber.Location = new System.Drawing.Point(827, 84);
            this.chkCylinderNumber.Name = "chkCylinderNumber";
            this.chkCylinderNumber.Size = new System.Drawing.Size(120, 210);
            this.chkCylinderNumber.TabIndex = 4;
            // 
            // lblEngNoGraph
            // 
            this.lblEngNoGraph.AutoSize = true;
            this.lblEngNoGraph.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngNoGraph.Location = new System.Drawing.Point(13, 1);
            this.lblEngNoGraph.Name = "lblEngNoGraph";
            this.lblEngNoGraph.Size = new System.Drawing.Size(68, 18);
            this.lblEngNoGraph.TabIndex = 101;
            this.lblEngNoGraph.Text = "label71";
            // 
            // btnSubmitGraph
            // 
            this.btnSubmitGraph.BackColor = System.Drawing.Color.Red;
            this.btnSubmitGraph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmitGraph.ForeColor = System.Drawing.Color.White;
            this.btnSubmitGraph.Location = new System.Drawing.Point(842, 9);
            this.btnSubmitGraph.Name = "btnSubmitGraph";
            this.btnSubmitGraph.Size = new System.Drawing.Size(75, 23);
            this.btnSubmitGraph.TabIndex = 5;
            this.btnSubmitGraph.Text = "Submit";
            this.btnSubmitGraph.UseVisualStyleBackColor = false;
            this.btnSubmitGraph.Click += new System.EventHandler(this.btnSubmitGraph_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(824, 39);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "X-Axis";
            // 
            // cmbXAxis
            // 
            this.cmbXAxis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbXAxis.FormattingEnabled = true;
            this.cmbXAxis.Items.AddRange(new object[] {
            "Running Hours",
            "Date"});
            this.cmbXAxis.Location = new System.Drawing.Point(827, 56);
            this.cmbXAxis.Name = "cmbXAxis";
            this.cmbXAxis.Size = new System.Drawing.Size(110, 21);
            this.cmbXAxis.TabIndex = 2;
            // 
            // chBNData
            // 
            chartArea35.Name = "ChartArea1";
            this.chBNData.ChartAreas.Add(chartArea35);
            legend35.Name = "Legend1";
            this.chBNData.Legends.Add(legend35);
            this.chBNData.Location = new System.Drawing.Point(106, 235);
            this.chBNData.Name = "chBNData";
            this.chBNData.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.chBNData.Size = new System.Drawing.Size(734, 208);
            this.chBNData.TabIndex = 1;
            this.chBNData.Text = "chart1";
            // 
            // chCylinderData
            // 
            chartArea36.Name = "ChartArea1";
            this.chCylinderData.ChartAreas.Add(chartArea36);
            legend36.Name = "Legend1";
            this.chCylinderData.Legends.Add(legend36);
            this.chCylinderData.Location = new System.Drawing.Point(102, 30);
            this.chCylinderData.Name = "chCylinderData";
            this.chCylinderData.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.chCylinderData.Size = new System.Drawing.Size(734, 208);
            this.chCylinderData.TabIndex = 0;
            this.chCylinderData.Text = "chart1";
            // 
            // pnlSupportInfo
            // 
            this.pnlSupportInfo.Controls.Add(this.lblNewSupport);
            this.pnlSupportInfo.Controls.Add(this.label37);
            this.pnlSupportInfo.Controls.Add(this.label36);
            this.pnlSupportInfo.Controls.Add(this.chkLstCylInspection);
            this.pnlSupportInfo.Controls.Add(this.btnAddNewSupport);
            this.pnlSupportInfo.Controls.Add(this.dtpSupportInfo);
            this.pnlSupportInfo.Controls.Add(this.lblEngineNoSup);
            this.pnlSupportInfo.Controls.Add(this.lblCylInfoSupport);
            this.pnlSupportInfo.Controls.Add(this.dgvLinearWear);
            this.pnlSupportInfo.Controls.Add(this.label39);
            this.pnlSupportInfo.Controls.Add(this.lblSupportLinWear);
            this.pnlSupportInfo.Controls.Add(this.dgvRunningHour);
            this.pnlSupportInfo.Controls.Add(this.lblSupportRngHour);
            this.pnlSupportInfo.Controls.Add(this.btnSaveSupportInfo);
            this.pnlSupportInfo.Controls.Add(this.lblSupportBunker);
            this.pnlSupportInfo.Controls.Add(this.dgvBunkerInfo);
            this.pnlSupportInfo.Controls.Add(this.dgvCylInpsection);
            this.pnlSupportInfo.Location = new System.Drawing.Point(3, 3);
            this.pnlSupportInfo.Name = "pnlSupportInfo";
            this.pnlSupportInfo.Size = new System.Drawing.Size(950, 445);
            this.pnlSupportInfo.TabIndex = 1;
            // 
            // lblNewSupport
            // 
            this.lblNewSupport.AutoSize = true;
            this.lblNewSupport.Location = new System.Drawing.Point(511, 4);
            this.lblNewSupport.Name = "lblNewSupport";
            this.lblNewSupport.Size = new System.Drawing.Size(41, 13);
            this.lblNewSupport.TabIndex = 106;
            this.lblNewSupport.Text = "label38";
            this.lblNewSupport.Visible = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(37, 230);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(390, 13);
            this.label37.TabIndex = 105;
            this.label37.Text = "Please select this check box if cylinders were inspected on this day";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(234, 6);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 13);
            this.label36.TabIndex = 104;
            this.label36.Text = "Date of Reading";
            // 
            // chkLstCylInspection
            // 
            this.chkLstCylInspection.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chkLstCylInspection.FormattingEnabled = true;
            this.chkLstCylInspection.Location = new System.Drawing.Point(77, 248);
            this.chkLstCylInspection.Name = "chkLstCylInspection";
            this.chkLstCylInspection.Size = new System.Drawing.Size(168, 195);
            this.chkLstCylInspection.TabIndex = 103;
            // 
            // btnAddNewSupport
            // 
            this.btnAddNewSupport.BackColor = System.Drawing.Color.Red;
            this.btnAddNewSupport.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAddNewSupport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewSupport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewSupport.ForeColor = System.Drawing.Color.White;
            this.btnAddNewSupport.Location = new System.Drawing.Point(451, 416);
            this.btnAddNewSupport.Name = "btnAddNewSupport";
            this.btnAddNewSupport.Size = new System.Drawing.Size(106, 23);
            this.btnAddNewSupport.TabIndex = 102;
            this.btnAddNewSupport.Text = "Add new date";
            this.btnAddNewSupport.UseVisualStyleBackColor = false;
            this.btnAddNewSupport.Click += new System.EventHandler(this.btnAddNewSupport_Click);
            // 
            // dtpSupportInfo
            // 
            this.dtpSupportInfo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSupportInfo.Location = new System.Drawing.Point(337, 4);
            this.dtpSupportInfo.Name = "dtpSupportInfo";
            this.dtpSupportInfo.Size = new System.Drawing.Size(92, 20);
            this.dtpSupportInfo.TabIndex = 101;
            this.dtpSupportInfo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpSupportInfo_KeyDown);
            this.dtpSupportInfo.Validating += new System.ComponentModel.CancelEventHandler(this.dtpSupportInfo_Validating);
            // 
            // lblEngineNoSup
            // 
            this.lblEngineNoSup.AutoSize = true;
            this.lblEngineNoSup.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineNoSup.Location = new System.Drawing.Point(13, 1);
            this.lblEngineNoSup.Name = "lblEngineNoSup";
            this.lblEngineNoSup.Size = new System.Drawing.Size(68, 18);
            this.lblEngineNoSup.TabIndex = 100;
            this.lblEngineNoSup.Text = "label71";
            // 
            // lblCylInfoSupport
            // 
            this.lblCylInfoSupport.AutoSize = true;
            this.lblCylInfoSupport.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCylInfoSupport.ForeColor = System.Drawing.Color.Red;
            this.lblCylInfoSupport.Location = new System.Drawing.Point(38, 208);
            this.lblCylInfoSupport.Name = "lblCylInfoSupport";
            this.lblCylInfoSupport.Size = new System.Drawing.Size(254, 17);
            this.lblCylInfoSupport.TabIndex = 98;
            this.lblCylInfoSupport.Text = "Information On Cylinder Inspection";
            // 
            // dgvLinearWear
            // 
            this.dgvLinearWear.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvLinearWear.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvLinearWear.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLinearWear.Location = new System.Drawing.Point(455, 258);
            this.dgvLinearWear.Name = "dgvLinearWear";
            this.dgvLinearWear.Size = new System.Drawing.Size(362, 150);
            this.dgvLinearWear.TabIndex = 97;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(455, 230);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(193, 13);
            this.label39.TabIndex = 96;
            this.label39.Text = "Latest Liner Calib (Max Reading)";
            // 
            // lblSupportLinWear
            // 
            this.lblSupportLinWear.AutoSize = true;
            this.lblSupportLinWear.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupportLinWear.ForeColor = System.Drawing.Color.Red;
            this.lblSupportLinWear.Location = new System.Drawing.Point(455, 209);
            this.lblSupportLinWear.Name = "lblSupportLinWear";
            this.lblSupportLinWear.Size = new System.Drawing.Size(196, 17);
            this.lblSupportLinWear.TabIndex = 95;
            this.lblSupportLinWear.Text = "Information On Liner Wear";
            // 
            // dgvRunningHour
            // 
            this.dgvRunningHour.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvRunningHour.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRunningHour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRunningHour.Location = new System.Drawing.Point(457, 42);
            this.dgvRunningHour.Name = "dgvRunningHour";
            this.dgvRunningHour.Size = new System.Drawing.Size(459, 150);
            this.dgvRunningHour.TabIndex = 94;
            // 
            // lblSupportRngHour
            // 
            this.lblSupportRngHour.AutoSize = true;
            this.lblSupportRngHour.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupportRngHour.ForeColor = System.Drawing.Color.Red;
            this.lblSupportRngHour.Location = new System.Drawing.Point(455, 21);
            this.lblSupportRngHour.Name = "lblSupportRngHour";
            this.lblSupportRngHour.Size = new System.Drawing.Size(224, 17);
            this.lblSupportRngHour.TabIndex = 93;
            this.lblSupportRngHour.Text = "Information On Running hours";
            // 
            // btnSaveSupportInfo
            // 
            this.btnSaveSupportInfo.BackColor = System.Drawing.Color.Red;
            this.btnSaveSupportInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSaveSupportInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveSupportInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSupportInfo.ForeColor = System.Drawing.Color.White;
            this.btnSaveSupportInfo.Location = new System.Drawing.Point(297, 419);
            this.btnSaveSupportInfo.Name = "btnSaveSupportInfo";
            this.btnSaveSupportInfo.Size = new System.Drawing.Size(75, 23);
            this.btnSaveSupportInfo.TabIndex = 92;
            this.btnSaveSupportInfo.Text = "Save";
            this.btnSaveSupportInfo.UseVisualStyleBackColor = false;
            this.btnSaveSupportInfo.Click += new System.EventHandler(this.btnSaveSupportInfo_Click);
            // 
            // lblSupportBunker
            // 
            this.lblSupportBunker.AutoSize = true;
            this.lblSupportBunker.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupportBunker.ForeColor = System.Drawing.Color.Red;
            this.lblSupportBunker.Location = new System.Drawing.Point(36, 21);
            this.lblSupportBunker.Name = "lblSupportBunker";
            this.lblSupportBunker.Size = new System.Drawing.Size(170, 17);
            this.lblSupportBunker.TabIndex = 1;
            this.lblSupportBunker.Text = "Information On Bunker";
            // 
            // dgvBunkerInfo
            // 
            this.dgvBunkerInfo.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvBunkerInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBunkerInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBunkerInfo.Location = new System.Drawing.Point(35, 42);
            this.dgvBunkerInfo.Name = "dgvBunkerInfo";
            this.dgvBunkerInfo.Size = new System.Drawing.Size(264, 86);
            this.dgvBunkerInfo.TabIndex = 0;
            // 
            // dgvCylInpsection
            // 
            this.dgvCylInpsection.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvCylInpsection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCylInpsection.Location = new System.Drawing.Point(35, 146);
            this.dgvCylInpsection.Name = "dgvCylInpsection";
            this.dgvCylInpsection.Size = new System.Drawing.Size(367, 150);
            this.dgvCylInpsection.TabIndex = 99;
            this.dgvCylInpsection.Visible = false;
            // 
            // pnlSupportHistory
            // 
            this.pnlSupportHistory.Controls.Add(this.btnExportSupportToExcel);
            this.pnlSupportHistory.Controls.Add(this.lblSupportHistEngNo);
            this.pnlSupportHistory.Controls.Add(this.dgvSupportHistReadOnly);
            this.pnlSupportHistory.Location = new System.Drawing.Point(3, 3);
            this.pnlSupportHistory.Name = "pnlSupportHistory";
            this.pnlSupportHistory.Size = new System.Drawing.Size(950, 445);
            this.pnlSupportHistory.TabIndex = 102;
            this.pnlSupportHistory.Visible = false;
            // 
            // btnExportSupportToExcel
            // 
            this.btnExportSupportToExcel.BackColor = System.Drawing.Color.Red;
            this.btnExportSupportToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportSupportToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportSupportToExcel.ForeColor = System.Drawing.Color.White;
            this.btnExportSupportToExcel.Location = new System.Drawing.Point(413, 405);
            this.btnExportSupportToExcel.Name = "btnExportSupportToExcel";
            this.btnExportSupportToExcel.Size = new System.Drawing.Size(112, 23);
            this.btnExportSupportToExcel.TabIndex = 102;
            this.btnExportSupportToExcel.Text = "Export to Excel";
            this.btnExportSupportToExcel.UseVisualStyleBackColor = false;
            this.btnExportSupportToExcel.Click += new System.EventHandler(this.btnExportSupportToExcel_Click);
            // 
            // lblSupportHistEngNo
            // 
            this.lblSupportHistEngNo.AutoSize = true;
            this.lblSupportHistEngNo.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupportHistEngNo.Location = new System.Drawing.Point(13, 1);
            this.lblSupportHistEngNo.Name = "lblSupportHistEngNo";
            this.lblSupportHistEngNo.Size = new System.Drawing.Size(68, 18);
            this.lblSupportHistEngNo.TabIndex = 101;
            this.lblSupportHistEngNo.Text = "label71";
            // 
            // dgvSupportHistReadOnly
            // 
            this.dgvSupportHistReadOnly.AllowUserToAddRows = false;
            this.dgvSupportHistReadOnly.AllowUserToDeleteRows = false;
            this.dgvSupportHistReadOnly.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvSupportHistReadOnly.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSupportHistReadOnly.Location = new System.Drawing.Point(15, 29);
            this.dgvSupportHistReadOnly.Name = "dgvSupportHistReadOnly";
            this.dgvSupportHistReadOnly.ReadOnly = true;
            this.dgvSupportHistReadOnly.Size = new System.Drawing.Size(921, 370);
            this.dgvSupportHistReadOnly.TabIndex = 0;
            // 
            // pnlHistory
            // 
            this.pnlHistory.Controls.Add(this.btnExportLogBookToExcel);
            this.pnlHistory.Controls.Add(this.lblEngineNoHistory);
            this.pnlHistory.Controls.Add(this.dgvReadOnlyHistory);
            this.pnlHistory.Location = new System.Drawing.Point(3, 3);
            this.pnlHistory.Name = "pnlHistory";
            this.pnlHistory.Size = new System.Drawing.Size(950, 445);
            this.pnlHistory.TabIndex = 96;
            this.pnlHistory.Visible = false;
            // 
            // btnExportLogBookToExcel
            // 
            this.btnExportLogBookToExcel.BackColor = System.Drawing.Color.Red;
            this.btnExportLogBookToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportLogBookToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportLogBookToExcel.ForeColor = System.Drawing.Color.White;
            this.btnExportLogBookToExcel.Location = new System.Drawing.Point(396, 405);
            this.btnExportLogBookToExcel.Name = "btnExportLogBookToExcel";
            this.btnExportLogBookToExcel.Size = new System.Drawing.Size(112, 23);
            this.btnExportLogBookToExcel.TabIndex = 103;
            this.btnExportLogBookToExcel.Text = "Export to Excel";
            this.btnExportLogBookToExcel.UseVisualStyleBackColor = false;
            this.btnExportLogBookToExcel.Click += new System.EventHandler(this.btnExportLogBookToExcel_Click);
            // 
            // lblEngineNoHistory
            // 
            this.lblEngineNoHistory.AutoSize = true;
            this.lblEngineNoHistory.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineNoHistory.Location = new System.Drawing.Point(13, 1);
            this.lblEngineNoHistory.Name = "lblEngineNoHistory";
            this.lblEngineNoHistory.Size = new System.Drawing.Size(68, 18);
            this.lblEngineNoHistory.TabIndex = 101;
            this.lblEngineNoHistory.Text = "label71";
            // 
            // dgvReadOnlyHistory
            // 
            this.dgvReadOnlyHistory.AllowUserToAddRows = false;
            this.dgvReadOnlyHistory.AllowUserToDeleteRows = false;
            this.dgvReadOnlyHistory.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvReadOnlyHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReadOnlyHistory.Location = new System.Drawing.Point(15, 28);
            this.dgvReadOnlyHistory.Name = "dgvReadOnlyHistory";
            this.dgvReadOnlyHistory.ReadOnly = true;
            this.dgvReadOnlyHistory.Size = new System.Drawing.Size(921, 370);
            this.dgvReadOnlyHistory.TabIndex = 0;
            // 
            // pnlLogBookInfo
            // 
            this.pnlLogBookInfo.Controls.Add(this.lnkTemplate);
            this.pnlLogBookInfo.Controls.Add(this.lblIsNew);
            this.pnlLogBookInfo.Controls.Add(this.pnlRunningData);
            this.pnlLogBookInfo.Controls.Add(this.lblEngineNoLogBook);
            this.pnlLogBookInfo.Controls.Add(this.txtNoOfCyl);
            this.pnlLogBookInfo.Controls.Add(this.btnAddNewDate);
            this.pnlLogBookInfo.Controls.Add(this.btnSaveData);
            this.pnlLogBookInfo.Controls.Add(this.dgvCylinderData);
            this.pnlLogBookInfo.Controls.Add(this.lblNoOfCylinders);
            this.pnlLogBookInfo.Controls.Add(this.lblPortSea);
            this.pnlLogBookInfo.Controls.Add(this.cmbPortSea);
            this.pnlLogBookInfo.Controls.Add(this.lblDate);
            this.pnlLogBookInfo.Controls.Add(this.dtDateOfReading);
            this.pnlLogBookInfo.Location = new System.Drawing.Point(3, 3);
            this.pnlLogBookInfo.Name = "pnlLogBookInfo";
            this.pnlLogBookInfo.Size = new System.Drawing.Size(950, 445);
            this.pnlLogBookInfo.TabIndex = 99;
            // 
            // lnkTemplate
            // 
            this.lnkTemplate.AutoSize = true;
            this.lnkTemplate.LinkColor = System.Drawing.Color.Red;
            this.lnkTemplate.Location = new System.Drawing.Point(786, 425);
            this.lnkTemplate.Name = "lnkTemplate";
            this.lnkTemplate.Size = new System.Drawing.Size(51, 13);
            this.lnkTemplate.TabIndex = 103;
            this.lnkTemplate.TabStop = true;
            this.lnkTemplate.Text = "Template";
            this.lnkTemplate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTemplate_LinkClicked);
            // 
            // lblIsNew
            // 
            this.lblIsNew.AutoSize = true;
            this.lblIsNew.Location = new System.Drawing.Point(402, 12);
            this.lblIsNew.Name = "lblIsNew";
            this.lblIsNew.Size = new System.Drawing.Size(41, 13);
            this.lblIsNew.TabIndex = 102;
            this.lblIsNew.Text = "label38";
            this.lblIsNew.Visible = false;
            // 
            // pnlRunningData
            // 
            this.pnlRunningData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRunningData.Controls.Add(this.label14);
            this.pnlRunningData.Controls.Add(this.label13);
            this.pnlRunningData.Controls.Add(this.label41);
            this.pnlRunningData.Controls.Add(this.txtDensity2);
            this.pnlRunningData.Controls.Add(this.label49);
            this.pnlRunningData.Controls.Add(this.cmbOilGrade2);
            this.pnlRunningData.Controls.Add(this.label50);
            this.pnlRunningData.Controls.Add(this.txtConsump);
            this.pnlRunningData.Controls.Add(this.label15);
            this.pnlRunningData.Controls.Add(this.lblConsump);
            this.pnlRunningData.Controls.Add(this.lblRunningData);
            this.pnlRunningData.Controls.Add(this.txtNoOfTCInUse);
            this.pnlRunningData.Controls.Add(this.txtCatfines);
            this.pnlRunningData.Controls.Add(this.txtVanadium);
            this.pnlRunningData.Controls.Add(this.lblCatFines);
            this.pnlRunningData.Controls.Add(this.lblVanadium);
            this.pnlRunningData.Controls.Add(this.label16);
            this.pnlRunningData.Controls.Add(this.txtComments);
            this.pnlRunningData.Controls.Add(this.txtPercentS);
            this.pnlRunningData.Controls.Add(this.lblPercentS);
            this.pnlRunningData.Controls.Add(this.lblComments);
            this.pnlRunningData.Controls.Add(this.lblEngRoomTemp);
            this.pnlRunningData.Controls.Add(this.txtEngRoomTemp);
            this.pnlRunningData.Controls.Add(this.lblScavAirTemp);
            this.pnlRunningData.Controls.Add(this.txtScavAirTemp);
            this.pnlRunningData.Controls.Add(this.lblPower);
            this.pnlRunningData.Controls.Add(this.txtPower);
            this.pnlRunningData.Controls.Add(this.lblSampleForRCC);
            this.pnlRunningData.Controls.Add(this.cmbSampleForRCC);
            this.pnlRunningData.Controls.Add(this.lblAmpTemp);
            this.pnlRunningData.Controls.Add(this.txtAmpTemp);
            this.pnlRunningData.Controls.Add(this.lblCylinderRPM);
            this.pnlRunningData.Controls.Add(this.txtCylinderRPM);
            this.pnlRunningData.Controls.Add(this.lblCylinderOilCons);
            this.pnlRunningData.Controls.Add(this.txtCylinderOilCons);
            this.pnlRunningData.Controls.Add(this.lblRelHumidity);
            this.pnlRunningData.Controls.Add(this.txtRelHumidity);
            this.pnlRunningData.Controls.Add(this.lblTotalEngineHours);
            this.pnlRunningData.Controls.Add(this.txtTotalEngineHours);
            this.pnlRunningData.Location = new System.Drawing.Point(16, 191);
            this.pnlRunningData.Name = "pnlRunningData";
            this.pnlRunningData.Size = new System.Drawing.Size(915, 225);
            this.pnlRunningData.TabIndex = 90;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(882, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 13);
            this.label14.TabIndex = 257;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(663, 83);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 13);
            this.label13.TabIndex = 256;
            this.label13.Text = "*";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(195, 188);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 13);
            this.label41.TabIndex = 253;
            this.label41.Text = "*";
            // 
            // txtDensity2
            // 
            this.txtDensity2.Enabled = false;
            this.txtDensity2.Location = new System.Drawing.Point(320, 182);
            this.txtDensity2.Name = "txtDensity2";
            this.txtDensity2.ReadOnly = true;
            this.txtDensity2.Size = new System.Drawing.Size(100, 20);
            this.txtDensity2.TabIndex = 255;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(238, 184);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(67, 13);
            this.label49.TabIndex = 252;
            this.label49.Text = "Density, kg/l";
            // 
            // cmbOilGrade2
            // 
            this.cmbOilGrade2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOilGrade2.FormattingEnabled = true;
            this.cmbOilGrade2.Items.AddRange(new object[] {
            "--Select--",
            "Alexia S3 (25 BN)",
            "Alexia S4 (60 BN)",
            "Alexia 50 (70 BN)",
            "Alexia S5 (80 BN)",
            "Alexia S6 (100 BN)"});
            this.cmbOilGrade2.Location = new System.Drawing.Point(89, 181);
            this.cmbOilGrade2.Name = "cmbOilGrade2";
            this.cmbOilGrade2.Size = new System.Drawing.Size(100, 21);
            this.cmbOilGrade2.TabIndex = 254;
            this.cmbOilGrade2.SelectedIndexChanged += new System.EventHandler(this.cmbOilGrade2_SelectedIndexChanged);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(18, 185);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(51, 13);
            this.label50.TabIndex = 251;
            this.label50.Text = "Oil Grade";
            // 
            // txtConsump
            // 
            this.txtConsump.Location = new System.Drawing.Point(779, 35);
            this.txtConsump.Name = "txtConsump";
            this.txtConsump.Size = new System.Drawing.Size(100, 20);
            this.txtConsump.TabIndex = 5;
            this.txtConsump.Validating += new System.ComponentModel.CancelEventHandler(this.txtConsump_Validating);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(20, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 18);
            this.label15.TabIndex = 116;
            this.label15.Text = "Fuel In Use";
            // 
            // lblConsump
            // 
            this.lblConsump.AutoSize = true;
            this.lblConsump.Location = new System.Drawing.Point(663, 32);
            this.lblConsump.Name = "lblConsump";
            this.lblConsump.Size = new System.Drawing.Size(91, 26);
            this.lblConsump.TabIndex = 115;
            this.lblConsump.Text = "Fuel Consumption\r\n                  kg/hr";
            // 
            // lblRunningData
            // 
            this.lblRunningData.AutoSize = true;
            this.lblRunningData.Font = new System.Drawing.Font("Verdana", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunningData.ForeColor = System.Drawing.Color.Red;
            this.lblRunningData.Location = new System.Drawing.Point(350, -2);
            this.lblRunningData.Name = "lblRunningData";
            this.lblRunningData.Size = new System.Drawing.Size(132, 22);
            this.lblRunningData.TabIndex = 122;
            this.lblRunningData.Text = "Running Data";
            // 
            // txtNoOfTCInUse
            // 
            this.txtNoOfTCInUse.Location = new System.Drawing.Point(320, 141);
            this.txtNoOfTCInUse.Name = "txtNoOfTCInUse";
            this.txtNoOfTCInUse.Size = new System.Drawing.Size(100, 20);
            this.txtNoOfTCInUse.TabIndex = 15;
            this.txtNoOfTCInUse.Validating += new System.ComponentModel.CancelEventHandler(this.txtNoOfTCInUse_Validating);
            // 
            // txtCatfines
            // 
            this.txtCatfines.Location = new System.Drawing.Point(320, 40);
            this.txtCatfines.Name = "txtCatfines";
            this.txtCatfines.Size = new System.Drawing.Size(100, 20);
            this.txtCatfines.TabIndex = 3;
            this.txtCatfines.Validating += new System.ComponentModel.CancelEventHandler(this.txtCatfines_Validating);
            // 
            // txtVanadium
            // 
            this.txtVanadium.Location = new System.Drawing.Point(557, 37);
            this.txtVanadium.Name = "txtVanadium";
            this.txtVanadium.Size = new System.Drawing.Size(100, 20);
            this.txtVanadium.TabIndex = 4;
            this.txtVanadium.Validating += new System.ComponentModel.CancelEventHandler(this.txtVanadium_Validating);
            // 
            // lblCatFines
            // 
            this.lblCatFines.AutoSize = true;
            this.lblCatFines.Location = new System.Drawing.Point(234, 44);
            this.lblCatFines.Name = "lblCatFines";
            this.lblCatFines.Size = new System.Drawing.Size(71, 13);
            this.lblCatFines.TabIndex = 102;
            this.lblCatFines.Text = "Catfines, ppm";
            // 
            // lblVanadium
            // 
            this.lblVanadium.AutoSize = true;
            this.lblVanadium.Location = new System.Drawing.Point(445, 35);
            this.lblVanadium.Name = "lblVanadium";
            this.lblVanadium.Size = new System.Drawing.Size(97, 26);
            this.lblVanadium.TabIndex = 110;
            this.lblVanadium.Text = "Vanadium Content,\r\n                   ppm";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(223, 138);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 26);
            this.label16.TabIndex = 120;
            this.label16.Text = "   No. Of Turbo-\r\nchargers In Use";
            // 
            // txtComments
            // 
            this.txtComments.Location = new System.Drawing.Point(557, 140);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(322, 81);
            this.txtComments.TabIndex = 16;
            this.txtComments.Validating += new System.ComponentModel.CancelEventHandler(this.txtComments_Validating);
            // 
            // txtPercentS
            // 
            this.txtPercentS.Location = new System.Drawing.Point(89, 42);
            this.txtPercentS.Name = "txtPercentS";
            this.txtPercentS.Size = new System.Drawing.Size(100, 20);
            this.txtPercentS.TabIndex = 2;
            this.txtPercentS.Leave += new System.EventHandler(this.txtPercentS_Leave);
            // 
            // lblPercentS
            // 
            this.lblPercentS.AutoSize = true;
            this.lblPercentS.Location = new System.Drawing.Point(19, 43);
            this.lblPercentS.Name = "lblPercentS";
            this.lblPercentS.Size = new System.Drawing.Size(57, 13);
            this.lblPercentS.TabIndex = 94;
            this.lblPercentS.Text = "Sulphur, %";
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.Location = new System.Drawing.Point(485, 143);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(56, 13);
            this.lblComments.TabIndex = 117;
            this.lblComments.Text = "Comments";
            // 
            // lblEngRoomTemp
            // 
            this.lblEngRoomTemp.AutoSize = true;
            this.lblEngRoomTemp.Location = new System.Drawing.Point(463, 112);
            this.lblEngRoomTemp.Name = "lblEngRoomTemp";
            this.lblEngRoomTemp.Size = new System.Drawing.Size(78, 13);
            this.lblEngRoomTemp.TabIndex = 116;
            this.lblEngRoomTemp.Text = "Eng Room T°C";
            // 
            // txtEngRoomTemp
            // 
            this.txtEngRoomTemp.Location = new System.Drawing.Point(557, 109);
            this.txtEngRoomTemp.Name = "txtEngRoomTemp";
            this.txtEngRoomTemp.Size = new System.Drawing.Size(100, 20);
            this.txtEngRoomTemp.TabIndex = 12;
            this.txtEngRoomTemp.Validating += new System.ComponentModel.CancelEventHandler(this.txtEngRoomTemp_Validating);
            // 
            // lblScavAirTemp
            // 
            this.lblScavAirTemp.AutoSize = true;
            this.lblScavAirTemp.Location = new System.Drawing.Point(219, 111);
            this.lblScavAirTemp.Name = "lblScavAirTemp";
            this.lblScavAirTemp.Size = new System.Drawing.Size(88, 13);
            this.lblScavAirTemp.TabIndex = 112;
            this.lblScavAirTemp.Text = "Scav Air Temp°C";
            // 
            // txtScavAirTemp
            // 
            this.txtScavAirTemp.Location = new System.Drawing.Point(320, 109);
            this.txtScavAirTemp.Name = "txtScavAirTemp";
            this.txtScavAirTemp.Size = new System.Drawing.Size(100, 20);
            this.txtScavAirTemp.TabIndex = 11;
            this.txtScavAirTemp.Validating += new System.ComponentModel.CancelEventHandler(this.txtScavAirTemp_Validating);
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Location = new System.Drawing.Point(474, 81);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(66, 13);
            this.lblPower.TabIndex = 108;
            this.lblPower.Text = "Power, kWh";
            // 
            // txtPower
            // 
            this.txtPower.Location = new System.Drawing.Point(557, 74);
            this.txtPower.Name = "txtPower";
            this.txtPower.Size = new System.Drawing.Size(100, 20);
            this.txtPower.TabIndex = 8;
            this.txtPower.Validating += new System.ComponentModel.CancelEventHandler(this.txtPower_Validating);
            // 
            // lblSampleForRCC
            // 
            this.lblSampleForRCC.AutoSize = true;
            this.lblSampleForRCC.Location = new System.Drawing.Point(7, 141);
            this.lblSampleForRCC.Name = "lblSampleForRCC";
            this.lblSampleForRCC.Size = new System.Drawing.Size(68, 26);
            this.lblSampleForRCC.TabIndex = 106;
            this.lblSampleForRCC.Text = "Sample Sent\r\n         To Lab";
            // 
            // cmbSampleForRCC
            // 
            this.cmbSampleForRCC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSampleForRCC.FormattingEnabled = true;
            this.cmbSampleForRCC.Items.AddRange(new object[] {
            "--Select--",
            "Yes",
            "No"});
            this.cmbSampleForRCC.Location = new System.Drawing.Point(89, 144);
            this.cmbSampleForRCC.Name = "cmbSampleForRCC";
            this.cmbSampleForRCC.Size = new System.Drawing.Size(100, 21);
            this.cmbSampleForRCC.TabIndex = 14;
            this.cmbSampleForRCC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbSampleForRCC_KeyDown);
            // 
            // lblAmpTemp
            // 
            this.lblAmpTemp.AutoSize = true;
            this.lblAmpTemp.Location = new System.Drawing.Point(7, 112);
            this.lblAmpTemp.Name = "lblAmpTemp";
            this.lblAmpTemp.Size = new System.Drawing.Size(72, 13);
            this.lblAmpTemp.TabIndex = 104;
            this.lblAmpTemp.Text = "Amb Temp °C";
            // 
            // txtAmpTemp
            // 
            this.txtAmpTemp.Location = new System.Drawing.Point(89, 109);
            this.txtAmpTemp.Name = "txtAmpTemp";
            this.txtAmpTemp.Size = new System.Drawing.Size(100, 20);
            this.txtAmpTemp.TabIndex = 10;
            this.txtAmpTemp.Validating += new System.ComponentModel.CancelEventHandler(this.txtAmpTemp_Validating);
            // 
            // lblCylinderRPM
            // 
            this.lblCylinderRPM.AutoSize = true;
            this.lblCylinderRPM.Location = new System.Drawing.Point(271, 80);
            this.lblCylinderRPM.Name = "lblCylinderRPM";
            this.lblCylinderRPM.Size = new System.Drawing.Size(31, 13);
            this.lblCylinderRPM.TabIndex = 100;
            this.lblCylinderRPM.Text = "RPM";
            // 
            // txtCylinderRPM
            // 
            this.txtCylinderRPM.Location = new System.Drawing.Point(320, 77);
            this.txtCylinderRPM.Name = "txtCylinderRPM";
            this.txtCylinderRPM.Size = new System.Drawing.Size(100, 20);
            this.txtCylinderRPM.TabIndex = 7;
            this.txtCylinderRPM.Validating += new System.ComponentModel.CancelEventHandler(this.txtCylinderRPM_Validating);
            // 
            // lblCylinderOilCons
            // 
            this.lblCylinderOilCons.AutoSize = true;
            this.lblCylinderOilCons.Location = new System.Drawing.Point(700, 105);
            this.lblCylinderOilCons.Name = "lblCylinderOilCons";
            this.lblCylinderOilCons.Size = new System.Drawing.Size(69, 26);
            this.lblCylinderOilCons.TabIndex = 98;
            this.lblCylinderOilCons.Text = " Cylinder Oil\r\nCons ltrs/day";
            // 
            // txtCylinderOilCons
            // 
            this.txtCylinderOilCons.Location = new System.Drawing.Point(779, 109);
            this.txtCylinderOilCons.Name = "txtCylinderOilCons";
            this.txtCylinderOilCons.Size = new System.Drawing.Size(100, 20);
            this.txtCylinderOilCons.TabIndex = 13;
            this.txtCylinderOilCons.Validating += new System.ComponentModel.CancelEventHandler(this.txtCylinderOilCons_Validating);
            // 
            // lblRelHumidity
            // 
            this.lblRelHumidity.AutoSize = true;
            this.lblRelHumidity.Location = new System.Drawing.Point(709, 75);
            this.lblRelHumidity.Name = "lblRelHumidity";
            this.lblRelHumidity.Size = new System.Drawing.Size(59, 13);
            this.lblRelHumidity.TabIndex = 96;
            this.lblRelHumidity.Text = "Rel Hum %";
            // 
            // txtRelHumidity
            // 
            this.txtRelHumidity.Location = new System.Drawing.Point(779, 72);
            this.txtRelHumidity.Name = "txtRelHumidity";
            this.txtRelHumidity.Size = new System.Drawing.Size(100, 20);
            this.txtRelHumidity.TabIndex = 9;
            this.txtRelHumidity.Validating += new System.ComponentModel.CancelEventHandler(this.txtRelHumidity_Validating);
            // 
            // lblTotalEngineHours
            // 
            this.lblTotalEngineHours.AutoSize = true;
            this.lblTotalEngineHours.Location = new System.Drawing.Point(10, 70);
            this.lblTotalEngineHours.Name = "lblTotalEngineHours";
            this.lblTotalEngineHours.Size = new System.Drawing.Size(67, 26);
            this.lblTotalEngineHours.TabIndex = 92;
            this.lblTotalEngineHours.Text = "Total Engine\r\n          Hours";
            // 
            // txtTotalEngineHours
            // 
            this.txtTotalEngineHours.Location = new System.Drawing.Point(89, 77);
            this.txtTotalEngineHours.Name = "txtTotalEngineHours";
            this.txtTotalEngineHours.Size = new System.Drawing.Size(100, 20);
            this.txtTotalEngineHours.TabIndex = 6;
            this.txtTotalEngineHours.Validating += new System.ComponentModel.CancelEventHandler(this.txtTotalEngineHours_Validating);
            // 
            // lblEngineNoLogBook
            // 
            this.lblEngineNoLogBook.AutoSize = true;
            this.lblEngineNoLogBook.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineNoLogBook.Location = new System.Drawing.Point(13, 1);
            this.lblEngineNoLogBook.Name = "lblEngineNoLogBook";
            this.lblEngineNoLogBook.Size = new System.Drawing.Size(68, 18);
            this.lblEngineNoLogBook.TabIndex = 101;
            this.lblEngineNoLogBook.Text = "label71";
            // 
            // txtNoOfCyl
            // 
            this.txtNoOfCyl.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtNoOfCyl.Location = new System.Drawing.Point(827, 7);
            this.txtNoOfCyl.Name = "txtNoOfCyl";
            this.txtNoOfCyl.ReadOnly = true;
            this.txtNoOfCyl.Size = new System.Drawing.Size(100, 20);
            this.txtNoOfCyl.TabIndex = 93;
            // 
            // btnAddNewDate
            // 
            this.btnAddNewDate.BackColor = System.Drawing.Color.Red;
            this.btnAddNewDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddNewDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewDate.ForeColor = System.Drawing.Color.White;
            this.btnAddNewDate.Location = new System.Drawing.Point(483, 420);
            this.btnAddNewDate.Name = "btnAddNewDate";
            this.btnAddNewDate.Size = new System.Drawing.Size(75, 23);
            this.btnAddNewDate.TabIndex = 18;
            this.btnAddNewDate.Text = "Add new date";
            this.btnAddNewDate.UseVisualStyleBackColor = false;
            this.btnAddNewDate.Click += new System.EventHandler(this.btnAddNewDate_Click);
            // 
            // btnSaveData
            // 
            this.btnSaveData.BackColor = System.Drawing.Color.Red;
            this.btnSaveData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnSaveData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveData.ForeColor = System.Drawing.Color.White;
            this.btnSaveData.Location = new System.Drawing.Point(296, 420);
            this.btnSaveData.Name = "btnSaveData";
            this.btnSaveData.Size = new System.Drawing.Size(75, 23);
            this.btnSaveData.TabIndex = 17;
            this.btnSaveData.Text = "Save";
            this.btnSaveData.UseVisualStyleBackColor = false;
            this.btnSaveData.Click += new System.EventHandler(this.btnSaveData_Click);
            // 
            // dgvCylinderData
            // 
            this.dgvCylinderData.AllowUserToAddRows = false;
            this.dgvCylinderData.AllowUserToDeleteRows = false;
            this.dgvCylinderData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvCylinderData.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCylinderData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvCylinderData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCylinderData.GridColor = System.Drawing.Color.Black;
            this.dgvCylinderData.Location = new System.Drawing.Point(16, 43);
            this.dgvCylinderData.Name = "dgvCylinderData";
            this.dgvCylinderData.Size = new System.Drawing.Size(915, 136);
            this.dgvCylinderData.TabIndex = 1;
            // 
            // lblNoOfCylinders
            // 
            this.lblNoOfCylinders.AutoSize = true;
            this.lblNoOfCylinders.Location = new System.Drawing.Point(731, 10);
            this.lblNoOfCylinders.Name = "lblNoOfCylinders";
            this.lblNoOfCylinders.Size = new System.Drawing.Size(83, 13);
            this.lblNoOfCylinders.TabIndex = 88;
            this.lblNoOfCylinders.Text = "No. Of Cylinders";
            // 
            // lblPortSea
            // 
            this.lblPortSea.AutoSize = true;
            this.lblPortSea.Location = new System.Drawing.Point(497, 12);
            this.lblPortSea.Name = "lblPortSea";
            this.lblPortSea.Size = new System.Drawing.Size(50, 13);
            this.lblPortSea.TabIndex = 86;
            this.lblPortSea.Text = "Port/Sea";
            this.lblPortSea.Visible = false;
            // 
            // cmbPortSea
            // 
            this.cmbPortSea.FormattingEnabled = true;
            this.cmbPortSea.Items.AddRange(new object[] {
            "--Select--",
            "Port",
            "Sea"});
            this.cmbPortSea.Location = new System.Drawing.Point(553, 8);
            this.cmbPortSea.Name = "cmbPortSea";
            this.cmbPortSea.Size = new System.Drawing.Size(121, 21);
            this.cmbPortSea.TabIndex = 85;
            this.cmbPortSea.Visible = false;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(247, 9);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 84;
            this.lblDate.Text = "Date";
            // 
            // dtDateOfReading
            // 
            this.dtDateOfReading.Enabled = false;
            this.dtDateOfReading.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDateOfReading.Location = new System.Drawing.Point(283, 5);
            this.dtDateOfReading.Name = "dtDateOfReading";
            this.dtDateOfReading.Size = new System.Drawing.Size(103, 20);
            this.dtDateOfReading.TabIndex = 83;
            this.dtDateOfReading.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtDateOfReading_KeyDown);
            this.dtDateOfReading.Validating += new System.ComponentModel.CancelEventHandler(this.dtDateOfReading_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(159, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 4);
            this.label1.TabIndex = 2;
            this.label1.Text = "Shell Marine Log Book";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Gold;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(12, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1110, 2);
            this.label2.TabIndex = 3;
            // 
            // lblLinkSetting
            // 
            this.lblLinkSetting.AutoSize = true;
            this.lblLinkSetting.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblLinkSetting.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLinkSetting.LinkColor = System.Drawing.Color.Red;
            this.lblLinkSetting.Location = new System.Drawing.Point(17, 3);
            this.lblLinkSetting.Name = "lblLinkSetting";
            this.lblLinkSetting.Size = new System.Drawing.Size(68, 18);
            this.lblLinkSetting.TabIndex = 4;
            this.lblLinkSetting.TabStop = true;
            this.lblLinkSetting.Text = "Settings";
            this.lblLinkSetting.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLinkSetting_LinkClicked);
            // 
            // pnlSettingLabel
            // 
            this.pnlSettingLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlSettingLabel.Controls.Add(this.lblLinkSetting);
            this.pnlSettingLabel.Location = new System.Drawing.Point(1029, 63);
            this.pnlSettingLabel.Name = "pnlSettingLabel";
            this.pnlSettingLabel.Size = new System.Drawing.Size(93, 23);
            this.pnlSettingLabel.TabIndex = 5;
            // 
            // pnlLubeMonInfo
            // 
            this.pnlLubeMonInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlLubeMonInfo.Controls.Add(this.lblLubeMonInfo);
            this.pnlLubeMonInfo.Location = new System.Drawing.Point(876, 63);
            this.pnlLubeMonInfo.Name = "pnlLubeMonInfo";
            this.pnlLubeMonInfo.Size = new System.Drawing.Size(141, 23);
            this.pnlLubeMonInfo.TabIndex = 6;
            // 
            // lblLubeMonInfo
            // 
            this.lblLubeMonInfo.AutoSize = true;
            this.lblLubeMonInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblLubeMonInfo.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLubeMonInfo.LinkColor = System.Drawing.Color.Red;
            this.lblLubeMonInfo.Location = new System.Drawing.Point(98, 3);
            this.lblLubeMonInfo.Name = "lblLubeMonInfo";
            this.lblLubeMonInfo.Size = new System.Drawing.Size(40, 18);
            this.lblLubeMonInfo.TabIndex = 4;
            this.lblLubeMonInfo.TabStop = true;
            this.lblLubeMonInfo.Text = "Help";
            this.lblLubeMonInfo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLubeMonInfo_LinkClicked);
            // 
            // label20
            // 
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(21, 560);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1110, 2);
            this.label20.TabIndex = 7;
            // 
            // pnlContactUs
            // 
            this.pnlContactUs.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlContactUs.Controls.Add(this.lnkContactUs);
            this.pnlContactUs.Location = new System.Drawing.Point(795, 565);
            this.pnlContactUs.Name = "pnlContactUs";
            this.pnlContactUs.Size = new System.Drawing.Size(116, 23);
            this.pnlContactUs.TabIndex = 7;
            // 
            // lnkContactUs
            // 
            this.lnkContactUs.AutoSize = true;
            this.lnkContactUs.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lnkContactUs.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkContactUs.LinkColor = System.Drawing.Color.Red;
            this.lnkContactUs.Location = new System.Drawing.Point(13, 1);
            this.lnkContactUs.Name = "lnkContactUs";
            this.lnkContactUs.Size = new System.Drawing.Size(91, 18);
            this.lnkContactUs.TabIndex = 4;
            this.lnkContactUs.TabStop = true;
            this.lnkContactUs.Text = "Contact Us";
            this.lnkContactUs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContactUs_LinkClicked);
            // 
            // imgHeader
            // 
            this.imgHeader.Cursor = System.Windows.Forms.Cursors.Default;
            this.imgHeader.Location = new System.Drawing.Point(12, 507);
            this.imgHeader.Name = "imgHeader";
            this.imgHeader.Size = new System.Drawing.Size(150, 52);
            this.imgHeader.TabIndex = 8;
            this.imgHeader.TabStop = false;
            // 
            // pnlTandC
            // 
            this.pnlTandC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlTandC.Location = new System.Drawing.Point(955, 565);
            this.pnlTandC.Name = "pnlTandC";
            this.pnlTandC.Size = new System.Drawing.Size(167, 23);
            this.pnlTandC.TabIndex = 8;
            // 
            // lnkTandC
            // 
            this.lnkTandC.AutoSize = true;
            this.lnkTandC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lnkTandC.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkTandC.LinkColor = System.Drawing.Color.Red;
            this.lnkTandC.Location = new System.Drawing.Point(952, 566);
            this.lnkTandC.Name = "lnkTandC";
            this.lnkTandC.Size = new System.Drawing.Size(170, 18);
            this.lnkTandC.TabIndex = 4;
            this.lnkTandC.TabStop = true;
            this.lnkTandC.Text = "Terms and Conditions";
            this.lnkTandC.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkTandC_LinkClicked);
            // 
            // lblMarineConnect
            // 
            this.lblMarineConnect.AutoSize = true;
            this.lblMarineConnect.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblMarineConnect.Location = new System.Drawing.Point(503, 565);
            this.lblMarineConnect.Name = "lblMarineConnect";
            this.lblMarineConnect.Size = new System.Drawing.Size(82, 13);
            this.lblMarineConnect.TabIndex = 10;
            this.lblMarineConnect.Text = "Marine Connect";
            // 
            // imgShellMarine
            // 
            this.imgShellMarine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgShellMarine.Location = new System.Drawing.Point(12, 7);
            this.imgShellMarine.Name = "imgShellMarine";
            this.imgShellMarine.Size = new System.Drawing.Size(313, 69);
            this.imgShellMarine.TabIndex = 11;
            this.imgShellMarine.TabStop = false;
            this.imgShellMarine.Click += new System.EventHandler(this.imgHeader_Click);
            // 
            // CustomerVesselData
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1143, 593);
            this.Controls.Add(this.imgShellMarine);
            this.Controls.Add(this.lblMarineConnect);
            this.Controls.Add(this.lnkTandC);
            this.Controls.Add(this.pnlTandC);
            this.Controls.Add(this.imgHeader);
            this.Controls.Add(this.pnlContactUs);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.pnlLubeMonInfo);
            this.Controls.Add(this.pnlSettingLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.toolStripContainer1);
            this.Name = "CustomerVesselData";
            this.Text = "Marine Connect";
            this.Shown += new System.EventHandler(this.CustomerVesselData_Shown);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.tsMLBToolStrip.ResumeLayout(false);
            this.tsMLBToolStrip.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlProgramInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgOtherProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgAlexia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgOilAnalysis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubeMonitorPgm)).EndInit();
            this.pnlCylinderDrainOil.ResumeLayout(false);
            this.pnlCylinderDrainOil.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgOnBoardUserGuide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgUserGuide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgOnboardBroch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBrochure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubricantsLeaflet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLubMonUserGuide)).EndInit();
            this.pnlOtherProducts.ResumeLayout(false);
            this.pnlOtherProducts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgProducts)).EndInit();
            this.pnlAlexia.ResumeLayout(false);
            this.pnlAlexia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3TDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3MSDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS3Brochure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img50TDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img50MSDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS4TDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS4MSDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS6TDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgS6MSDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgAlexiaBroch)).EndInit();
            this.pnlLubeMonitorBroch.ResumeLayout(false);
            this.pnlLubeMonitorBroch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imbLubeMonitorBroch)).EndInit();
            this.pnlTermsAndConditions.ResumeLayout(false);
            this.pnlTermsAndConditions.PerformLayout();
            this.pnlHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgHome)).EndInit();
            this.pnlEngine2.ResumeLayout(false);
            this.pnlEngine2.PerformLayout();
            this.pnlEngineInfo.ResumeLayout(false);
            this.pnlEngineInfo.PerformLayout();
            this.pnlDataSubmission.ResumeLayout(false);
            this.pnlDataSubmission.PerformLayout();
            this.pnlSetting.ResumeLayout(false);
            this.pnlSetting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjectData)).EndInit();
            this.pnlConUs.ResumeLayout(false);
            this.pnlConUs.PerformLayout();
            this.pnlGraph.ResumeLayout(false);
            this.pnlGraph.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chBNData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chCylinderData)).EndInit();
            this.pnlSupportInfo.ResumeLayout(false);
            this.pnlSupportInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLinearWear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRunningHour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBunkerInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCylInpsection)).EndInit();
            this.pnlSupportHistory.ResumeLayout(false);
            this.pnlSupportHistory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupportHistReadOnly)).EndInit();
            this.pnlHistory.ResumeLayout(false);
            this.pnlHistory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReadOnlyHistory)).EndInit();
            this.pnlLogBookInfo.ResumeLayout(false);
            this.pnlLogBookInfo.PerformLayout();
            this.pnlRunningData.ResumeLayout(false);
            this.pnlRunningData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCylinderData)).EndInit();
            this.pnlSettingLabel.ResumeLayout(false);
            this.pnlSettingLabel.PerformLayout();
            this.pnlLubeMonInfo.ResumeLayout(false);
            this.pnlLubeMonInfo.PerformLayout();
            this.pnlContactUs.ResumeLayout(false);
            this.pnlContactUs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgShellMarine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        



        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip tsMLBToolStrip;
        private System.Windows.Forms.ToolStripTextBox tstxtEngInfo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox tsTxtLogBookDetail;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripTextBox tsTxtSupport;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripTextBox tsTxtDataSubmission;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox tsTxtGraph;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripTextBox tsTxtHistory;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlEngineInfo;
        private System.Windows.Forms.TextBox txtIMONo;
        private System.Windows.Forms.Label lblIMONo;
        private System.Windows.Forms.Label lblVesselName;
        private System.Windows.Forms.Label lblVesselId;
        private System.Windows.Forms.DateTimePicker dtDateDelivered;
        private System.Windows.Forms.Label lblDateDelivered;
        private System.Windows.Forms.Label lblEngManuf;
        private System.Windows.Forms.TextBox txtMainEngType;
        private System.Windows.Forms.Label lblEngType;
        private System.Windows.Forms.Label lblEngSerialNo;
        private System.Windows.Forms.TextBox txtMainEngLoc;
        private System.Windows.Forms.Label lblEngLoc;
        private System.Windows.Forms.Label lblEngNo;
        private System.Windows.Forms.TextBox txtMCR;
        private System.Windows.Forms.Label lblRPM;
        private System.Windows.Forms.TextBox txtLubType;
        private System.Windows.Forms.Label lblLubType;
        private System.Windows.Forms.Label lblMinFeedRate;
        private System.Windows.Forms.TextBox txtCurrentFeedRate;
        private System.Windows.Forms.Label lblCurrentFeedRate;
        private System.Windows.Forms.TextBox txtTargetFeedRate;
        private System.Windows.Forms.Label lblTgtFeedRate;
        private System.Windows.Forms.Label lblNoOfTC;
        private System.Windows.Forms.ComboBox cmbPistonCleaning;
        private System.Windows.Forms.Label lblPistonCleaning;
        private System.Windows.Forms.ComboBox cmbTCCutavail;
        private System.Windows.Forms.Label lblTCCut;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlLogBookInfo;
        private System.Windows.Forms.Label lblNoOfCylinders;
        private System.Windows.Forms.Label lblPortSea;
        private System.Windows.Forms.ComboBox cmbPortSea;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dtDateOfReading;
        private System.Windows.Forms.DataGridView dgvCylinderData;
        private System.Windows.Forms.Panel pnlRunningData;
        private System.Windows.Forms.Label lblTotalEngineHours;
        private System.Windows.Forms.TextBox txtTotalEngineHours;
        private System.Windows.Forms.Label lblPercentS;
        private System.Windows.Forms.TextBox txtPercentS;
        private System.Windows.Forms.Label lblRelHumidity;
        private System.Windows.Forms.TextBox txtRelHumidity;
        private System.Windows.Forms.TextBox txtCylinderOilCons;
        private System.Windows.Forms.Label lblCylinderOilCons;
        private System.Windows.Forms.Label lblCylinderRPM;
        private System.Windows.Forms.TextBox txtCylinderRPM;
        private System.Windows.Forms.TextBox txtCatfines;
        private System.Windows.Forms.Label lblCatFines;
        private System.Windows.Forms.Label lblAmpTemp;
        private System.Windows.Forms.TextBox txtAmpTemp;
        private System.Windows.Forms.Label lblSampleForRCC;
        private System.Windows.Forms.ComboBox cmbSampleForRCC;
        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.TextBox txtPower;
        private System.Windows.Forms.TextBox txtVanadium;
        private System.Windows.Forms.Label lblVanadium;
        private System.Windows.Forms.Label lblScavAirTemp;
        private System.Windows.Forms.TextBox txtScavAirTemp;
        private System.Windows.Forms.Label lblEngRoomTemp;
        private System.Windows.Forms.Label lblConsump;
        private System.Windows.Forms.TextBox txtConsump;
        private System.Windows.Forms.TextBox txtEngRoomTemp;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Button btnAddNewDate;
        private System.Windows.Forms.Button btnSaveData;
        private System.Windows.Forms.TextBox txtNoOfTCInUse;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblRunningData;
        private System.Windows.Forms.LinkLabel lblLinkSetting;
        private System.Windows.Forms.Panel pnlSettingLabel;
        private System.Windows.Forms.Panel pnlSetting;
        private System.Windows.Forms.DateTimePicker dtpTargetEndDate;
        private System.Windows.Forms.Label lblTgtCompdate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.TextBox txtNoOfVessels;
        private System.Windows.Forms.Label lblNoOfVessels;
        private System.Windows.Forms.TextBox txtCompName;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.TextBox txtProjectID;
        private System.Windows.Forms.Label lblProjectId;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.DataGridView dgvProjectData;
        private System.Windows.Forms.TextBox txtSMPPhone;
        private System.Windows.Forms.Label lblSMPPhone;
        private System.Windows.Forms.TextBox txtCustTelephone;
        private System.Windows.Forms.Label lblCustPhone;
        private System.Windows.Forms.TextBox txtSMPEMail;
        private System.Windows.Forms.Label lblSMPEmail;
        private System.Windows.Forms.TextBox txtCustEmail;
        private System.Windows.Forms.Label lblCustEmail;
        private System.Windows.Forms.TextBox txtSMPAddress;
        private System.Windows.Forms.Label lblSMPAddress;
        private System.Windows.Forms.TextBox txtCustAddress;
        private System.Windows.Forms.Label lblCustAddress;
        private System.Windows.Forms.TextBox txtSMPContact;
        private System.Windows.Forms.Label lblSMPContact;
        private System.Windows.Forms.TextBox txtCustomerContact;
        private System.Windows.Forms.Label lblCustomerContact;
        private System.Windows.Forms.Button btnSaveSetting;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtSettingVslId;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtSettingIMONumber;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtSettingVesselName;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnSaveEngineInfo;
        private System.Windows.Forms.Label lblNoOfCyl;
        private System.Windows.Forms.Panel pnlLubeMonInfo;
        private System.Windows.Forms.LinkLabel lblLubeMonInfo;
        private System.Windows.Forms.Panel pnlGraph;
        private System.Windows.Forms.DataVisualization.Charting.Chart chCylinderData;
        private System.Windows.Forms.Panel pnlConUs;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.LinkLabel lnkHere;
        private System.Windows.Forms.Label lblContactUs2;
        private System.Windows.Forms.Label lblContactUs1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel pnlContactUs;
        private System.Windows.Forms.LinkLabel lnkContactUs;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lblNoOfEngines;
        private System.Windows.Forms.TextBox txtNoOfCyl;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel pnlHistory;
        private System.Windows.Forms.DataGridView dgvReadOnlyHistory;
        private System.Windows.Forms.Panel pnlSupportInfo;
        private System.Windows.Forms.Label lblSupportBunker;
        private System.Windows.Forms.DataGridView dgvBunkerInfo;
        private System.Windows.Forms.Button btnSaveSupportInfo;
        private System.Windows.Forms.DataGridView dgvRunningHour;
        private System.Windows.Forms.Label lblSupportRngHour;
        private System.Windows.Forms.Label lblSupportLinWear;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DataGridView dgvLinearWear;
        private System.Windows.Forms.Label lblCylInfoSupport;
        private System.Windows.Forms.PictureBox imgHeader;
        private System.Windows.Forms.Panel pnlHome;
        private System.Windows.Forms.PictureBox imgHome;
        private System.Windows.Forms.Panel pnlEngine2;
        private System.Windows.Forms.Button btnSaveEngine2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cmbPistonCleaningRing2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox cmbTCCutOutAvail2;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtNoOfTC2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtTargetFeedRate2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtMinFeedRate2;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtCurrentFeedRate2;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtLubType2;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtMCR2;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtRPM2;
        private System.Windows.Forms.TextBox txtMainEngNo2;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtMainEngSerialNo2;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtMainEngLoc2;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtMainEngType2;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.DateTimePicker dtpDateDelivered2;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtVesselId2;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtIMONo2;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtVesselName2;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button btnSecondEngine;
        private System.Windows.Forms.Button btnFirstEngine;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.ComboBox cmbProjectStatus;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label lblEngineNoFirstEng;
        private System.Windows.Forms.Label lblEngineNoSup;
        private System.Windows.Forms.Label lblEngineNoHistory;
        private System.Windows.Forms.Label lblSecondEngine;
        private System.Windows.Forms.Label lblEngineNoLogBook;
        private System.Windows.Forms.Panel pnlDataSubmission;
        private System.Windows.Forms.Button btnSubmitData;
        private System.Windows.Forms.DataVisualization.Charting.Chart chBNData;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbXAxis;
        private System.Windows.Forms.CheckedListBox chkCylinderNumber;
        private System.Windows.Forms.Button btnSubmitGraph;
        private System.Windows.Forms.Label lblEngNoGraph;
        private System.Windows.Forms.Label lblFileSavedMessage;
        private System.Windows.Forms.Label lblFileLocation;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbNoOfCyl;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.DateTimePicker dtpSupportInfo;
        private System.Windows.Forms.Button btnAddNewSupport;
        private System.Windows.Forms.ToolStripTextBox tsTxtSupportHistory;
        private System.Windows.Forms.Panel pnlSupportHistory;
        private System.Windows.Forms.Label lblSupportHistEngNo;
        private System.Windows.Forms.DataGridView dgvSupportHistReadOnly;
        private System.Windows.Forms.CheckedListBox chkLstCylInspection;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cmbNoOfEngines;
        private System.Windows.Forms.DataGridView dgvCylInpsection;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblIsNew;
        private System.Windows.Forms.Label lblNewSupport;
        private System.Windows.Forms.Label lblHidden;
        private System.Windows.Forms.DateTimePicker dtpDateFrom;
        private System.Windows.Forms.Label lblDateFrom;
        private System.Windows.Forms.DateTimePicker dtpDateTo;
        private System.Windows.Forms.Label lblDateTo;
        private System.Windows.Forms.Panel pnlTandC;
        private System.Windows.Forms.LinkLabel lnkTandC;
        private System.Windows.Forms.Panel pnlTermsAndConditions;
        private System.Windows.Forms.Label lblTandC;
        private System.Windows.Forms.ComboBox cmbEngManuf2;
        private System.Windows.Forms.Label lblGenXML4;
        private System.Windows.Forms.LinkLabel lnkEmail;
        private System.Windows.Forms.Button btnExportLogBookToExcel;
        private System.Windows.Forms.Button btnExportSupportToExcel;
        private System.Windows.Forms.Label lblGenXML6;
        private System.Windows.Forms.Label lblGenXML5;
        private System.Windows.Forms.Label lblGenXML3;
        private System.Windows.Forms.Label lblGenXML2;
        private System.Windows.Forms.Label lblGenXML1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripTextBox tsProgramInfo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.Panel pnlProgramInfo;
        private System.Windows.Forms.ComboBox cmbEngManuf;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNoOfTC;
        private System.Windows.Forms.TextBox txtMinFeedRate;
        private System.Windows.Forms.Label lblMCR;
        private System.Windows.Forms.TextBox txtRPM;
        private System.Windows.Forms.TextBox txtMainEngNo;
        private System.Windows.Forms.TextBox txtMainEngSerialNo;
        private System.Windows.Forms.TextBox txtVesselId;
        private System.Windows.Forms.TextBox txtVesselName;
        private System.Windows.Forms.Label lblMarineConnect;
        private System.Windows.Forms.LinkLabel lnkTemplate;
        private System.Windows.Forms.PictureBox imgShellMarine;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtDensity2;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox cmbOilGrade2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox imgLubeMonitorPgm;
        private System.Windows.Forms.PictureBox imgOilAnalysis;
        private System.Windows.Forms.PictureBox imgAlexia;
        private System.Windows.Forms.PictureBox imgOtherProducts;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpGraphEndDate;
        private System.Windows.Forms.DateTimePicker dtpGraphStartDate;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbIronAxis;
        private System.Windows.Forms.TextBox txtRefBN;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtReferenceIron;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel pnlLubeMonitorBroch;
        private System.Windows.Forms.PictureBox imbLubeMonitorBroch;
        private System.Windows.Forms.Panel pnlCylinderDrainOil;
        private System.Windows.Forms.PictureBox imgLubMonUserGuide;
        private System.Windows.Forms.PictureBox imgLubricantsLeaflet;
        private System.Windows.Forms.PictureBox imgBrochure;
        private System.Windows.Forms.PictureBox imgOnboardBroch;
        private System.Windows.Forms.PictureBox imgUserGuide;
        private System.Windows.Forms.PictureBox imgOnBoardUserGuide;
        private System.Windows.Forms.Panel pnlAlexia;
        private System.Windows.Forms.PictureBox imgAlexiaBroch;
        private System.Windows.Forms.PictureBox imgS6MSDS;
        private System.Windows.Forms.PictureBox imgS6TDS;
        private System.Windows.Forms.PictureBox imgS4MSDS;
        private System.Windows.Forms.PictureBox imgS4TDS;
        private System.Windows.Forms.PictureBox img50MSDS;
        private System.Windows.Forms.PictureBox img50TDS;
        private System.Windows.Forms.PictureBox imgS3Brochure;
        private System.Windows.Forms.PictureBox imgS3MSDS;
        private System.Windows.Forms.PictureBox imgS3TDS;
        private System.Windows.Forms.Panel pnlOtherProducts;
        private System.Windows.Forms.PictureBox imgProducts;
        private System.Windows.Forms.Label lblCylinderDrain;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.Label lblAlexia;
        private System.Windows.Forms.Label lblPgmOverview;

    }
}